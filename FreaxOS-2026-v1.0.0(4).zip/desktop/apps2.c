/*
 * FreaxOS 2026 - desktop/apps2.c
 * Applications du bureau (2/2) + registre / Desktop apps (2/2) + registry.
 *
 * FR : Navigateur (moteur html.c sur les pages internes /www), Boutique
 *      (installation réelle via le VFS : /apps/ID.app + /etc/apps.conf),
 *      Réglages (fonds, accent, verre, langue), Extensions (desklets),
 *      À propos. Les objets struct app de apps1/apps2 forment le catalogue.
 * EN : Browser (html.c engine over internal /www pages), Store (real VFS
 *      install: /apps/ID.app + /etc/apps.conf), Settings (wallpapers, accent,
 *      glass, language), Extensions (desklets), About. struct app objects
 *      from apps1/apps2 form the catalog.
 */
#include "desktop.h"
#include "html.h"
#include "freax/vfs.h"
#include "freax/hal.h"
#include "freax/config.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

static u32 TXT = RGBA(235, 238, 245, 255);
static u32 DIM = RGBA(150, 158, 175, 255);

/* callbacks définis dans apps1.c / callbacks defined in apps1.c */
void icon_terminal(struct gfx *g, int x, int y, int s, u32 accent);
void icon_files(struct gfx *g, int x, int y, int s, u32 accent);
void icon_editor(struct gfx *g, int x, int y, int s, u32 accent);
void icon_calc(struct gfx *g, int x, int y, int s, u32 accent);
void icon_monitor(struct gfx *g, int x, int y, int s, u32 accent);
void term_draw(struct dwin *w, struct gfx *g, int x, int y, int cw, int ch);
int  term_key(struct dwin *w, int key, const char *text);
void term_open(struct dwin *w);
void files_open(struct dwin *w);
void files_draw(struct dwin *w, struct gfx *g, int x, int y, int cw, int ch);
int  files_pointer(struct dwin *w, int mx, int my, int btn, int evt,
                   int cw, int ch);
void editor_open(struct dwin *w);
void editor_draw(struct dwin *w, struct gfx *g, int x, int y, int cw, int ch);
int  editor_pointer(struct dwin *w, int mx, int my, int btn, int evt,
                    int cw, int ch);
int  editor_key(struct dwin *w, int key, const char *text);
void calc_open(struct dwin *w);
void calc_draw(struct dwin *w, struct gfx *g, int x, int y, int cw, int ch);
int  calc_pointer(struct dwin *w, int mx, int my, int btn, int evt,
                  int cw, int ch);
int  calc_key(struct dwin *w, int key, const char *text);
void mon_open(struct dwin *w);
void mon_draw(struct dwin *w, struct gfx *g, int x, int y, int cw, int ch);

/* ================================================================== */
/* Icônes (2/2) / icons (2/2)                                          */
/* ================================================================== */

void icon_browser(struct gfx *g, int x, int y, int s, u32 accent)
{
    gfx_circle_f(g, x + s / 2, y + s / 2, s / 2 - 1, RGBA(16, 22, 36, 235));
    gfx_circle_o(g, x + s / 2, y + s / 2, s / 2 - 1, RGBA(255, 255, 255, 70));
    gfx_circle_o(g, x + s / 2, y + s / 2, s / 4, RGBA(255, 255, 255, 60));
    gfx_hline(g, x + 2, x + s - 2, y + s / 2, RGBA(255, 255, 255, 60));
    gfx_vline(g, x + s / 2, y + 2, y + s - 2, RGBA(255, 255, 255, 60));
    gfx_circle_f(g, x + s / 2 - s / 5, y + s / 2 - s / 5, 2, accent);
}

void icon_store(struct gfx *g, int x, int y, int s, u32 accent)
{
    gfx_rect_f(g, x + s / 6, y + s / 3, s * 2 / 3, s * 5 / 9,
               RGBA(18, 24, 38, 235));
    gfx_rect_o(g, x + s / 6, y + s / 3, s * 2 / 3, s * 5 / 9,
               RGBA(255, 255, 255, 70));
    gfx_circle_o(g, x + s / 2, y + s / 3, s / 5, RGBA(255, 255, 255, 70));
    gfx_circle_f(g, x + s / 2, y + s / 2 + s / 6, 3, accent);
}

void icon_settings(struct gfx *g, int x, int y, int s, u32 accent)
{
    gfx_circle_f(g, x + s / 2, y + s / 2, s / 3, RGBA(18, 24, 38, 235));
    for (int i = 0; i < 8; i++) {
        int ang = i * 45;
        int dx = s / 3 + 2, dy = 0;
        int ca = 1, sa = 0;                    /* rotations de 45° / 45° steps */
        for (int k = 0; k < ang / 45; k++) {
            int ndx = (dx * ca - dy * sa) >> 1;
            int ndy = (dx * sa + dy * ca) >> 1;
            dx = ndx; dy = ndy;
            int t = ca;                        /* +45° : (c-s, s+c)/sqrt2 */
            ca = (ca * 3 - sa * 3) / 4;
            sa = (t * 3 + sa * 3) / 4;
        }
        gfx_rect_f(g, x + s / 2 + dx - 2, y + s / 2 + dy - 2, 5, 5,
                   RGBA(140, 150, 175, 255));
    }
    gfx_circle_o(g, x + s / 2, y + s / 2, s / 3, RGBA(255, 255, 255, 80));
    gfx_circle_f(g, x + s / 2, y + s / 2, s / 7, accent);
}

void icon_ext(struct gfx *g, int x, int y, int s, u32 accent)
{
    gfx_round_f(g, x + s / 6, y + s / 6, s * 2 / 3, s * 2 / 3, 3,
                RGBA(18, 24, 38, 235));
    gfx_round_o(g, x + s / 6, y + s / 6, s * 2 / 3, s * 2 / 3, 3,
                RGBA(255, 255, 255, 70));
    gfx_rect_f(g, x + s / 3, y + s / 6 - 3, s / 5, s / 8, accent);
    gfx_rect_f(g, x + s * 2 / 3, y + s / 3, s / 8, s / 5, accent);
    gfx_rect_f(g, x + s / 6 + 2, y + s / 2, s / 4, 2,
               RGBA(255, 255, 255, 90));
}

void icon_about(struct gfx *g, int x, int y, int s, u32 accent)
{
    /* mini Tux / mini Tux */
    gfx_circle_f(g, x + s / 2, y + s * 4 / 9, s / 3, RGBA(12, 14, 22, 245));
    gfx_circle_f(g, x + s / 2, y + s * 3 / 5, s / 4,
                 RGBA(240, 243, 250, 245));
    gfx_circle_f(g, x + s / 2 - s / 8, y + s / 3, 2,
                 RGBA(245, 248, 255, 255));
    gfx_circle_f(g, x + s / 2 + s / 8, y + s / 3, 2,
                 RGBA(245, 248, 255, 255));
    gfx_rect_f(g, x + s / 2 - 2, y + s / 2, 5, 3,
               RGBA(255, 170, 60, 255));
    gfx_rect_f(g, x + s / 2 - s / 6, y + s - 4, s / 3, 3,
               RGBA(255, 170, 60, 200));
    (void)accent;
}

/* ================================================================== */
/* Navigateur / Browser (pages internes /www via html.c)               */
/* ================================================================== */

struct brw_state {
    char url[96];
    struct html_doc *doc;
    char page[16384];
    int  scroll;
    char input[64];
    int  ilen;
    int  focus;
    char status[80];
};

static void brw_load(struct brw_state *b, const char *url)
{
    /* freax://freaxos.test/<page> -> /www/<page>.html */
    const char *p = strrchr(url, '/');
    char path[150];
    if (url[0] == '/')
        snprintf(path, sizeof path, "%s", url);
    else if (p && p[1])
        snprintf(path, sizeof path, "/www/%s.html", p + 1);
    else
        snprintf(path, sizeof path, "/www/accueil.html");
    snprintf(b->url, sizeof b->url, "%s", url);
    struct vnode *v = vfs_resolve(path);
    if (!v || v->type != VNODE_FILE) {
        snprintf(b->page, sizeof b->page,
                 "<h1>404</h1><p>Page introuvable / Page not found : %s</p>"
                 "<p><a href=\"freax://freaxos.test/accueil\">accueil / home"
                 "</a></p>", path);
    } else {
        u32 pos = 0;
        int n = vfs_read(v, b->page, (u32)sizeof b->page - 1, &pos);
        if (n < 0)
            n = 0;
        b->page[n] = '\0';
    }
    if (b->doc)
        html_close(b->doc);
    b->doc = html_open(b->page, 660);
    b->scroll = 0;
    b->input[0] = '\0';
    b->ilen = 0;
    b->focus = 0;
    b->status[0] = '\0';
}

static void brw_open(struct dwin *w)
{
    struct brw_state *b = win_state_alloc(w, sizeof *b);
    if (!b)
        return;
    memset(b, 0, sizeof *b);
    brw_load(b, "freax://freaxos.test/accueil");
}

static void brw_draw(struct dwin *w, struct gfx *g, int x, int y,
                     int cw, int ch)
{
    struct brw_state *b = win_state(w);
    if (!b)
        return;
    /* barre d'URL / URL bar */
    gfx_round_f(g, x, y, cw, 26, 8, RGBA(255, 255, 255, b->focus ? 40 : 24));
    gfx_text(g, x + 10, y + 5, "freax://", DIM);
    gfx_text(g, x + 10 + gfx_text_w("freax://", 1), y + 5,
             b->input[0] ? b->input : b->url + 8, theme_get()->accent);
    if (b->focus)
        gfx_text(g, x + 10 + gfx_text_w("freax://", 1) +
                     gfx_text_w(b->input, 1), y + 5, "_", TXT);
    gfx_round_f(g, x + cw - 84, y, 84, 26, 8, RGBA(255, 255, 255, 30));
    gfx_text(g, x + cw - 74, y + 5, tr("Accueil", "Home"), DIM);
    /* page */
    int view_h = ch - 36;
    if (b->doc)
        html_draw(g, b->doc, x + 6, y + 32, view_h, b->scroll,
                  theme_get()->accent);
    if (b->status[0])
        gfx_text(g, x + 6, y + ch - 14, b->status,
                 RGBA(255, 190, 120, 255));
}

static int brw_pointer(struct dwin *w, int mx, int my, int btn,
                       int evt, int cw, int ch)
{
    struct brw_state *b = win_state(w);
    if (!b)
        return 0;
    if (evt == 2) {                              /* molette / wheel */
        b->scroll += btn > 0 ? 24 : -24;
        if (b->scroll < 0)
            b->scroll = 0;
        if (b->doc && b->doc->height > ch - 36 &&
            b->scroll > b->doc->height - (ch - 36))
            b->scroll = b->doc->height - (ch - 36);
        return 1;
    }
    if (evt != 1 || btn != 1)
        return 0;
    if (my < 26) {                               /* barre d'URL / URL bar */
        if (mx >= cw - 84) {                     /* bouton accueil / home */
            brw_load(b, "freax://freaxos.test/accueil");
            return 1;
        }
        b->focus = 1;
        return 1;
    }
    b->focus = 0;
    /* clic sur un lien / link click */
    if (b->doc) {
        const char *href = NULL;
        if (html_hit_link(b->doc, mx - 6, my - 32 + b->scroll, &href)) {
            if (!strncmp(href, "freax://", 8)) {
                brw_load(b, href);
            } else if (!strncmp(href, "http", 4)) {
                snprintf(b->status, sizeof b->status,
                         tr("hors-ligne : pas de pile TCP/IP dans cette "
                            "version", "offline: no TCP/IP stack in this "
                            "build"));
            } else {
                char u[96];
                snprintf(u, sizeof u, "freax://freaxos.test/%s", href);
                brw_load(b, u);
            }
            return 1;
        }
    }
    return 1;
}

static int brw_key(struct dwin *w, int key, const char *text)
{
    struct brw_state *b = win_state(w);
    if (!b)
        return 0;
    if (b->focus) {
        if (key == KEY_RETURN) {
            char u[96];
            snprintf(u, sizeof u, "freax://freaxos.test/%s",
                     b->input[0] ? b->input : "accueil");
            brw_load(b, u);
            return 1;
        }
        if (key == KEY_BACKSPACE) {
            if (b->ilen > 0)
                b->input[--b->ilen] = '\0';
            return 1;
        }
        if (key == KEY_ESCAPE) {
            b->focus = 0;
            b->input[0] = '\0';
            b->ilen = 0;
            return 1;
        }
        if (text && text[0] >= 32 && text[0] < 127 && b->ilen < 62) {
            b->input[b->ilen++] = text[0];
            b->input[b->ilen] = '\0';
            return 1;
        }
        return 1;
    }
    if (key == KEY_ESCAPE) {
        b->scroll = 0;
        return 1;
    }
    return 0;
}

/* ================================================================== */
/* Boutique : installation réelle via VFS / real install via VFS       */
/* ================================================================== */

static const struct {
    const char *id, *fr, *en, *dfr, *den, *size;
} STORE_CATALOG[5] = {
    { "editor",  "Éditeur de texte", "Text Editor",
      "Écrire et enregistrer des fichiers du ramfs.",
      "Write and save ramfs files.", "12 Ko" },
    { "calc",    "Calculatrice", "Calculator",
      "Calculs entiers rapides au clavier ou à la souris.",
      "Fast integer math, keyboard or mouse.", "8 Ko" },
    { "monitor", "Moniteur système", "System Monitor",
      "Mémoire, tâches et journal du noyau en direct.",
      "Live memory, tasks and kernel log.", "10 Ko" },
    { "ext",     "Extensions", "Extensions",
      "Desklets horloge, moniteur et notes, applets tray.",
      "Clock, monitor and notes desklets, tray applets.", "9 Ko" },
    { "about",   "À propos", "About",
      "Histoire, licence et commande du projet.",
      "History, license and project credits.", "6 Ko" },
};

int store_catalog_count(void) { return 5; }

const char *store_catalog_id(int i)
{
    return (i >= 0 && i < store_catalog_count()) ? STORE_CATALOG[i].id : "";
}

const char *store_catalog_name(int i, int lang)
{
    return (i >= 0 && i < store_catalog_count())
               ? (lang ? STORE_CATALOG[i].en : STORE_CATALOG[i].fr) : "";
}

const char *store_catalog_desc(int i, int lang)
{
    return (i >= 0 && i < store_catalog_count())
               ? (lang ? STORE_CATALOG[i].den : STORE_CATALOG[i].dfr) : "";
}

const char *store_catalog_size(int i)
{
    return (i >= 0 && i < store_catalog_count()) ? STORE_CATALOG[i].size : "";
}

/* registre /etc/apps.conf : un id par ligne / one id per line */
static int registry_read(char *buf, int cap)
{
    buf[0] = '\0';
    struct vnode *f = vfs_resolve("/etc/apps.conf");
    if (!f)
        return 0;
    u32 pos = 0;
    int n = vfs_read(f, buf, cap - 1, &pos);
    if (n < 0)
        n = 0;
    buf[n] = '\0';
    return n;
}

static void registry_write(const char *buf)
{
    struct vnode *f = vfs_resolve("/etc/apps.conf");
    if (!f)
        f = vfs_create("/etc/apps.conf");
    if (!f)
        return;
    vfs_truncate(f);
    vfs_write(f, buf, (u32)strlen(buf), 0);
}

int store_is_installed(const char *id)
{
    char buf[256];
    registry_read(buf, (int)sizeof buf);
    char *save = NULL;
    for (char *l = strtok_r(buf, "\n", &save); l;
         l = strtok_r(NULL, "\n", &save))
        if (!strcmp(l, id))
            return 1;
    return 0;
}

int store_install(const char *id)
{
    if (store_is_installed(id))
        return 0;
    char path[64];
    snprintf(path, sizeof path, "/apps/%s.app", id);
    struct vnode *f = vfs_resolve(path);
    if (!f)
        f = vfs_create(path);
    if (!f)
        return -1;
    vfs_truncate(f);
    char meta[128];
    int n = snprintf(meta, sizeof meta,
                     "[bundle]\nid=%s\nos=FreaxOS 2026\napi=1.0\n", id);
    vfs_write(f, meta, (u32)(n > 0 ? n : 0), 0);
    char reg[256];
    registry_read(reg, (int)sizeof reg);
    int len = (int)strlen(reg);
    snprintf(reg + len, sizeof reg - len, "%s\n", id);
    registry_write(reg);
    return 0;
}

int store_uninstall(const char *id)
{
    char path[64];
    snprintf(path, sizeof path, "/apps/%s.app", id);
    vfs_unlink(path);
    char reg[256], out[256];
    (void)registry_read(reg, (int)sizeof reg);
    int olen = 0;
    char *save = NULL;
    for (char *l = strtok_r(reg, "\n", &save); l;
         l = strtok_r(NULL, "\n", &save))
        if (strcmp(l, id)) {
            int ll = (int)strlen(l);
            if (olen + ll + 2 < (int)sizeof out) {
                memcpy(out + olen, l, (u32)ll);
                olen += ll;
                out[olen++] = '\n';
            }
        }
    out[olen] = '\0';
    registry_write(out);
    return 0;
}

int store_installed_count(void)
{
    char buf[256];
    int n = registry_read(buf, (int)sizeof buf), c = 0;
    for (int i = 0; i < n; i++)
        if (buf[i] == '\n')
            c++;
    return c;
}

const char *store_installed_id(int i)
{
    static char id[32];
    char buf[256];
    registry_read(buf, (int)sizeof buf);
    int c = 0;
    char *save = NULL;
    for (char *l = strtok_r(buf, "\n", &save); l;
         l = strtok_r(NULL, "\n", &save))
        if (c++ == i) {
            snprintf(id, sizeof id, "%s", l);
            return id;
        }
    return "";
}

void store_seed(void)
{
    vfs_mkdir("/repo");
    vfs_mkdir("/apps");
    /* catalogue source / source catalog */
    for (int i = 0; i < store_catalog_count(); i++) {
        char path[64];
        snprintf(path, sizeof path, "/repo/%s.app", STORE_CATALOG[i].id);
        struct vnode *f = vfs_resolve(path);
        if (!f)
            f = vfs_create(path);
        if (!f)
            continue;
        vfs_truncate(f);
        char meta[160];
        int n = snprintf(meta, sizeof meta,
                         "[bundle]\nid=%s\nsize=%s\nos=FreaxOS 2026\n"
                         "api=1.0\n", STORE_CATALOG[i].id,
                         STORE_CATALOG[i].size);
        vfs_write(f, meta, (u32)n, 0);
    }
    /* apps installées par défaut / default installed set */
    if (!vfs_resolve("/etc/apps.conf")) {
        registry_write("editor\ncalc\nmonitor\next\nabout\n");
    }
}

struct store_state {
    int  installing;       /* index en cours / installing index, -1 sinon */
    u32  start;
    char msg[64];
};

static void store_open(struct dwin *w)
{
    struct store_state *s = win_state_alloc(w, sizeof *s);
    if (!s)
        return;
    s->installing = -1;
    s->start = 0;
    s->msg[0] = '\0';
}

static void store_draw(struct dwin *w, struct gfx *g, int x, int y,
                       int cw, int ch)
{
    struct store_state *s = win_state(w);
    if (!s)
        return;
    gfx_text_scale(g, x, y, tr("Bibliothèque", "App Library"), TXT, 2);
    gfx_text(g, x + 180, y + 8,
             tr("installation via le VFS du noyau",
                "installs through the kernel VFS"),
             DIM);
    int rows = (ch - 60) / 64;
    for (int i = 0; i < store_catalog_count() && i < rows; i++) {
        int ry = y + 40 + i * 64;
        gfx_round_f(g, x, ry, cw, 58, 8, RGBA(255, 255, 255, 18));
        icon_store(g, x + 10, ry + 10, 34, theme_get()->accent);
        int lang = theme_get()->lang;
        gfx_text(g, x + 54, ry + 8, store_catalog_name(i, lang), TXT);
        /* description tronquée avant le badge / desc clipped before badge */
        char dsc[72];
        snprintf(dsc, sizeof dsc, "%.*s", (int)(sizeof dsc) - 1,
                 store_catalog_desc(i, lang));
        int dmax = (cw - 130) / 9;
        if (dmax < 8)
            dmax = 8;
        if ((int)strlen(dsc) > dmax)
            dsc[dmax] = '\0';
        gfx_text(g, x + 54, ry + 26, dsc, DIM);
        gfx_text(g, x + 54, ry + 42, store_catalog_size(i),
                 RGBA(120, 128, 145, 255));
        int inst = store_is_installed(store_catalog_id(i));
        int busy = s->installing == i;
        int bw = 92;
        int bx = x + cw - bw - 12;
        if (busy) {
            u32 t = g_hal->ticks() - s->start;
            int pct = (int)(t / 12);           /* ~1.2 s / ~1.2s */
            if (pct > 100)
                pct = 100;
            gfx_round_f(g, bx, ry + 18, bw, 20, 8, RGBA(255, 255, 255, 40));
            gfx_round_f(g, bx, ry + 18, bw * pct / 100, 20, 8,
                        theme_get()->accent);
            if (pct >= 100) {
                store_install(store_catalog_id(i));
                s->installing = -1;
                snprintf(s->msg, sizeof s->msg,
                         tr("installé dans /apps", "installed to /apps"));
            }
        } else if (inst) {
            gfx_round_f(g, bx, ry + 18, bw, 20, 8, RGBA(80, 220, 140, 90));
            gfx_text(g, bx + 12, ry + 23, tr("Installé", "Installed"),
                     RGBA(140, 240, 180, 255));
        } else {
            gfx_round_f(g, bx, ry + 18, bw, 20, 8, theme_get()->accent);
            gfx_text(g, bx + 12, ry + 23, tr("Installer", "Install"),
                     RGBA(10, 12, 20, 255));
        }
    }
    if (s->msg[0])
        gfx_text(g, x, y + ch - 14, s->msg,
                 RGBA(140, 240, 180, 255));
}

static int store_pointer(struct dwin *w, int mx, int my, int btn,
                         int evt, int cw, int ch)
{
    struct store_state *s = win_state(w);
    if (!s || evt != 1 || btn != 1)
        return 0;
    if (s->installing >= 0)
        return 1;
    int rows = (ch - 60) / 64;
    for (int i = 0; i < store_catalog_count() && i < rows; i++) {
        int ry = 40 + i * 64;
        if (my >= ry && my < ry + 58 && mx >= cw - 104 && mx < cw - 12) {
            if (store_is_installed(store_catalog_id(i))) {
                store_uninstall(store_catalog_id(i));
                snprintf(s->msg, sizeof s->msg,
                         tr("désinstallé", "uninstalled"));
            } else {
                s->installing = i;
                s->start = g_hal->ticks();
                s->msg[0] = '\0';
            }
            return 1;
        }
    }
    return 1;
}

/* ================================================================== */
/* Réglages / Settings (thème, accent, verre, langue)                   */
/* ================================================================== */

static const u32 ACCENTS[6] = {
    RGB(0x22, 0xD3, 0xEE), RGB(0xA8, 0x55, 0xF7), RGB(0xF4, 0x3F, 0x6E),
    RGB(0x34, 0xD3, 0x99), RGB(0xFB, 0xBF, 0x24), RGB(0x60, 0xA5, 0xFA),
};

static void set_open(struct dwin *w)
{
    win_state_alloc(w, 16);
}

static void mini_wall(struct gfx *g, int x, int y, int w, int h, int idx)
{
    switch (idx) {
    case 0: gfx_gradient_diag(g, x, y, w, h, RGB(0x07, 0x0B, 0x1C),
                              RGB(0x1B, 0x10, 0x3B)); break;
    case 1: gfx_gradient_diag(g, x, y, w, h, RGB(0x07, 0x2B, 0x1F),
                              RGB(0x0D, 0x4F, 0x3C)); break;
    case 2: gfx_gradient_diag(g, x, y, w, h, RGB(0x04, 0x08, 0x1E),
                              RGB(0x11, 0x2E, 0x5A)); break;
    case 3: gfx_gradient_v(g, x, y, w, h, RGB(0x2B, 0x10, 0x3A),
                           RGB(0xC2, 0x4B, 0x22)); break;
    default: gfx_gradient_v(g, x, y, w, h, RGB(0x05, 0x06, 0x0C),
                            RGB(0x10, 0x14, 0x22)); break;
    }
}

static void set_draw(struct dwin *w, struct gfx *g, int x, int y,
                     int cw, int ch)
{
    (void)w;
    struct theme *t = theme_get();
    int lang = t->lang;
    gfx_text_scale(g, x, y, tr("Réglages", "Settings"), TXT, 2);
    /* fonds d'écran / wallpapers */
    gfx_text(g, x, y + 40, tr("Fond d'écran", "Wallpaper"), DIM);
    for (int i = 0; i < theme_wallpaper_count(); i++) {
        int wx = x + i * 104, wy = y + 62;
        mini_wall(g, wx, wy, 96, 56, i);
        if (!strcmp(theme_wallpaper_id(i), t->wallpaper))
            gfx_round_o(g, wx, wy, 96, 56, 3, t->accent);
        else
            gfx_round_o(g, wx, wy, 96, 56, 3, RGBA(255, 255, 255, 40));
        gfx_text(g, wx, wy + 60, theme_wallpaper_label(i, lang),
                 RGBA(170, 178, 195, 255));
    }
    /* accent / accent colors */
    gfx_text(g, x, y + 132, tr("Couleur d'accent", "Accent color"), DIM);
    for (int i = 0; i < 6; i++) {
        int ax = x + i * 54, ay = y + 154;
        gfx_circle_f(g, ax + 20, ay + 20, 18, ACCENTS[i]);
        if ((ACCENTS[i] & 0xFFFFFF) == (t->accent & 0xFFFFFF))
            gfx_circle_o(g, ax + 20, ay + 20, 22, RGBA(255, 255, 255, 220));
    }
    /* verre / glass */
    gfx_text(g, x, y + 204,
             tr("Intensité du verre (liquid glass)", "Glass intensity "
               "(liquid glass)"), DIM);
    int gx = x, gy = y + 228;
    gfx_round_f(g, gx, gy, cw - 120, 14, 7, RGBA(255, 255, 255, 40));
    gfx_round_f(g, gx, gy, (cw - 120) * t->glass / 100, 14, 7, t->accent);
    gfx_circle_f(g, gx + (cw - 120) * t->glass / 100, gy + 7, 10,
                 RGBA(240, 244, 252, 255));
    char gv[8];
    snprintf(gv, sizeof gv, "%d%%", t->glass);
    gfx_text(g, gx + cw - 110, gy + 2, gv, TXT);
    /* langue / language */
    gfx_text(g, x, y + 262, tr("Langue / Language", "Language"), DIM);
    gfx_round_f(g, x, y + 284, 90, 28, 8,
                lang ? RGBA(255, 255, 255, 26) : t->accent);
    gfx_text(g, x + 34, y + 292, "FR",
             lang ? TXT : RGBA(10, 12, 20, 255));
    gfx_round_f(g, x + 100, y + 284, 90, 28, 8,
                lang ? t->accent : RGBA(255, 255, 255, 26));
    gfx_text(g, x + 134, y + 292, "EN",
             lang ? RGBA(10, 12, 20, 255) : TXT);
    gfx_text(g, x, y + ch - 16,
             tr("Les changements sont enregistrés dans /etc "
                "(persiste sur le ramfs).",
                "Changes are saved under /etc (persists on the ramfs)."),
             RGBA(120, 128, 145, 255));
}

static int set_pointer(struct dwin *w, int mx, int my, int btn,
                       int evt, int cw, int ch)
{
    (void)w;
    struct theme *t = theme_get();
    if (evt != 1 || btn != 1)
        return 0;
    for (int i = 0; i < theme_wallpaper_count(); i++) {
        int wx = i * 104, wy = 62;
        if (mx >= wx && mx < wx + 96 && my >= wy && my < wy + 56) {
            theme_set_wallpaper(theme_wallpaper_id(i));
            conf_save();
            return 1;
        }
    }
    for (int i = 0; i < 6; i++) {
        int ax = i * 54 + 20 - 18, ay = 154;
        if (mx >= ax && mx <= ax + 36 && my >= ay && my <= ay + 40) {
            theme_set_accent(ACCENTS[i] & 0xFFFFFF);
            conf_save();
            return 1;
        }
    }
    if (my >= 228 && my <= 242) {
        int pct = mx * 100 / (cw - 120);
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;
        theme_set_glass(pct);
        conf_save();
        return 1;
    }
    if (my >= 284 && my <= 312) {
        if (mx < 90 && t->lang) {
            theme_set_lang(0);
            conf_save();
            return 1;
        }
        if (mx >= 100 && mx < 190 && !t->lang) {
            theme_set_lang(1);
            conf_save();
            return 1;
        }
    }
    (void)ch;
    return 1;
}

/* ================================================================== */
/* Extensions / Extensions manager                                     */
/* ================================================================== */

static const struct {
    const char *id, *fr, *en, *dfr, *den;
} EXTS[4] = {
    { "clock",  "Desklet Horloge", "Clock desklet",
      "Heure et date sur le bureau.", "Time and date on the desktop." },
    { "sysmon", "Desklet Moniteur", "Monitor desklet",
      "Mémoire et uptime en direct.", "Live memory and uptime." },
    { "notes",  "Desklet Notes", "Notes desklet",
      "Première ligne de /home/notes.txt.", "First line of /home/notes.txt." },
    { "tray",   "Applets tray (CPU/MEM)", "Tray applets (CPU/MEM)",
      "Indicateurs dans la barre des tâches.", "Indicators in the taskbar." },
};

static void ext_open(struct dwin *w)
{
    win_state_alloc(w, 16);
}

static void ext_draw(struct dwin *w, struct gfx *g, int x, int y,
                     int cw, int ch)
{
    (void)w;
    (void)ch;
    gfx_text_scale(g, x, y, tr("Extensions", "Extensions"), TXT, 2);
    gfx_text(g, x, y + 32,
             tr("Desklets et applets, au choix.", "Desklets and applets, "
               "your pick."), DIM);
    for (int i = 0; i < 4; i++) {
        int ry = y + 60 + i * 62;
        gfx_round_f(g, x, ry, cw, 54, 8, RGBA(255, 255, 255, 18));
        gfx_text(g, x + 14, ry + 8, theme_get()->lang ? EXTS[i].en
                                                      : EXTS[i].fr, TXT);
        gfx_text(g, x + 14, ry + 28, theme_get()->lang ? EXTS[i].den
                                                       : EXTS[i].dfr, DIM);
        /* interrupteur / switch */
        int on = desklet_enabled(EXTS[i].id);
        int sx = x + cw - 64, sy = ry + 16;
        gfx_round_f(g, sx, sy, 48, 22, 11,
                    on ? theme_get()->accent : RGBA(255, 255, 255, 40));
        gfx_circle_f(g, sx + (on ? 36 : 12), sy + 11, 8,
                     RGBA(245, 248, 255, 255));
    }
}

static int ext_pointer(struct dwin *w, int mx, int my, int btn,
                       int evt, int cw, int ch)
{
    (void)w;
    (void)ch;
    if (evt != 1 || btn != 1)
        return 0;
    for (int i = 0; i < 4; i++) {
        int ry = 60 + i * 62;
        if (my >= ry && my < ry + 54 && mx >= cw - 64 && mx < cw - 16) {
            desklet_set(EXTS[i].id, !desklet_enabled(EXTS[i].id));
            conf_save();
            return 1;
        }
    }
    return 1;
}

/* ================================================================== */
/* À propos / About                                                    */
/* ================================================================== */

static void about_draw(struct dwin *w, struct gfx *g, int x, int y,
                       int cw, int ch)
{
    (void)w;
    icon_about(g, x + 10, y + 6, 64, theme_get()->accent);
    gfx_text_scale(g, x + 84, y + 6, "FreaxOS 2026", TXT, 2);
    gfx_text(g, x + 84, y + 44, "v" FREAX_RELEASE " — « Liquid Glass »", DIM);
    int by = y + 92;
    gfx_text(g, x, by, tr(
        "Bureau complet relié au noyau portable : le Terminal exécute le",
        "Full desktop wired to the portable kernel: the Terminal runs the"),
        TXT);
    gfx_text(g, x, by + 18, tr(
        "vrai shell freaxsh, Fichiers et l'Éditeur passent par le VFS, le",
        "real freaxsh shell, Files and Editor go through the VFS, the"),
        TXT);
    gfx_text(g, x, by + 36, tr(
        "Moniteur lit /proc, la Boutique installe via /apps.",
        "Monitor reads /proc, the Store installs via /apps."),
        TXT);
    gfx_hline(g, x, x + cw, by + 64, RGBA(255, 255, 255, 50));
    gfx_text(g, x, by + 74, tr(
        "Inspiré du noyau Linux 0.12 (GNU GPL, février 1992).",
        "Inspired by the Linux 0.12 kernel (GNU GPL, February 1992)."),
        DIM);
    gfx_text(g, x, by + 92, tr(
        "Ici, « Liquid Glass » : barre translucide, flou du fond, coins",
        "Here, \"Liquid Glass\": translucent bar, background blur, rounded"),
        DIM);
    gfx_text(g, x, by + 110, tr(
        "arrondis — rendu 100 % logiciel dans un framebuffer ARGB32.",
        "corners — 100% software rendering into an ARGB32 framebuffer."),
        DIM);
    (void)ch;
    (void)w;
}

/* ================================================================== */
/* Registre des applications / app registry                            */
/* ================================================================== */

const struct app app_terminal = { "terminal", "Terminal", "Terminal",
    icon_terminal, term_draw, NULL, term_key, term_open, NULL };
const struct app app_files = { "files", "Fichiers", "Files",
    icon_files, files_draw, files_pointer, NULL, files_open, NULL };
const struct app app_browser = { "browser", "Navigateur", "Browser",
    icon_browser, brw_draw, brw_pointer, brw_key, brw_open, NULL };
const struct app app_store = { "store", "Boutique", "Store",
    icon_store, store_draw, store_pointer, NULL, store_open, NULL };
const struct app app_settings = { "settings", "Réglages", "Settings",
    icon_settings, set_draw, set_pointer, NULL, set_open, NULL };
const struct app app_editor = { "editor", "Éditeur", "Editor",
    icon_editor, editor_draw, editor_pointer, editor_key, editor_open, NULL };
const struct app app_calc = { "calc", "Calculatrice", "Calculator",
    icon_calc, calc_draw, calc_pointer, calc_key, calc_open, NULL };
const struct app app_monitor = { "monitor", "Moniteur", "Monitor",
    icon_monitor, mon_draw, NULL, NULL, mon_open, NULL };
const struct app app_ext = { "ext", "Extensions", "Extensions",
    icon_ext, ext_draw, ext_pointer, NULL, ext_open, NULL };
const struct app app_about = { "about", "À propos", "About",
    icon_about, about_draw, NULL, NULL, NULL, NULL };

static const struct app *const APP_TABLE[] = {
    &app_terminal, &app_files, &app_browser, &app_store, &app_settings,
    &app_editor, &app_calc, &app_monitor, &app_ext, &app_about,
};

int app_catalog_count(void)
{
    return (int)(sizeof APP_TABLE / sizeof APP_TABLE[0]);
}

const struct app *app_catalog(int i)
{
    if (i < 0 || i >= app_catalog_count())
        return NULL;
    return APP_TABLE[i];
}

const struct app *app_by_id(const char *id)
{
    for (int i = 0; i < app_catalog_count(); i++)
        if (!strcmp(APP_TABLE[i]->id, id))
            return APP_TABLE[i];
    return NULL;
}
