/*
 * FreaxOS 2026 - desktop/desktop.h
 * Bureau « Liquid Glass » / Liquid Glass desktop: themes, config, events,
 * window manager and applications.
 */
#ifndef FREAX_DESKTOP_H
#define FREAX_DESKTOP_H

#include "freax/types.h"
#include "gfx.h"

#define DESK_W 1024
#define DESK_H 600
#define TASKBAR_H 56
#define TITLE_H   30

/* ------------------------------------------------------------------ */
/* Thèmes / themes                                                     */
/* ------------------------------------------------------------------ */

struct theme {
    char wallpaper[24];        /* id du fond / wallpaper id        */
    u32  accent;               /* couleur accent RGB               */
    int  glass;                /* intensité du verre 0..100        */
    int  lang;                 /* 0 = FR, 1 = EN                   */
};

void  theme_init(void);
void  theme_apply(struct gfx *g);          /* dessine le fond / wallpaper */
int   theme_wallpaper_count(void);
const char *theme_wallpaper_id(int i);
const char *theme_wallpaper_label(int i, int lang);
int   theme_set_wallpaper(const char *id); /* 0 = ok, -1 inconnu         */
struct theme *theme_get(void);
void  theme_set_accent(u32 rgb);
void  theme_set_glass(int v);              /* borné 0..100 / clamped     */
void  theme_set_lang(int lang);
const char *tr(const char *fr, const char *en);

/* ------------------------------------------------------------------ */
/* Configuration persistée via le VFS du noyau / persisted via kernel VFS */
/* ------------------------------------------------------------------ */

void conf_load(void);                      /* /etc/freaxdesktop.conf     */
void conf_save(void);
void conf_set(const char *key, const char *val);
const char *conf_get(const char *key, const char *dflt);

/* ------------------------------------------------------------------ */
/* Bibliothèque d'applications / app store registry                     */
/* ------------------------------------------------------------------ */

void store_seed(void);                     /* /repo + /apps + catalogue  */
int  store_catalog_count(void);
const char *store_catalog_id(int i);
const char *store_catalog_name(int i, int lang);
const char *store_catalog_desc(int i, int lang);
const char *store_catalog_size(int i);
int  store_is_installed(const char *id);
int  store_install(const char *id);        /* 0 = ok                     */
int  store_uninstall(const char *id);      /* 0 = ok                     */
int  store_installed_count(void);
const char *store_installed_id(int i);

/* ------------------------------------------------------------------ */
/* Événements / events                                                  */
/* ------------------------------------------------------------------ */

enum devt_type {
    DEV_NONE = 0,
    DEV_MOTION,        /* souris bouge / mouse move          */
    DEV_DOWN,          /* bouton pressé / button pressed     */
    DEV_UP,            /* bouton relâché / button released   */
    DEV_KEY,           /* touche pressée / key press         */
    DEV_WHEEL,         /* molette (+1 / -1) / wheel          */
    DEV_RESIZE,
    DEV_QUIT
};

struct devt {
    int type;
    int mx, my;        /* position souris / mouse pos        */
    int btn;           /* 1 gauche, 2 milieu, 3 droite       */
    int wheel;
    int key;           /* X11 keysym compressé / keysym      */
    char text[8];      /* caractère UTF-8 tapé / typed char  */
};

/* clés utiles / useful keys (mappées par le frontend) */
#define KEY_BACKSPACE 0x1000
#define KEY_RETURN    0x1001
#define KEY_ESCAPE    0x1002
#define KEY_UP        0x1003
#define KEY_DOWN      0x1004
#define KEY_LEFT      0x1005
#define KEY_RIGHT     0x1006
#define KEY_TAB       0x1007
#define KEY_F2        0x1008

/* ------------------------------------------------------------------ */
/* Gestionnaire de fenêtres / window manager                            */
/* ------------------------------------------------------------------ */

struct dwin;

typedef void (*app_draw_fn)(struct dwin *w, struct gfx *g, int x, int y,
                            int cw, int ch);
typedef int  (*app_pointer_fn)(struct dwin *w, int mx, int my, int btn,
                               int evt_down, int cw, int ch);
typedef int  (*app_key_fn)(struct dwin *w, int key, const char *text);
typedef void (*app_open_fn)(struct dwin *w);
typedef void (*app_tick_fn)(struct dwin *w, u32 ticks);

struct app {
    const char *id;          /* identité / id                    */
    const char *name_fr;
    const char *name_en;
    void       (*icon)(struct gfx *g, int x, int y, int size, u32 accent);
    app_draw_fn     draw;
    app_pointer_fn  pointer; /* retourne 1 si consommé / consumed */
    app_key_fn      key;
    app_open_fn     open;    /* NULL = rien / nothing             */
    app_tick_fn     tick;
};

const struct app *app_by_id(const char *id);
const struct app *app_catalog(int i);       /* apps de base / builtin  */
int  app_catalog_count(void);

#define DWIN_MAX 8

struct dwin {
    int          used;
    const struct app *app;
    int          x, y, w, h;
    int          minimized;
    int          z;                 /* z-order, plus haut = devant      */
    void        *state;             /* état privé de l'app / app state  */
    int          state_cap;         /* taille allouée / allocated size  */
    int          drag_off_x, drag_off_y;
    int          dragging;
};

/* bureau / desktop lifecycle */
void desktop_task(void);                 /* tâche init du noyau !           */
void wm_init(void);
void wm_frame(struct gfx *g, u32 ticks); /* compose tout / compose all      */
void wm_input(const struct devt *e, u32 ticks);
void wm_open_app(const char *id);        /* ouvre (ou focus) / open or focus */
void wm_close_win(struct dwin *w);
struct dwin *wm_focused(void);
int  wm_window_count(void);
struct dwin *wm_window(int i);
void wm_toggle_launcher(void);
int  wm_launcher_open(void);
/* état privé d'une fenêtre (realloc via frontend) / window private state */
void *win_state_alloc(struct dwin *w, int size);
void *win_state(struct dwin *w);
/* captures console pour le Terminal / console capture for Terminal app */
void term_capture_begin(char *buf, int cap);

/* frontend X11 (desktop/x11_host.c) / X11 frontend via dlopen */
int  x11_open(int w, int h, const char *title);
u32 *x11_fb(void);
void x11_flush(void);
void x11_close(void);
int  x11_poll(struct devt *e);

/* desklets (widgets de bureau) / desklets */
void desklets_draw(struct gfx *g, u32 ticks);
int  desklets_pointer(struct devt e);     /* 1 si consommé / consumed       */
int  desklet_enabled(const char *id);
void desklet_set(const char *id, int on);

/* barre des tâches / taskbar */
void taskbar_draw(struct gfx *g, u32 ticks);
int  taskbar_pointer(const struct devt *e, u32 ticks);
void tray_draw(struct gfx *g, int x, int y, u32 ticks);

#endif /* FREAX_DESKTOP_H */
