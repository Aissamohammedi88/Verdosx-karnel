/*
 * FreaxOS 2026 - desktop/html.h
 * Mini moteur HTML (navigateur hors-ligne) / Tiny HTML engine (offline browser).
 *
 * FR : rendu d'un sous-ensemble HTML : h1-h3, p, b, i, li, hr, br, pre,
 *      a href (liens internes), entités &amp; &lt; &gt;. Mise en page par mots.
 * EN : renders an HTML subset: h1-h3, p, b, i, li, hr, br, pre, a href
 *      (internal links), entities. Word-based layout.
 */
#ifndef FREAX_DESKTOP_HTML_H
#define FREAX_DESKTOP_HTML_H

#include "gfx.h"

#define HTML_MAX_ATOMS 700
#define HTML_MAX_LINKS 16

struct html_doc {
    char   text[HTML_MAX_ATOMS][56];
    short  x[HTML_MAX_ATOMS], y[HTML_MAX_ATOMS];
    u8     size[HTML_MAX_ATOMS];       /* 1..3                                   */
    u8     flags[HTML_MAX_ATOMS];      /* bit0 gras, bit1 ital, bit2 hr, bit3 pre */
    short  link[HTML_MAX_ATOMS];       /* -1 ou index lien / -1 or link index    */
    int    natom;
    char   href[HTML_MAX_LINKS][88];
    int    nlink;
    int    height;                     /* hauteur totale / total laid height */
    int    width;                      /* largeur de mise en page / layout w */
    int    truncated;
};

struct html_doc *html_open(const char *src, int width);
void html_close(struct html_doc *d);
void html_draw(struct gfx *g, struct html_doc *d, int x, int y,
               int view_h, int scroll_y, u32 accent);
int  html_link_at(struct html_doc *d, int px, int py);   /* -1 si aucun */
const char *html_link_href(struct html_doc *d, int i);
int  html_hit_link(struct html_doc *d, int px, int py, const char **href);

#endif /* FREAX_DESKTOP_HTML_H */
