/*
 * FreaxOS 2026 - desktop/gfx.h
 * Rendu 2D logiciel du bureau / Software 2D renderer for the desktop.
 *
 * FR : framebuffer ARGB32 (0xAARRGGBB), blending alpha, rectangles arrondis,
 *      dégradés, flou (box blur), texte via desktop/font8x14.c. Zéro
 *      dépendance : utilisable côté hôte et (module font) côté bare-metal.
 * EN : ARGB32 framebuffer (0xAARRGGBB), alpha blending, rounded rects,
 *      gradients, box blur, text via desktop/font8x14.c. No dependencies:
 *      usable on host, font module also on bare-metal.
 */
#ifndef FREAX_DESKTOP_GFX_H
#define FREAX_DESKTOP_GFX_H

#include "freax/types.h"

/* Couleur / color helpers */
#define RGBA(r, g, b, a) \
    (((u32)(a) << 24) | ((u32)(r) << 16) | ((u32)(g) << 8) | (u32)(b))
#define RGB(r, g, b)       RGBA(r, g, b, 255)
#define GFX_R(c)  (((c) >> 16) & 0xFF)
#define GFX_G(c)  (((c) >> 8)  & 0xFF)
#define GFX_B(c)  ((c) & 0xFF)
#define GFX_A(c)  (((c) >> 24) & 0xFF)

struct gfx {
    u32 *fb;
    int  w, h;
};

/* --- contexte --- */
void gfx_init(struct gfx *g, u32 *fb, int w, int h);

/* --- pixels / rects --- */
void gfx_px(struct gfx *g, int x, int y, u32 c);
u32  gfx_get(struct gfx *g, int x, int y);
void gfx_fill(struct gfx *g, u32 c);
void gfx_rect_f(struct gfx *g, int x, int y, int w, int h, u32 c);   /* plein */
void gfx_rect_o(struct gfx *g, int x, int y, int w, int h, u32 c);   /* bord  */
void gfx_hline(struct gfx *g, int x0, int x1, int y, u32 c);
void gfx_vline(struct gfx *g, int x, int y0, int y1, u32 c);
void gfx_line(struct gfx *g, int x0, int y0, int x1, int y1, u32 c);
void gfx_circle_f(struct gfx *g, int cx, int cy, int r, u32 c);
void gfx_circle_o(struct gfx *g, int cx, int cy, int r, u32 c);

/* --- verre / glass : alpha + arrondi + flou --- */
void gfx_blend_rect(struct gfx *g, int x, int y, int w, int h, u32 c);
void gfx_round_f(struct gfx *g, int x, int y, int w, int h, int r, u32 c);
void gfx_round_o(struct gfx *g, int x, int y, int w, int h, int r, u32 c);
/* floute la zone (blur box) via un tampon fourni (w*h*u32 du rect) / blur */
void gfx_blur(struct gfx *g, int x, int y, int w, int h, int radius,
              u32 *scratch);
void gfx_gradient_v(struct gfx *g, int x, int y, int w, int h,
                    u32 top, u32 bottom);
void gfx_gradient_diag(struct gfx *g, int x, int y, int w, int h,
                       u32 top, u32 bottom);

/* --- texte (font8x14) --- */
void gfx_text(struct gfx *g, int x, int y, const char *s, u32 c);
void gfx_text_scale(struct gfx *g, int x, int y, const char *s, u32 c, int sc);
int  gfx_text_w(const char *s, int scale);
int  gfx_text_h(int scale);

#endif /* FREAX_DESKTOP_GFX_H */
