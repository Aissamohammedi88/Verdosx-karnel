/*
 * FreaxOS 2026 - sim/hal_host.c
 * HAL hébergé : terminal hôte / Hosted HAL: the terminal.
 *
 * FR : Terminal en mode semi-brut (écho géré par le shell), entrée non
 *      bloquante, horloge monotone de l'hôte. Un « script » peut préalimenter
 *      l'entrée (tests, démos, make smoke).
 * EN : Semi-raw terminal (echo handled by the shell), non-blocking input,
 *      host monotonic clock. A "script" can pre-feed stdin (tests, demos,
 *      make smoke).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <termios.h>
#include <time.h>

#include "freax/hal.h"
#include "freax/config.h"

static const char *hal_platform = "hosted simulator";

static struct termios g_saved;
static int   g_raw;
static int   g_eof;

static char  *g_script;
static freax_size g_script_len, g_script_pos;

void hal_host_set_script(const char *data, freax_size len)
{
    g_script = (char *)data;
    g_script_len = len;
    g_script_pos = 0;
}

static void restore_termios(void)
{
    if (g_raw)
        tcsetattr(STDIN_FILENO, TCSANOW, &g_saved);
    g_raw = 0;
}

static void on_signal(int sig)
{
    (void)sig;
    restore_termios();
    _exit(130);
}

static void hal_putc(char c)
{
    fputc((unsigned char)c, stdout);
}

static int hal_getc(void)
{
    if (g_script && g_script_pos < g_script_len)
        return (u8)g_script[g_script_pos++];
    if (g_eof)
        return -1;
    u8 c;
    ssize_t n = read(STDIN_FILENO, &c, 1);
    if (n == 1)
        return (int)c;
    if (n == 0) {
        g_eof = 1;              /* EOF (tube fermé) / closed pipe */
        return -1;
    }
    if (errno == EINTR || errno == EAGAIN)
        return -1;
    g_eof = 1;
    return -1;
}

static u32 hal_ticks(void)
{
    /* origine = démarrage du sim / origin = simulator start */
    static u32 origin;
    if (!origin) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        u64 ms = (u64)ts.tv_sec * 1000ull + (u64)ts.tv_nsec / 1000000ull;
        origin = (u32)(ms / (1000ull / FREAX_TICK_HZ));
        if (!origin)
            origin = 1;
    }
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    u64 ms = (u64)ts.tv_sec * 1000ull + (u64)ts.tv_nsec / 1000000ull;
    u32 now = (u32)(ms / (1000ull / FREAX_TICK_HZ));
    return now - origin;        /* wrap-safe (arithmétique u32) / wrap-safe */
}

static void hal_idle(void)
{
    usleep(2000);               /* 2 ms : laisse respirer / breathing room */
}

static void hal_shutdown(int reboot)
{
    (void)reboot;               /* le sim sort proprement / sim exits cleanly */
}

static struct hal g_hal_host = {
    .putc     = hal_putc,
    .getc     = hal_getc,
    .ticks    = hal_ticks,
    .idle     = hal_idle,
    .shutdown = hal_shutdown,
};

void hal_host_install(void)
{
    g_hal = &g_hal_host;
    g_hal_platform = hal_platform;

    if (isatty(STDIN_FILENO)) {
        if (tcgetattr(STDIN_FILENO, &g_saved) == 0) {
            struct termios t = g_saved;
            t.c_lflag &= ~(ICANON | ECHO);
            t.c_cc[VMIN] = 0;
            t.c_cc[VTIME] = 0;
            if (tcsetattr(STDIN_FILENO, TCSANOW, &t) == 0) {
                g_raw = 1;
                atexit(restore_termios);
            }
        }
        signal(SIGINT, on_signal);
        signal(SIGTERM, on_signal);
    } else {
        /* tube/fichier : lecture non bloquante / pipe/file: non-blocking */
        int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
        if (flags >= 0)
            fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
    }

    setvbuf(stdout, NULL, _IOLBF, 0);
}
