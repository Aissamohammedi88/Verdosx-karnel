/*
 * FreaxOS 2026 - sim/ctx_ucontext.c
 * Contextes hébergés via POSIX ucontext / Hosted contexts via POSIX ucontext.
 *
 * FR : Portable sur tous les hôtes POSIX (Linux, macOS) sans asm : la taille
 *      et la complexité du fichier tiennent dans l'éducation.
 * EN : Portable across all POSIX hosts (Linux, macOS) with no asm: file size
 *      and complexity stay within educational reach.
 */
#include <ucontext.h>
#include "freax/ctx.h"
#include "freax/printk.h"

int ctx_size(void)
{
    return (int)sizeof(ucontext_t);
}

int ctx_init(struct ctx *c, void *stack, u32 stack_size, void (*entry)(void))
{
    ucontext_t *u = (ucontext_t *)c;
    if (getcontext(u) != 0)
        return -1;
    u->uc_stack.ss_sp = stack;
    u->uc_stack.ss_size = (freax_size)stack_size;
    u->uc_stack.ss_flags = 0;
    u->uc_link = NULL;
    makecontext(u, entry, 0);
    return 0;
}

void ctx_switch(struct ctx *from, struct ctx *to)
{
    swapcontext((ucontext_t *)from, (ucontext_t *)to);
}
