/*
 * FreaxOS 2026 - sim/sim_main.c
 * Frontend du simulateur hébergé / Hosted simulator frontend.
 *
 * FR : Alloue le tas de l'hôte, installe le HAL terminal, amorce le noyau.
 *      Options : -c "cmd" (une commande), --script FILE (entrée préchargée),
 *      --mem KB, --version, --help. Idéal pour tester sans QEMU.
 * EN : Allocates the host heap, installs the terminal HAL, boots the kernel.
 *      Options: -c "cmd" (one command), --script FILE (pre-fed stdin),
 *      --mem KB, --version, --help. Great for testing without QEMU.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "freax/kernel.h"
#include "freax/config.h"
#include "freax/hal.h"
#include "freax/types.h"

void hal_host_install(void);
void hal_host_set_script(const char *data, freax_size len);

static char *read_entire_file(const char *path, freax_size *out_len)
{
    FILE *f = fopen(path, "rb");
    if (!f)
        return NULL;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size < 0) {
        fclose(f);
        return NULL;
    }
    char *buf = (char *)malloc((freax_size)size + 1);
    if (!buf) {
        fclose(f);
        return NULL;
    }
    if (fread(buf, 1, (freax_size)size, f) != (freax_size)size) {
        free(buf);
        fclose(f);
        return NULL;
    }
    fclose(f);
    buf[size] = '\0';
    *out_len = (freax_size)size;
    return buf;
}

static void usage(FILE *out, const char *prog)
{
    fprintf(out,
        "FreaxOS 2026 — simulateur hébergé / hosted simulator\n\n"
        "usage: %s [options]\n"
        "  -c \"cmd\"        exécute une commande puis halt / run one command\n"
        "  --script FILE   précharge l'entrée / pre-feed stdin from file\n"
        "  --mem KB        taille du tas en Kio / heap size in KiB (def: %u)\n"
        "  --version       bannière et sortie / banner and exit\n"
        "  --help          cette aide / this help\n\n"
        "exemple / example: %s -c \"ls /proc\"\n",
        prog, (unsigned)(FREAX_HEAP_SIZE / 1024), prog);
}

int main(int argc, char **argv)
{
    u32 heap_kib = (u32)(FREAX_HEAP_SIZE / 1024);
    char *script_buf = NULL;
    freax_size script_len = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--version") == 0) {
            printf("FreaxOS 2026 v%s (%s) — build %s\n", FREAX_RELEASE,
                   FREAX_CODENAME, FREAX_BUILD_DATE);
            return 0;
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            usage(stdout, argv[0]);
            return 0;
        } else if (strcmp(argv[i], "--mem") == 0 && i + 1 < argc) {
            heap_kib = (u32)atoi(argv[++i]);
            if (heap_kib < 64)
                heap_kib = 64;
            if (heap_kib > 64 * 1024)
                heap_kib = 64 * 1024;
        } else if (strcmp(argv[i], "-c") == 0 && i + 1 < argc) {
            const char *cmd = argv[++i];
            freax_size n = strlen(cmd);
            script_buf = (char *)malloc(n + 8);
            if (!script_buf) {
                fprintf(stderr, "sim : plus de mémoire hôte / out of host memory\n");
                return 1;
            }
            memcpy(script_buf, cmd, n);
            script_len = n;
            memcpy(script_buf + script_len, "\nhalt\n", 6);
            script_len += 6;
        } else if (strcmp(argv[i], "--script") == 0 && i + 1 < argc) {
            script_buf = read_entire_file(argv[++i], &script_len);
            if (!script_buf) {
                fprintf(stderr, "sim : script illisible / cannot read script\n");
                return 1;
            }
            /* garantit une fin propre / guarantee a clean exit */
            if (script_len < 4 ||
                memcmp(script_buf + script_len - 4, "halt", 4) != 0) {
                char *nb = (char *)realloc(script_buf, script_len + 8);
                if (!nb) {
                    free(script_buf);
                    return 1;
                }
                script_buf = nb;
                memcpy(script_buf + script_len, "\nhalt\n", 6);
                script_len += 6;
            }
        } else {
            fprintf(stderr, "sim : option inconnue / unknown option '%s'\n",
                    argv[i]);
            usage(stderr, argv[0]);
            return 1;
        }
    }

    hal_host_install();
    if (script_buf)
        hal_host_set_script(script_buf, script_len);

    void *heap = malloc((freax_size)heap_kib * 1024);
    if (!heap) {
        fprintf(stderr, "sim : tas hôte indisponible / no host heap\n");
        return 1;
    }

    kernel_boot(heap, heap_kib * 1024);

    printf("* FreaxOS terminé proprement / FreaxOS exited cleanly.\n");
    free(heap);
    free(script_buf);
    return 0;
}
