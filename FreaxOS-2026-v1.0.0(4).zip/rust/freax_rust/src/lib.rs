//! FreaxOS 2026 — rust/freax_rust/src/lib.rs
//! Module Rust optionnel du noyau (no_std, staticlib) / Optional Rust kernel
//! module (no_std, staticlib).
//!
//! FR : Comme le noyau Linux « écrit en C et Rust » de l'article Wikipedia de
//!      2026, FreaxOS embarque une partie de son outillage en Rust : le CRC32
//!      (table générée à la compilation) et la mascotte Tux. Si cargo est
//!      absent, le Makefile lie kernel/tux_stub.c (comportement identique).
//! EN : Echoing the "C and Rust" kernel of the 2026 Wikipedia article, FreaxOS
//!      ships part of its tooling in Rust: CRC32 (compile-time table) and the
//!      Tux mascot. If cargo is missing, the Makefile links kernel/tux_stub.c
//!      (identical behaviour).

#![no_std]
#![no_main]

use core::panic::PanicInfo;

#[panic_handler]
fn freax_panic(_info: &PanicInfo) -> ! {
    loop {}
}

/* ---- CRC32 (IEEE 802.3, polynôme 0xEDB88320) ---- */

const fn make_crc_table() -> [u32; 256] {
    let mut table = [0u32; 256];
    let mut i = 0usize;
    while i < 256 {
        let mut c = i as u32;
        let mut k = 0;
        while k < 8 {
            c = if c & 1 != 0 {
                0xEDB8_8320 ^ (c >> 1)
            } else {
                c >> 1
            };
            k += 1;
        }
        table[i] = c;
        i += 1;
    }
    table
}

static CRC_TABLE: [u32; 256] = make_crc_table();

/// CRC32 d'un tampon. seed : passez 0 (le calcul gère l'inversion).
/// CRC32 of a buffer. seed: pass 0 (inversion handled internally).
#[no_mangle]
pub extern "C" fn freax_crc32(data: *const u8, len: usize, seed: u32) -> u32 {
    if data.is_null() {
        return 0;
    }
    let bytes = unsafe { core::slice::from_raw_parts(data, len) };
    let mut crc = seed ^ 0xFFFF_FFFF;
    for &b in bytes {
        crc = CRC_TABLE[((crc ^ b as u32) & 0xFF) as usize] ^ (crc >> 8);
    }
    crc ^ 0xFFFF_FFFF
}

/* ---- Mascotte Tux / Tux mascot ---- */

const TUX_LINES: &[&str] = &[
    "   _____",
    "  /     \\        .---.",
    " | () () |       |o o|",
    "  \\  ^  /        (   )",
    "   |||||          \\_/ ~",
    "   |||||       .-\"\"\"\"\"\"-.",
    "  _/___\\_     /  FreaxOS \\",
    " (  TUX  )    \\  2026    /",
    "  `\"\"\"\"\"`      '-.,___,.-'",
];

/// Écrit l'ASCII-art de Tux dans buf (NUL-terminé). Retourne le nombre de
/// lignes. / Writes Tux ASCII-art into buf (NUL-terminated). Returns lines.
#[no_mangle]
pub extern "C" fn freax_tux_lines(buf: *mut u8, cap: i32) -> i32 {
    if buf.is_null() || cap <= 0 {
        return 0;
    }
    let cap = cap as usize;
    let mut n = 0usize;
    let mut lines = 0i32;
    for (i, line) in TUX_LINES.iter().enumerate() {
        for b in line.as_bytes() {
            if n + 1 >= cap {
                break;
            }
            unsafe {
                *buf.add(n) = *b;
            }
            n += 1;
        }
        if n + 1 < cap {
            unsafe {
                *buf.add(n) = b'\n';
            }
            n += 1;
        }
        lines += 1;
        let _ = i;
    }
    if n < cap {
        unsafe {
            *buf.add(n) = 0;
        }
    } else if cap > 0 {
        unsafe {
            *buf.add(cap - 1) = 0;
        }
    }
    lines
}

/// Provenance du module / module provenance string.
#[no_mangle]
pub extern "C" fn freax_rust_info(buf: *mut u8, cap: i32) -> i32 {
    const INFO: &str = "FreaxCore Rust (no_std staticlib) - build 2026";
    if buf.is_null() || cap <= 0 {
        return 0;
    }
    let cap = cap as usize;
    let bytes = INFO.as_bytes();
    let mut n = 0usize;
    while n < bytes.len() && n + 1 < cap {
        unsafe {
            *buf.add(n) = bytes[n];
        }
        n += 1;
    }
    if n < cap {
        unsafe {
            *buf.add(n) = 0;
        }
    } else if cap > 0 {
        unsafe {
            *buf.add(cap - 1) = 0;
        }
    }
    n as i32
}
