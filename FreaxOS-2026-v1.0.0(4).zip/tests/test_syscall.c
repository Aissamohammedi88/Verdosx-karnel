/*
 * FreaxOS 2026 - tests/test_syscall.c
 * Tests appels système / system call tests.
 */
#include "framework.h"
#include "freax/syscall.h"
#include "freax/sched.h"
#include "freax/vfs.h"
#include "freax/mm.h"
#include "freax/libc.h"

#include <string.h>

static void t_getpid_probe(void)
{
    int pid = sys_getpid();
    if (pid <= 0)
        task_exit(-10);
    task_exit(pid);
}

void suite_syscall(void)
{
    test_reset_kernel();

    /* getpid hors tâche / outside a task */
    CHECK(sys_getpid() == 0);

    /* getpid dans une tâche, via le dispatch générique / generic dispatch */
    int p = sched_spawn("probe", t_getpid_probe, 0);
    CHECK(p > 0);
    int code = -1;
    CHECK(task_wait(p, &code) == p);
    CHECK(code == p);                  /* la tâche a vu son vrai pid */

    /* dispatch générique : mauvais numéro / bad syscall number */
    CHECK(syscall(1234, 0, 0, 0) == -1);
    CHECK(syscall(-5, 0, 0, 0) == -1);

    /* open/close erreurs / open+close errors */
    CHECK(sys_open("/nope/missing.txt", 0) == -1);
    CHECK(sys_close(99) == -1);
    CHECK(sys_close(FD_STDOUT) == -1);

    /* write console via syscall / console write through syscall */
    const char *hello = "syscall-write-ok\n";
    CHECK(sys_write(FD_STDOUT, hello, (int)strlen(hello)) == (int)strlen(hello));
    CHECK(strstr(test_capture(), "syscall-write-ok") != NULL);

    /* fd round-trip via syscalls / fd round trip */
    const char *content = "kernel kit 2026";
    int fd = sys_open("/tmp/sy.txt", 1);          /* 'w' crée+tronque */
    CHECK(fd >= 3);
    CHECK(sys_write(fd, content, (int)strlen(content)) == (int)strlen(content));
    CHECK(sys_close(fd) == 0);
    fd = sys_open("/tmp/sy.txt", 0);
    CHECK(fd >= 3);
    char buf[64];
    int n = sys_read(fd, buf, (int)sizeof(buf) - 1);
    CHECK(n == (int)strlen(content));
    buf[n > 0 ? n : 0] = '\0';
    CHECK(strcmp(buf, content) == 0);
    CHECK(sys_close(fd) == 0);

    /* sys_open lecture d'un fichier absent / read of missing file */
    CHECK(sys_open("/tmp/absent.txt", 0) == -1);
    /* création implicite en 'w' / implicit create with 'w' */
    CHECK(sys_open("/tmp/absent.txt", 1) >= 3);

    /* uptime cohérent / uptime sanity */
    CHECK(sys_uptime_ticks() < 0x7FFFFFFFu);

    /* spawn/wait via syscalls avec attente bloquante / spawn+wait block */
    int pw = sys_spawn("probe2", t_getpid_probe);
    CHECK(pw > 0);
    CHECK(sys_wait(pw, &code) == pw);
    CHECK(code == pw);

    CHECK(mm_check() == 0);
}
