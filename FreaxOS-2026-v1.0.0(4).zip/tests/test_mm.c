/*
 * FreaxOS 2026 - tests/test_mm.c
 * Tests gestion mémoire / memory manager tests.
 */
#include "framework.h"
#include "freax/mm.h"
#include "freax/printk.h"
#include "freax/libc.h"

void suite_mm(void)
{
    test_reset_kernel();

    /* alignement et écriture / alignment + writes */
    for (int i = 0; i < 50; i++) {
        u8 *p = (u8 *)kmalloc(1 + (u32)(i * 7));
        CHECK(p != NULL);
        if (p) {
            CHECK(((freax_uptr)p % 16) == 0);
            memset(p, 0xAB, (freax_size)(1 + i * 7));
        }
    }
    CHECK(mm_check() == 0);

    struct mm_stats s1;
    mm_get_stats(&s1);
    CHECK(s1.n_alloc >= 50);
    CHECK(s1.n_free == 0);
    CHECK(s1.used > 0);
    CHECK(s1.used == s1.peak_used);

    /* motif allouer/libérer entrelacé / interleaved alloc/free pattern */
    u8 *ptrs[20];
    for (int i = 0; i < 20; i++)
        ptrs[i] = (u8 *)kmalloc(100);
    CHECK(mm_check() == 0);
    for (int i = 0; i < 20; i += 2)
        kfree(ptrs[i]);
    CHECK(mm_check() == 0);
    for (int i = 1; i < 20; i += 2)
        kfree(ptrs[i]);
    CHECK(mm_check() == 0);

    struct mm_stats s2;
    mm_get_stats(&s2);
    CHECK(s2.n_free == 20);       /* les 50 premiers restent (fuite volontaire) */
    CHECK(mm_check() == 0);

    /* test coalescence propre / clean coalescing on a fresh heap */
    test_reset_kernel();
    struct mm_stats s0;
    mm_get_stats(&s0);                    /* état après seed vfs / post-seed */
    int mm_leak_count_baseline = mm_leak_count();
    u8 *a = (u8 *)kmalloc(1024);
    u8 *b = (u8 *)kmalloc(1024);
    u8 *c = (u8 *)kmalloc(1024);
    CHECK(a && b && c);
    kfree(a);
    kfree(b);
    kfree(c);
    struct mm_stats s3;
    mm_get_stats(&s3);
    CHECK(mm_check() == 0);
    /* tout doit revenir à l'état initial / everything back to baseline */
    CHECK(s3.used == s0.used);
    CHECK(s3.free == s0.free);
    CHECK(s3.n_blocks == s0.n_blocks);
    CHECK(mm_leak_count() == mm_leak_count_baseline);

    /* gros bloc après coalescence / big block after coalescing */
    u8 *big = (u8 *)kmalloc(4 * 1024);
    CHECK(big != NULL);
    memset(big, 0x5A, 4 * 1024);
    kfree(big);
    {
        struct mm_stats s5;
        mm_get_stats(&s5);
        CHECK(s5.used == s0.used);        /* toujours à l'état initial / baseline */
        CHECK(mm_check() == 0);
    }

    /* échec propre sur heap minuscule / clean OOM on tiny heap */
    test_reset_kernel();
    /* le noyau vient de créer ramfs... cherchons plutôt un échec direct :
       taille délirante / absurd size */
    void *nope = kmalloc(64u * 1024u * 1024u);
    CHECK(nope == NULL);
    struct mm_stats s4;
    mm_get_stats(&s4);
    CHECK(s4.n_fail >= 1);
    CHECK(mm_check() == 0);

    /* fuites détectées / leaks detected */
    void *l1 = kmalloc(10);
    void *l2 = kmalloc(20);
    (void)l1; (void)l2;
    CHECK(mm_leak_count() >= 2 + 1);   /* + le contexte ordonnanceur / sched ctx */

    /* kmalloc(0) renvoie un bloc valide / zero-size returns a block */
    void *z = kmalloc(0);
    CHECK(z != NULL);
    kfree(z);

    /* kfree(NULL) ne fait rien / free(NULL) is a no-op */
    kfree(NULL);
    CHECK(mm_check() == 0);
}
