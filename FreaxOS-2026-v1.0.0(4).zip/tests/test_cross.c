/*
 * FreaxOS 2026 - tests/test_cross.c
 * Tests transversaux : module Rust/C, libc du noyau / cross-cutting tests:
 * the Rust/C module and the kernel libc.
 */
#include "framework.h"
#include "freax/shell.h"
#include "freax/mm.h"
#include "freax/libc.h"

#include <string.h>

void suite_cross(void)
{
    test_reset_kernel();

    /* CRC32 : vecteurs IEEE / IEEE test vectors */
    CHECK(freax_crc32((const u8 *)"123456789", 9, 0) == 0xCBF43926u);
    CHECK(freax_crc32((const u8 *)"", 0, 0) == 0x00000000u);
    CHECK(freax_crc32((const u8 *)"a", 1, 0) == 0xE8B7BE43u);
    CHECK(freax_crc32((const u8 *)"The quick brown fox jumps over the lazy dog",
                      43, 0) == 0x414FA339u);
    /* seed non nul cohérent avec l'algorithme / non-zero seed consistency */
    u32 s1 = freax_crc32((const u8 *)"abcd", 4, 0);
    u32 s2 = freax_crc32((const u8 *)"abcd", 4, 1);
    CHECK(s1 != s2);

    /* provenance du module (Rust ou repli C) / module provenance */
    char info[96];
    int ni = freax_rust_info(info, (int)sizeof(info));
    CHECK(ni > 0);
    info[ni > 0 ? ni : 0] = '\0';
    CHECK(strstr(info, "Freax") != NULL);

    /* Tux : multi-lignes, contient l'ancre / Tux: multi-line with anchor */
    char art[512];
    int lines = freax_tux_lines(art, (int)sizeof(art));
    CHECK(lines == 9);
    CHECK(strstr(art, "FreaxOS") != NULL);
    CHECK(strstr(art, "2026") != NULL);

    /* tampon trop petit : pas d'écriture hors bornes / tiny buffer: no OOB */
    char tiny[8];
    int lt = freax_tux_lines(tiny, (int)sizeof(tiny));
    CHECK(lt >= 0);
    CHECK(tiny[7] == '\0');

    /* mini-libc du noyau / kernel mini-libc */
    char d1[16], d2[16];
    memset(d1, 0x41, sizeof(d1));
    memset(d2, 0x41, sizeof(d2));
    CHECK(memcmp(d1, d2, sizeof(d1)) == 0);
    d1[5] = 0x42;
    CHECK(memcmp(d1, d2, sizeof(d1)) != 0);

    char m1[16], m2[16];
    memcpy(m1, "abcdef", 7);
    memmove(m2, m1, 7);
    CHECK(strcmp(m2, "abcdef") == 0);
    memmove(m1 + 2, m1, 4);                     /* recouvrement / overlap */
    CHECK(memcmp(m1, "ababcd", 7) == 0);

    CHECK(strlen("freax") == 5);
    CHECK(strcmp("abc", "abd") < 0);
    CHECK(strncmp("abcdef", "abcxyz", 3) == 0);
    CHECK(strchr("hello", 'l') != NULL);
    CHECK(tolower('A') == 'a');
    CHECK(toupper('a') == 'A');
    CHECK(freax_atoi("42") == 42);
    CHECK(freax_atoi("-7") == -7);

    /* mm_check reste vert après tout ça / integrity still green */
    CHECK(mm_check() == 0);
}
