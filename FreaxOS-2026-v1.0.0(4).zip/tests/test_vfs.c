/*
 * FreaxOS 2026 - tests/test_vfs.c
 * Tests ramfs + /proc / ramfs and /proc tests.
 */
#include "framework.h"
#include "freax/vfs.h"
#include "freax/mm.h"
#include "freax/libc.h"
#include "freax/config.h"
#include "freax/shell.h"

#include <string.h>

static char ls_names[32][VFS_NAME_MAX];
static int  ls_types[32];
static int  ls_count;

static int ls_collect(const char *name, int type, void *ctx)
{
    (void)ctx;
    if (ls_count < 32) {
        strncpy(ls_names[ls_count], name, VFS_NAME_MAX - 1);
        ls_types[ls_count] = type;
        ls_count++;
    }
    return 1;
}

static int dir_has(const char *name)
{
    for (int i = 0; i < ls_count; i++)
        if (strcmp(ls_names[i], name) == 0)
            return 1;
    return 0;
}

void suite_vfs(void)
{
    test_reset_kernel();

    /* racine seedée / seeded root */
    struct vnode *root = vfs_root();
    CHECK(root != NULL);
    ls_count = 0;
    vfs_list(root, ls_collect, NULL);
    CHECK(dir_has("proc"));
    CHECK(dir_has("etc"));
    CHECK(dir_has("bin"));
    CHECK(dir_has("home"));

    /* /proc/version dynamique / dynamic /proc/version */
    struct vnode *v = vfs_resolve("/proc/version");
    CHECK(v != NULL);
    CHECK(v->type == VNODE_FILE);
    CHECK(v->is_dynamic);
    char buf[512];
    u32 pos = 0;
    int n = vfs_read(v, buf, (int)sizeof(buf) - 1, &pos);
    CHECK(n > 0);
    buf[n > 0 ? n : 0] = '\0';
    CHECK(strstr(buf, "FreaxOS") != NULL);
    CHECK(strstr(buf, FREAX_RELEASE) != NULL);

    /* /proc/uptime et /proc/meminfo / uptime & meminfo */
    v = vfs_resolve("/proc/meminfo");
    CHECK(v != NULL);
    pos = 0;                      /* réinitialise la position / reset position */
    n = vfs_read(v, buf, (int)sizeof(buf) - 1, &pos);
    CHECK(n > 0);
    buf[n > 0 ? n : 0] = '\0';
    CHECK(strstr(buf, "HeapTotal") != NULL);

    /* écriture/lecture ramfs / ramfs write+read round trip */
    CHECK(vfs_mkdir("/projet") != NULL);
    CHECK(vfs_create("/projet/notes.txt") != NULL);
    struct vnode *f = vfs_resolve("/projet/notes.txt");
    CHECK(f != NULL);
    CHECK(f->type == VNODE_FILE);
    const char *msg = "hello freax 1992->2026";
    CHECK(vfs_write(f, msg, (u32)strlen(msg), 0) == 0);
    char rb[128];
    u32 rp = 0;
    n = vfs_read(f, rb, sizeof(rb) - 1, &rp);
    CHECK(n == (int)strlen(msg));
    rb[n > 0 ? n : 0] = '\0';
    CHECK(strcmp(rb, msg) == 0);

    /* extension de tampon / buffer growth */
    char big[1000];
    for (int i = 0; i < (int)sizeof(big); i++)
        big[i] = (char)('A' + (i % 26));
    CHECK(vfs_write(f, big, sizeof(big), 0) == 0);   /* écrase / overwrites */
    u32 sz = f->size;
    CHECK(sz == sizeof(big));
    u32 rp2 = 0;
    n = vfs_read(f, rb, sizeof(rb) - 1, &rp2);       /* lecture partielle */
    CHECK(n == (int)sizeof(rb) - 1);                 /* 127 octets */
    CHECK(rb[0] == 'A');                             /* index 0  */
    CHECK(rb[126] == (char)('A' + (126 % 26)));      /* index 126 */
    CHECK(rp2 == 127u);

    /* résolution relative + « .. » / relative path + parent */
    CHECK(vfs_resolve("/tmp") != NULL);            /* déjà seedé / seeded  */
    CHECK(vfs_mkdir("/tmp_extra") != NULL);        /* nouveau dossier / new */
    vfs_set_cwd(vfs_resolve("/tmp"));
    CHECK(vfs_cwd() == vfs_resolve("/tmp"));
    CHECK(vfs_create("relatif.txt") != NULL);
    CHECK(vfs_resolve("relatif.txt") != NULL);
    CHECK(vfs_resolve("../tmp/relatif.txt") != NULL);
    CHECK(vfs_resolve("..") == vfs_root());
    CHECK(vfs_resolve(".") == vfs_resolve("/tmp"));
    CHECK(vfs_resolve("./././relatif.txt") != NULL);
    CHECK(vfs_resolve("/../../../etc/motd") != NULL); /* au-dessus de / : reste à / */

    /* écriture via fopen-like fds / fd-based write+read */
    int fd = vfs_fd_open(vfs_create("/tmp/fd_test.txt"), 1);
    CHECK(fd >= 3);
    CHECK(vfs_fd_write(fd, "abc", 3) == 3);
    CHECK(vfs_fd_write(fd, "def", 3) == 3);
    vfs_fd_close(fd);
    fd = vfs_fd_open(vfs_resolve("/tmp/fd_test.txt"), 0);
    CHECK(fd >= 3);
    char fb[16];
    CHECK(vfs_fd_read(fd, fb, 4) == 4);
    fb[4] = '\0';
    CHECK(strcmp(fb, "abcd") == 0);
    vfs_fd_close(fd);

    /* fds 0-2 réservés / reserved fds */
    CHECK(vfs_fd_open(vfs_resolve("/etc/motd"), 0) >= 3);

    /* suppression / unlink */
    CHECK(vfs_unlink("/tmp/fd_test.txt") == 0);
    CHECK(vfs_resolve("/tmp/fd_test.txt") == NULL);
    CHECK(vfs_unlink("/tmp/fd_test.txt") == -1);     /* déjà parti / gone */
    /* on ne supprime pas son propre cwd / cannot delete your own cwd */
    CHECK(vfs_unlink("/tmp") == -1);
    vfs_set_cwd(vfs_root());                         /* cd / */
    CHECK(vfs_unlink("/tmp") == -2);                 /* non vide / not empty */
    CHECK(vfs_unlink("/etc/motd") == 0);
    CHECK(vfs_resolve("/etc/motd") == NULL);

    /* chemin d'un nœud / path_of */
    char path[256];
    CHECK(vfs_path_of(vfs_resolve("/proc/version"), path, (int)sizeof(path)) > 0);
    CHECK(strcmp(path, "/proc/version") == 0);
    CHECK(vfs_path_of(vfs_root(), path, (int)sizeof(path)) > 0);
    CHECK(strcmp(path, "/") == 0);

    /* erreurs saines / sane errors */
    CHECK(vfs_resolve("/no/such/path") == NULL);
    CHECK(vfs_mkdir("/") == NULL);
    CHECK(vfs_resolve_dir("/etc/motd_removed") == NULL);

    CHECK(mm_check() == 0);

    /* arrêt propre puis re-init / clean shutdown then re-init */
    vfs_shutdown();
    /* reste 1 bloc : le contexte ordonnanceur (sched_init) / scheduler ctx */
    CHECK(mm_leak_count() == 1);
}
