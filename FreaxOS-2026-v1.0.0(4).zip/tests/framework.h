/*
 * FreaxOS 2026 - tests/framework.h
 * Micro-cadre de tests / Tiny test framework (hébergé uniquement).
 */
#ifndef FREAX_TEST_FRAMEWORK_H
#define FREAX_TEST_FRAMEWORK_H

#include <stdio.h>

/* compteurs globaux (définis dans test_main.c) / global counters */
extern int g_pass, g_fail;

#define CHECK(cond)                                                        \
    do {                                                                   \
        if (cond) {                                                        \
            g_pass++;                                                      \
        } else {                                                           \
            g_fail++;                                                      \
            printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);       \
        }                                                                  \
    } while (0)

#define RUN_SUITE(name)                                                    \
    do {                                                                   \
        printf("\n== suite %s ==\n", #name);                               \
        int before_fail = g_fail;                                          \
        suite_##name();                                                    \
        printf("   -> %s\n", (g_fail == before_fail) ? "OK" : "FAILED");   \
    } while (0)

/* réinitialisation complète du noyau / full kernel reset between tests */
void test_reset_kernel(void);
/* console capturée (renvoyée à chaque appel) / captured console output */
const char *test_capture(void);
void test_start_capture(void);

#endif /* FREAX_TEST_FRAMEWORK_H */
