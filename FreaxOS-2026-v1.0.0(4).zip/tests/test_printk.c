/*
 * FreaxOS 2026 - tests/test_printk.c
 * Tests formatage printk / printk formatting tests.
 */
#include "framework.h"
#include "freax/printk.h"
#include "freax/libc.h"

#include <string.h>

void suite_printk(void)
{
    test_reset_kernel();

    struct {
        const char *fmt;
        const char *want;
    } cases[] = {
        { "simple",                       "simple" },
        { "%d",                           "-42" },
        { "%u",                           "42" },
        { "%x",                           "deadbeef" },
        { "%X",                           "DEADBEEF" },
        { "%08x",                         "00001337" },
        { "%5d",                          "   42" },
        { "%-5d|",                        "42   |" },
        { "%05d",                         "00042" },
        { "%s",                           "texte" },
        { "%c%c",                         "ab" },
        { "100%%",                        "100%" },
        { "%d %d",                        "-1 2" },
        { "%x %x",                        "ff 100" },
    };

    /* Évaluation précise via freax_snprintf (même moteur que printk) /
       Precise evaluation via freax_snprintf (same engine as printk) */
    for (unsigned i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
        char out[64];
        int n = -1;
        if (strcmp(cases[i].fmt, "%d") == 0)
            n = freax_snprintf(out, sizeof(out), "%d", -42);
        else if (strcmp(cases[i].fmt, "%u") == 0)
            n = freax_snprintf(out, sizeof(out), "%u", 42u);
        else if (strcmp(cases[i].fmt, "%x") == 0)
            n = freax_snprintf(out, sizeof(out), "%x", 0xdeadbeefu);
        else if (strcmp(cases[i].fmt, "%X") == 0)
            n = freax_snprintf(out, sizeof(out), "%X", 0xdeadbeefu);
        else if (strcmp(cases[i].fmt, "%08x") == 0)
            n = freax_snprintf(out, sizeof(out), "%08x", 0x1337u);
        else if (strcmp(cases[i].fmt, "%5d") == 0)
            n = freax_snprintf(out, sizeof(out), "%5d", 42);
        else if (strcmp(cases[i].fmt, "%-5d|") == 0)
            n = freax_snprintf(out, sizeof(out), "%-5d|", 42);
        else if (strcmp(cases[i].fmt, "%05d") == 0)
            n = freax_snprintf(out, sizeof(out), "%05d", 42);
        else if (strcmp(cases[i].fmt, "%s") == 0)
            n = freax_snprintf(out, sizeof(out), "%s", "texte");
        else if (strcmp(cases[i].fmt, "%c%c") == 0)
            n = freax_snprintf(out, sizeof(out), "%c%c", 'a', 'b');
        else if (strcmp(cases[i].fmt, "100%%") == 0)
            n = freax_snprintf(out, sizeof(out), "100%%");
        else if (strcmp(cases[i].fmt, "%d %d") == 0)
            n = freax_snprintf(out, sizeof(out), "%d %d", -1, 2);
        else if (strcmp(cases[i].fmt, "%x %x") == 0)
            n = freax_snprintf(out, sizeof(out), "%x %x", 255u, 256u);
        else
            n = freax_snprintf(out, sizeof(out), "%s", cases[i].fmt);
        CHECK(n >= 0);
        CHECK(strcmp(out, cases[i].want) == 0);
    }

    /* troncature sûre / safe truncation */
    char small[8];
    int n = freax_snprintf(small, (int)sizeof(small), "%s", "chaine-longue-de-test");
    CHECK(n > 0);
    CHECK(strlen(small) == 7);              /* cap-1 chars + NUL */
    CHECK(small[7] == '\0');

    /* printk → capture (fin de chaîne) / printk lands in the capture */
    test_start_capture();
    printk("printk-%d-%s", 26, "ok");
    CHECK(strstr(test_capture(), "printk-26-ok") != NULL);

    /* %p est imprimé / %p prints something */
    char pbuf[32];
    freax_snprintf(pbuf, sizeof(pbuf), "%p", (void *)0x1234);
    CHECK(strncmp(pbuf, "0x", 2) == 0);

    /* klog a capturé le flux / klog captured the stream */
    static char klog[8192];
    int kn = klog_read(klog, (int)sizeof(klog) - 1);
    CHECK(kn > 0);
    klog[kn > 0 ? kn : 0] = '\0';
    CHECK(strstr(klog, "printk-26-ok") != NULL);
}
