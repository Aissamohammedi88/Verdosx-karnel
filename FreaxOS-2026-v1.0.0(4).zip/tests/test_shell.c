/*
 * FreaxOS 2026 - tests/test_shell.c
 * Tests shell (tokenisation, commandes, eggs) / shell tests.
 */
#include "framework.h"
#include "freax/shell.h"
#include "freax/vfs.h"
#include "freax/sched.h"
#include "freax/mm.h"
#include "freax/config.h"
#include "freax/libc.h"

#include <string.h>

static void exec(const char *line)
{
    char buf[256];
    strncpy(buf, line, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    shell_exec_line(buf);
}

static void expect_capture_contains(const char *needle)
{
    if (strstr(test_capture(), needle) == NULL) {
        g_fail++;
        printf("  FAIL %s:%d  capture ne contient pas / missing: '%s'\n",
               __FILE__, __LINE__, needle);
    } else {
        g_pass++;
    }
}

void suite_shell(void)
{
    test_reset_kernel();

    /* commande inconnue / unknown command */
    exec("pas_de_commande_xyz");
    expect_capture_contains("commande inconnue");
    expect_capture_contains("pas_de_commande_xyz");

    /* help non vide et structuré / help is populated */
    exec("help");
    expect_capture_contains("Commandes / Commands");
    expect_capture_contains("ls");
    expect_capture_contains("crc32");

    /* help ciblé / targeted help */
    test_start_capture();
    exec("help cat");
    expect_capture_contains("cat");

    /* version / version */
    test_start_capture();
    exec("version");
    expect_capture_contains(FREAX_RELEASE);
    expect_capture_contains("Linux 0.12");

    /* echo + tokenisation avec guillemets / echo + quoted tokens */
    test_start_capture();
    exec("echo un deux trois");
    expect_capture_contains("un deux trois");
    test_start_capture();
    exec("echo \"un  deux\"    trois");
    expect_capture_contains("un  deux trois");

    /* pwd / cd / ls / cd flow */
    test_start_capture();
    exec("pwd");
    expect_capture_contains("/");
    exec("mkdir /mon_dossier");
    exec("cd /mon_dossier");
    test_start_capture();
    exec("pwd");
    expect_capture_contains("/mon_dossier");
    exec("touch note.txt");
    test_start_capture();
    exec("ls");
    expect_capture_contains("note.txt");
    exec("cd /");

    /* write + cat */
    test_start_capture();
    exec("write /mon_dossier/note.txt kit 1992 -> 2026");
    exec("cat /mon_dossier/note.txt");
    expect_capture_contains("kit 1992 -> 2026");

    /* mkdir + rm */
    test_start_capture();
    exec("rm /mon_dossier/note.txt");
    exec("cat /mon_dossier/note.txt");
    expect_capture_contains("introuvable / not found");

    /* procfs via cat */
    test_start_capture();
    exec("cat /proc/version");
    expect_capture_contains("FreaxOS");

    /* crc32 : vecteur standard / standard test vector */
    test_start_capture();
    exec("crc32 123456789");
    expect_capture_contains("cbf43926");   /* IEEE CRC32("123456789") */

    /* crc32 d'un fichier / crc32 of a file */
    test_start_capture();
    exec("crc32 /etc/freax-release");
    expect_capture_contains("crc32(\"/etc/freax-release\") = 0x");

    /* tux renvoie l'art + crédit / tux prints art + credit */
    test_start_capture();
    exec("tux");
    expect_capture_contains("TUX");
    expect_capture_contains("Larry Ewing");

    /* easter eggs historiques / history eggs */
    test_start_capture();
    exec("justforfun");
    expect_capture_contains("just a hobby");
    test_start_capture();
    exec("tanenbaum");
    expect_capture_contains("monolithic");
    test_start_capture();
    exec("freax");
    expect_capture_contains("Ari Lemmke");
    test_start_capture();
    exec("v012");
    expect_capture_contains("GPL");

    /* uptime + mem + ps s'exécutent sans erreur / run without crashing */
    test_start_capture();
    exec("uptime");
    exec("mem");
    exec("ps");
    exec("sysinfo");
    expect_capture_contains("Heap");

    /* license */
    test_start_capture();
    exec("license");
    expect_capture_contains("GPL v2");

    /* demo : nécessite un contexte de tâche — dans le harnais, spawn direct */
    int pd = sched_spawn("demo-run", shell_task, 0);
    CHECK(pd > 0);                       /* la tâche shell démarre bien */
    sched_run(50);                       /* quelques tours, sans finir */

    CHECK(mm_check() == 0);
}
