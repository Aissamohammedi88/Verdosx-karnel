/*
 * FreaxOS 2026 - tests/test_sched.c
 * Tests ordonnanceur round-robin / round-robin scheduler tests.
 */
#include "framework.h"
#include "freax/sched.h"
#include "freax/mm.h"

#define DEMO_STEPS 10
static volatile int g_cnt[3];

static void t1(void) { for (int i = 0; i < DEMO_STEPS; i++) { g_cnt[0]++; sched_yield(); } }
static void t2(void) { for (int i = 0; i < DEMO_STEPS; i++) { g_cnt[1]++; sched_yield(); } }
static void t3(void) { for (int i = 0; i < DEMO_STEPS; i++) { g_cnt[2]++; sched_yield(); } }

static void t_quick(void)
{
    sched_yield();
    /* task_exit implicite via trampoline (code 0) / implicit exit code 0 */
}

static void t_exit7(void)
{
    task_exit(7);
}

void suite_sched(void)
{
    test_reset_kernel();

    /* pid de départ / starting pid */
    CHECK(sched_current_pid() == 0);   /* hors tâche / no task context yet */

    int p1 = sched_spawn("t1", t1, 0);
    int p2 = sched_spawn("t2", t2, 0);
    int p3 = sched_spawn("t3", t3, 0);
    CHECK(p1 > 0);
    CHECK(p2 == p1 + 1);
    CHECK(p3 == p2 + 1);               /* pids séquentiels / sequential pids */
    CHECK(sched_task_count() == 3);

    g_cnt[0] = g_cnt[1] = g_cnt[2] = 0;
    sched_run(4000);                   /* bien assez / plenty of steps */

    CHECK(g_cnt[0] == DEMO_STEPS);
    CHECK(g_cnt[1] == DEMO_STEPS);
    CHECK(g_cnt[2] == DEMO_STEPS);
    CHECK(sched_task_count() == 0);    /* zombies repris / zombies reaped */
    CHECK(mm_check() == 0);            /* piles libérées / stacks freed */

    /* exit code propagé / exit code propagation */
    test_reset_kernel();
    int px = sched_spawn("exit7", t_exit7, 0);
    sched_run(100);
    CHECK(px > 0);

    /* attente bloquante / blocking wait */
    test_reset_kernel();
    int pw = sched_spawn("quick", t_quick, 0);
    int code = -99;
    CHECK(task_wait(pw, &code) == pw);
    CHECK(code == 0);
    CHECK(sched_task_count() == 0);    /* reprise par wait / reaped by wait */

    /* wait sur pid inconnu / wait on unknown pid */
    CHECK(task_wait(9999, &code) == -1);

    /* yield hors tâche : inoffensif / yield outside a task is a no-op */
    sched_yield();
    CHECK(sched_current_pid() == 0);

    /* 8 tâches en parallèle / eight parallel tasks */
    test_reset_kernel();
    int pids[8];
    for (int i = 0; i < 8; i++)
        pids[i] = sched_spawn("multi", t_quick, 0);
    for (int i = 0; i < 8; i++)
        CHECK(pids[i] > 0);
    sched_run(2000);
    CHECK(sched_task_count() == 0);
    CHECK(mm_check() == 0);
}
