/*
 * FreaxOS 2026 - tests/test_main.c
 * Harnais des tests unitaires hébergés / Hosted unit-test harness.
 *
 * FR : Chaque suite repart d'un noyau neuf (mm+vfs+sched réinitialisés) et
 *      capture la console. Objectif : `make test` 100 % vert.
 * EN : Each suite starts from a fresh kernel (mm+vfs+sched reset) with the
 *      console captured. Goal: a fully green `make test`.
 */
#include "framework.h"
#include "freax/kernel.h"
#include "freax/shell.h"
#include "freax/mm.h"
#include "freax/sched.h"
#include "freax/vfs.h"

#include <string.h>
#include <stdlib.h>

/* compteurs partagés des suites / shared suite counters */
int g_pass, g_fail;

#define HEAP_BYTES (4u * 1024u * 1024u)
static char heap[HEAP_BYTES] __attribute__((aligned(16)));
static char capbuf[65536];

void test_start_capture(void)
{
    console_set_capture(capbuf, (int)sizeof(capbuf));
}

const char *test_capture(void)
{
    return capbuf;
}

void test_reset_kernel(void)
{
    kernel_init_subsystems(heap, HEAP_BYTES);
    test_start_capture();
}

/* prototypes des suites / suite prototypes */
void suite_mm(void);
void suite_sched(void);
void suite_vfs(void);
void suite_syscall(void);
void suite_shell(void);
void suite_printk(void);
void suite_cross(void);
void suite_desktop(void);

int main(void)
{
    printf("FreaxOS 2026 — tests unitaires / unit tests\n");

    RUN_SUITE(mm);
    RUN_SUITE(sched);
    RUN_SUITE(vfs);
    RUN_SUITE(syscall);
    RUN_SUITE(shell);
    RUN_SUITE(printk);
    RUN_SUITE(cross);
    RUN_SUITE(desktop);

    printf("\n== bilan / summary : %d OK, %d KO / FAIL ==\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
