/*
 * FreaxOS 2026 - baremetal/i386.h
 * Accès ports + segment descripteur / Port I/O + segment descriptors.
 */
#ifndef FREAX_I386_H
#define FREAX_I386_H

#include "freax/types.h"

static inline void outb(u16 port, u8 val)
{
    __asm__ __volatile__("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline u8 inb(u16 port)
{
    u8 v;
    __asm__ __volatile__("inb %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}

static inline void io_wait(void)
{
    outb(0x80, 0);
}

static inline void cli(void)
{
    __asm__ __volatile__("cli");
}

static inline void sti(void)
{
    __asm__ __volatile__("sti");
}

static inline void hlt(void)
{
    __asm__ __volatile__("hlt");
}

/* Descripteur de segment 8 octets / 8-byte segment descriptor */
static inline u64 gdt_entry(u32 base, u32 limit, u8 access, u8 gran)
{
    u64 d = 0;
    d |= (u64)(limit & 0xFFFF);
    d |= (u64)((base & 0xFFFFFF) << 16);
    d |= (u64)access << 40;
    d |= (u64)((limit >> 16) & 0x0F) << 48;
    d |= (u64)(gran & 0x0F) << 52;
    d |= (u64)(base >> 24) << 56;
    return d;
}

/* Entrée IDT / IDT gate */
struct idt_entry {
    u16 base_lo;
    u16 sel;
    u8  zero;
    u8  flags;
    u16 base_hi;
} __attribute__((packed));

#endif /* FREAX_I386_H */
