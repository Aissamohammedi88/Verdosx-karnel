/*
 * FreaxOS 2026 - baremetal/linker.ld
 * Script d'édition de liens i386 / i386 linker script.
 *
 * FR : Le header multiboot doit être dans les 8 premiers Kio de l'image,
 *      chargée à 1 Mio par GRUB/QEMU.
 * EN : The multiboot header must sit within the first 8 KiB of the image,
 *      loaded at 1 MiB by GRUB/QEMU.
 */
OUTPUT_FORMAT(elf32-i386)
OUTPUT_ARCH(i386)
ENTRY(_start)

SECTIONS
{
    . = 1M;

    .boot : ALIGN(4)
    {
        KEEP(*(.multiboot))
    }

    .text : ALIGN(4K)
    {
        *(.text*)
    }

    .rodata : ALIGN(4K)
    {
        *(.rodata*)
    }

    .data : ALIGN(4K)
    {
        *(.data*)
    }

    .bss : ALIGN(4K)
    {
        *(COMMON)
        *(.bss*)
    }

    . = ALIGN(4K);
    _end = .;

    /DISCARD/ :
    {
        *(.eh_frame*)
        *(.comment*)
        *(.note*)
    }
}
