/*
 * FreaxOS 2026 - baremetal/ctx_i386.c
 * Changement de contexte i386 à la main / Hand-rolled i386 context switch.
 *
 * FR : Convention cdecl : on sauvegarde ebx, ebp, esi, edi et esp, puis le
 *      `ret` final saute sur l'entrée de la tâche. La pile initiale est
 *      préparée pour ces pop.
 * EN : cdecl convention: save ebx, ebp, esi, edi and esp, then the final
 *      `ret` jumps to the task entry. The initial stack is laid out to feed
 *      those pops.
 */
#include "freax/ctx.h"
#include "freax/libc.h"

int ctx_size(void)
{
    return (int)sizeof(struct ctx);
}

int ctx_init(struct ctx *c, void *stack, u32 stack_size, void (*entry)(void))
{
    if (!c || !stack || stack_size < 64)
        return -1;

    /* trame initiale : edi, esi, ebp, ebx, eip / initial frame layout */
    u32 *sp = (u32 *)((u8 *)stack + stack_size);
    *--sp = (u32)entry;             /* eip consommé par ret / consumed by ret */
    *--sp = 0;                      /* ebx */
    *--sp = 0;                      /* ebp */
    *--sp = 0;                      /* esi */
    *--sp = 0;                      /* edi */
    c->esp = (u32)sp;
    return 0;
}

void ctx_switch(struct ctx *from, struct ctx *to)
{
    __asm__ __volatile__(
        "pushl %%ebx\n\t"
        "pushl %%ebp\n\t"
        "pushl %%esi\n\t"
        "pushl %%edi\n\t"
        "movl %%esp, %0\n\t"
        "movl %1, %%esp\n\t"
        "popl %%edi\n\t"
        "popl %%esi\n\t"
        "popl %%ebp\n\t"
        "popl %%ebx\n\t"
        "ret\n\t"
        : "=m"(from->esp)
        : "m"(to->esp)
        : "memory", "cc");
}
