/*
 * FreaxOS 2026 - baremetal/splash.c
 * Splash graphique au boot / graphical boot splash.
 *
 * FR : passe le VGA en mode 13h (320x200, 8 bpp @ 0xA0000) par écritures
 *      directes des registres (aucun BIOS en mode protégé), dessine le visuel
 *      « Liquid Glass » du noyau, attend une touche (ou 4 s), puis remet le
 *      mode texte 03h et rend la main à kmain. Le serial COM1 n'est pas
 *      touché : make smoke continue de fonctionner.
 * EN : switches VGA to mode 13h (320x200, 8bpp @ 0xA0000) by direct register
 *      writes (no BIOS in protected mode), draws the "Liquid Glass" boot
 *      visual, waits for a key (or 4 s), restores text mode 03h and returns
 *      to kmain. COM1 untouched: make smoke keeps working.
 */
#include "freax/types.h"
#include "freax/hal.h"
#include "i386.h"
#include "gfx.h"

static inline void spl_out(u16 port, u8 v) { outb(port, v); }
static inline u8 spl_in(u16 port) { return inb(port); }

/* palette du splash (index DAC) / splash palette (DAC index) */
enum {
    C_BG0, C_BG1, C_BG2, C_BG3, C_BAND, C_ACCENT, C_WHITE, C_DIM,
    C_BAR, C_BARHI, C_TUX, C_BELLY, C_ORANGE, C_KEY, N_SPL_COLORS
};

static const u8 SPL_RGB[N_SPL_COLORS][3] = {
    { 0x07, 0x0B, 0x1C },        /* C_BG0     */
    { 0x0F, 0x0E, 0x29 },        /* C_BG1     */
    { 0x17, 0x10, 0x36 },        /* C_BG2     */
    { 0x1B, 0x10, 0x3B },        /* C_BG3     */
    { 0x22, 0x6C, 0xEE },        /* C_BAND    */
    { 0x22, 0xD3, 0xEE },        /* C_ACCENT  */
    { 0xF0, 0xF4, 0xFC },        /* C_WHITE   */
    { 0x8A, 0x93, 0xAA },        /* C_DIM     */
    { 0x1A, 0x21, 0x38 },        /* C_BAR     */
    { 0x3A, 0x46, 0x68 },        /* C_BARHI   */
    { 0x14, 0x14, 0x1E },        /* C_TUX     */
    { 0xEF, 0xF2, 0xFA },        /* C_BELLY   */
    { 0xFF, 0xAA, 0x3C },        /* C_ORANGE  */
    { 0x55, 0xE0, 0xA0 },        /* C_KEY     */
};

#define SPL_W 320
#define SPL_H 200
static u8 *const FB = (u8 *)0xA0000;

static void spl_px(int x, int y, int c)
{
    if (x < 0 || y < 0 || x >= SPL_W || y >= SPL_H)
        return;
    FB[SPL_W * y + x] = (u8)c;
}

static void spl_hline(int x0, int x1, int y, int c)
{
    for (int x = x0; x <= x1; x++)
        spl_px(x, y, c);
}

static void spl_rect(int x0, int y0, int x1, int y1, int c)
{
    for (int y = y0; y <= y1; y++)
        spl_hline(x0, x1, y, c);
}

/* glyphe 9x16 partagé avec le bureau / shared 9x16 glyph */
int font_lookup(int cp, const unsigned short **rows);

static void spl_text(int x, int y, const char *s, int color, int scale)
{
    while (*s) {
        int cp = (unsigned char)*s;
        if (cp >= 0xC0 && *s) {
            /* UTF-8 2 octets / 2-byte UTF-8 */
            if ((cp & 0xE0) == 0xC0 && s[1]) {
                cp = ((cp & 0x1F) << 6) | (s[1] & 0x3F);
                s += 2;
            } else {
                s++;
            }
        } else {
            s++;
        }
        const unsigned short *rows;
        if (!font_lookup(cp, &rows)) {
            x += 9 * scale;
            continue;
        }
        for (int ry = 0; ry < 16; ry++) {
            u16 bits = rows[ry];
            for (int rx = 0; rx < 9; rx++)
                if (bits & (1u << rx))
                    for (int sy = 0; sy < scale; sy++)
                        for (int sx = 0; sx < scale; sx++)
                            spl_px(x + rx * scale + sx, y + ry * scale + sy,
                                   color);
        }
        x += 9 * scale;
    }
}

static int spl_text_w(const char *s, int scale)
{
    int n = 0;
    for (const char *p = s; *p; p++)
        n++;
    return n * 9 * scale;
}

/* dessin du visuel / visual drawing */
static void spl_draw(void)
{
    /* fond dégradé + bandes aurora / gradient + aurora bands */
    for (int y = 0; y < SPL_H; y++) {
        int c = y < 60 ? C_BG0 : (y < 110 ? C_BG1 : (y < 160 ? C_BG2 : C_BG3));
        spl_hline(0, SPL_W - 1, y, c);
    }
    for (int y = 0; y < SPL_H; y += 7) {
        int off = (y / 7) % 5;
        spl_hline(off * 4, off * 4 + 210, y, C_BAND);
    }
    /* étoiles / stars */
    for (int i = 0; i < 60; i++) {
        int x = (i * 71 + 23) % SPL_W;
        int y = (i * 37 + 11) % 170;
        spl_px(x, y, i % 3 ? C_BG2 : C_WHITE);
    }
    /* mini Tux / mini Tux */
    for (int dy = -14; dy <= 14; dy++)
        for (int dx = -9; dx <= 9; dx++)
            if (dx * dx / 4 + dy * dy <= 196)
                spl_px(36 + dx, 96 + dy, C_TUX);
    for (int dy = 0; dy <= 10; dy++)
        for (int dx = -6; dx <= 6; dx++)
            if (dx * dx + dy * dy <= 52)
                spl_px(36 + dx, 100 + dy, C_BELLY);
    spl_px(32, 88, C_BELLY);
    spl_px(40, 88, C_BELLY);
    spl_rect(32, 102, 40, 104, C_ORANGE);
    spl_rect(29, 106, 43, 107, C_ORANGE);
    /* titre / title */
    spl_text((SPL_W - spl_text_w("FreaxOS", 3)) / 2 + 34, 42, "FreaxOS",
             C_WHITE, 3);
    spl_text((SPL_W - spl_text_w("2026", 3)) / 2 + 34, 96, "2026",
             C_ACCENT, 3);
    spl_text(58, 128, "v1.0.0-freax  —  Liquid Glass", C_ACCENT, 1);
    spl_text(58, 144, "kernel 0.12 spirit, desktop edition", C_DIM, 1);
    spl_text(58, 158, "noyau 0.12 + bureau, edition 2026", C_DIM, 1);
    /* barre liquid glass / liquid glass bar */
    spl_rect(6, 180, SPL_W - 7, 193, C_BAR);
    spl_hline(6, SPL_W - 7, 180, C_BARHI);
    spl_hline(6, SPL_W - 7, 193, C_BARHI);
    spl_rect(12, 184, 22, 189, C_ACCENT);
    spl_rect(26, 183, 30, 190, C_BARHI);
    spl_text(36, 184, "terminal   files   browser   store", C_DIM, 1);
    spl_text((SPL_W - spl_text_w("QEMU — appuyez sur une touche / press any "
                                 "key", 1)) / 2, 196, "QEMU — appuyez sur "
             "une touche / press any key", C_KEY, 1);
}

/* passage en mode 13h / enter mode 13h */
static void spl_mode13(void)
{
    spl_out(0x3C2, 0x63);
    spl_out(0x3C4, 0x00); spl_out(0x3C5, 0x01);      /* reset sync */
    spl_out(0x3C4, 0x01); spl_out(0x3C5, 0x01);
    spl_out(0x3C4, 0x02); spl_out(0x3C5, 0x0F);
    spl_out(0x3C4, 0x03); spl_out(0x3C5, 0x00);
    spl_out(0x3C4, 0x04); spl_out(0x3C5, 0x0E);      /* chain4 */
    spl_out(0x3C4, 0x00); spl_out(0x3C5, 0x03);
    spl_out(0x3D4, 0x11); spl_out(0x3D5, 0x00);      /* unlock CRTC */
    static const u8 crtc[25] = {
        0x5F, 0x3F, 0x40, 0x82, 0x55, 0x81, 0xBF, 0x1F, 0x00, 0x4F, 0x0D,
        0x0E, 0x00, 0x00, 0x00, 0x00, 0x9C, 0x8E, 0x8F, 0x28, 0x40, 0x96,
        0xB9, 0xE3, 0xFF
    };
    for (int i = 0; i < 25; i++) {
        spl_out(0x3D4, (u8)i);
        spl_out(0x3D5, crtc[i]);
    }
    static const u8 gc[9] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x0E,
                              0x0F, 0xFF };
    for (int i = 0; i < 9; i++) {
        spl_out(0x3CE, (u8)i);
        spl_out(0x3CF, gc[i]);
    }
    (void)spl_in(0x3DA);                             /* reset flip-flop */
    for (int i = 0; i < 16; i++) {
        spl_out(0x3C0, (u8)i);
        spl_out(0x3C0, (u8)i);
    }
    spl_out(0x3C0, 0x10); spl_out(0x3C0, 0x41);
    spl_out(0x3C0, 0x12); spl_out(0x3C0, 0x0F);
    spl_out(0x3C0, 0x13); spl_out(0x3C0, 0x00);
    spl_out(0x3C0, 0x14); spl_out(0x3C0, 0x00);
    (void)spl_in(0x3DA);
    spl_out(0x3C0, 0x20);                            /* vidéo ON / video on */
    /* DAC / palette */
    for (int i = 0; i < N_SPL_COLORS; i++) {
        spl_out(0x3C8, (u8)i);
        spl_out(0x3C9, SPL_RGB[i][0] >> 2);
        spl_out(0x3C9, SPL_RGB[i][1] >> 2);
        spl_out(0x3C9, SPL_RGB[i][2] >> 2);
    }
}

/* retour mode texte 03h / back to text mode 03h */
static void spl_mode3(void)
{
    spl_out(0x3C2, 0x67);
    spl_out(0x3C4, 0x00); spl_out(0x3C5, 0x01);
    spl_out(0x3C4, 0x01); spl_out(0x3C5, 0x00);
    spl_out(0x3C4, 0x02); spl_out(0x3C5, 0x03);
    spl_out(0x3C4, 0x03); spl_out(0x3C5, 0x00);
    spl_out(0x3C4, 0x04); spl_out(0x3C5, 0x02);
    spl_out(0x3C4, 0x00); spl_out(0x3C5, 0x03);
    spl_out(0x3D4, 0x11); spl_out(0x3D5, 0x00);
    static const u8 crtc[25] = {
        0x5F, 0x4F, 0x50, 0x82, 0x55, 0x81, 0xBF, 0x1F, 0x00, 0x4F, 0x0D,
        0x0E, 0x00, 0x00, 0x00, 0x00, 0x9C, 0x8E, 0x8F, 0x28, 0x1F, 0x96,
        0xB9, 0xA3, 0xFF
    };
    for (int i = 0; i < 25; i++) {
        spl_out(0x3D4, (u8)i);
        spl_out(0x3D5, crtc[i]);
    }
    static const u8 gc[9] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x0E,
                              0x0F, 0xFF };
    for (int i = 0; i < 9; i++) {
        spl_out(0x3CE, (u8)i);
        spl_out(0x3CF, gc[i]);
    }
    (void)spl_in(0x3DA);
    for (int i = 0; i < 16; i++) {
        spl_out(0x3C0, (u8)i);
        spl_out(0x3C0, (u8)i);
    }
    spl_out(0x3C0, 0x10); spl_out(0x3C0, 0x0C);
    spl_out(0x3C0, 0x12); spl_out(0x3C0, 0x0F);
    spl_out(0x3C0, 0x13); spl_out(0x3C0, 0x00);
    spl_out(0x3C0, 0x14); spl_out(0x3C0, 0x00);
    (void)spl_in(0x3DA);
    spl_out(0x3C0, 0x20);
    for (int i = 0; i < 16; i++) {                   /* palette texte / text */
        spl_out(0x3C8, (u8)i);
        u8 r = (i & 1) ? 0x2A : 0x00;
        u8 g = (i & 2) ? 0x2A : 0x00;
        u8 b = (i & 4) ? 0x2A : 0x00;
        if (i >= 8) { r += 0x15; g += 0x15; b += 0x15; }
        if (i == 6) r += 0x15;
        spl_out(0x3C9, r >> 2);
        spl_out(0x3C9, g >> 2);
        spl_out(0x3C9, b >> 2);
    }
}

/* attend une touche ou 400 ticks / wait key or 400 ticks (4 s) */
static void spl_wait(void)
{
    u32 start = g_hal->ticks();
    for (;;) {
        if (spl_in(0x64) & 1) {
            (void)spl_in(0x60);
            return;
        }
        if (g_hal->ticks() - start >= 400)
            return;
    }
}

void splash_show(void)
{
    spl_mode13();
    spl_draw();
    spl_wait();
    spl_mode3();
}
