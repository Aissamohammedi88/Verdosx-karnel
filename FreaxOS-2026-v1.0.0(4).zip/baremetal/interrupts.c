/*
 * FreaxOS 2026 - baremetal/interrupts.c
 * GDT, IDT, PIC, gestionnaire C des interruptions / GDT, IDT, PIC, C handler.
 *
 * FR : Le PIC est remappé sur les vecteurs 32-47 (IRQ0 = PIT, IRQ1 = clavier).
 *      Les exceptions déclenchent kpanic. Les IRQ inattendues sont acquittées
 *      (spurious) et ignorées.
 * EN : The PIC is remapped to vectors 32-47 (IRQ0 = PIT, IRQ1 = keyboard).
 *      Exceptions call kpanic. Unexpected IRQs are acked (spurious) & ignored.
 */
#include "freax/printk.h"
#include "freax/config.h"
#include "i386.h"

extern void *isr_stub_table[48];

static struct idt_entry g_idt[256];
static u64 g_gdt[3];
static u16 volatile g_pic_mask = 0xFFFF;

struct regs {
    u32 edi, esi, ebp, esp_orig, ebx, edx, ecx, eax; /* pusha (ordre memoire) */
    u32 intno, errcode, eip, cs, eflags;
};

static void idt_set(int n, void (*handler)(void), u8 flags)
{
    u32 addr = (u32)handler;
    g_idt[n].base_lo = (u16)(addr & 0xFFFF);
    g_idt[n].sel = 0x08;
    g_idt[n].zero = 0;
    g_idt[n].flags = flags;
    g_idt[n].base_hi = (u16)((addr >> 16) & 0xFFFF);
}

static void gdt_install(void)
{
    g_gdt[0] = 0;
    g_gdt[1] = gdt_entry(0, 0xFFFFFFFF, 0x9A, 0xCF); /* code 0x08 */
    g_gdt[2] = gdt_entry(0, 0xFFFFFFFF, 0x92, 0xCF); /* data 0x10 */

    struct {
        u16 limit;
        u32 base;
    } __attribute__((packed)) gdtr = {
        sizeof(g_gdt) - 1,
        (u32)g_gdt,
    };

    __asm__ __volatile__(
        "lgdt %0\n\t"
        "movw $0x10, %%ax\n\t"
        "movw %%ax, %%ds\n\t"
        "movw %%ax, %%es\n\t"
        "movw %%ax, %%fs\n\t"
        "movw %%ax, %%gs\n\t"
        "movw %%ax, %%ss\n\t"
        "ljmp $0x08, $1f\n\t"
        "1:\n\t"
        :
        : "m"(gdtr)
        : "ax", "memory");
}

static void pic_remap(void)
{
    outb(0x20, 0x11); io_wait();      /* ICW1 : cascade / init */
    outb(0xA0, 0x11); io_wait();
    outb(0x21, 0x20); io_wait();      /* ICW2 : offset 0x20 / master offset */
    outb(0xA1, 0x28); io_wait();      /* ICW2 : offset 0x28 / slave offset  */
    outb(0x21, 0x04); io_wait();      /* ICW3                               */
    outb(0xA1, 0x02); io_wait();
    outb(0x21, 0x01); io_wait();      /* ICW4 : 8086 mode                   */
    outb(0xA1, 0x01); io_wait();
    outb(0x21, 0xFF);                 /* tout masqué pour l'instant / mask all */
    outb(0xA1, 0xFF);
}

static void pic_mask_clear(u8 irq)
{
    u16 port = (irq < 8) ? 0x21 : 0xA1;
    u8 bit = (u8)(1u << (irq & 7));
    u8 val = inb(port) & (u8)~bit;
    outb(port, val);
}

void pic_send_eoi(int intno)
{
    if (intno >= 40)
        outb(0xA0, 0x20);
    if (intno >= 32)
        outb(0x20, 0x20);
}

/* Hooks fournis par hal_i386.c / implemented in hal_i386.c */
void irq_timer_tick(void);
void irq_keyboard_scancode(u8 sc);

void isr_handler(u32 *frame)
{
    struct regs *r = (struct regs *)frame;
    int intno = (int)r->intno;

    if (intno < 32) {
        kpanic("exception CPU %d, errcode=%u, eip=%p",
               intno, r->errcode, (void *)(freax_uptr)r->eip);
        return;
    }
    switch (intno) {
    case 32:                        /* IRQ0 : timer */
        irq_timer_tick();
        break;
    case 33:                        /* IRQ1 : clavier / keyboard */
        irq_keyboard_scancode(inb(0x60));
        break;
    default:
        break;                      /* spurious : ack seulement / ack only */
    }
    pic_send_eoi(intno);
}

void interrupts_install(void)
{
    gdt_install();
    pic_remap();

    for (int i = 0; i < 48; i++)
        idt_set(i, isr_stub_table[i], 0x8E); /* present, ring0, 32-bit gate */
    for (int i = 48; i < 256; i++)
        g_idt[i].flags = 0;                  /* non présent / not present */

    struct {
        u16 limit;
        u32 base;
    } __attribute__((packed)) idtr = {
        sizeof(g_idt) - 1,
        (u32)g_idt,
    };
    __asm__ __volatile__("lidt %0" : : "m"(idtr) : "memory");

    pic_mask_clear(0);            /* IRQ0 PIT */
    pic_mask_clear(1);            /* IRQ1 clavier / keyboard */
    (void)g_pic_mask;
}
