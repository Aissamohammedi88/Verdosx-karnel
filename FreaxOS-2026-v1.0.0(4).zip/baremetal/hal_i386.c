/*
 * FreaxOS 2026 - baremetal/hal_i386.c
 * HAL bare-metal : VGA, clavier PS/2, PIT, série / VGA, PS/2 kbd, PIT, serial.
 *
 * FR : Sortie console = VGA texte 80x25 + port série COM1 + port debug 0xE9
 *      (pratique avec `qemu -serial stdio`). Le pilote VGA décode les séquences
 *      ANSI (couleurs) et translittère les accents UTF-8 vers CP437.
 * EN : Console output = 80x25 VGA text + COM1 serial + debug port 0xE9
 *      (handy with `qemu -serial stdio`). The VGA driver parses ANSI color
 *      sequences and transliterates UTF-8 accents to CP437.
 */
#include "freax/hal.h"
#include "freax/printk.h"
#include "freax/config.h"
#include "freax/libc.h"
#include "i386.h"

static const char *hal_platform = "i386 baremetal";

/* ---- VGA ---- */

#define VGA_W 80
#define VGA_H 25
static u8 *volatile g_vga = (u8 *)0xB8000;
static int g_row, g_col;
static u8 g_color = 0x07;

static void vga_scroll(void)
{
    memmove((void *)g_vga, (void *)(g_vga + 2 * VGA_W),
            (freax_size)(2 * VGA_W * (VGA_H - 1)));
    for (int i = 0; i < VGA_W; i++) {
        g_vga[2 * ((VGA_H - 1) * VGA_W + i)] = ' ';
        g_vga[2 * ((VGA_H - 1) * VGA_W + i) + 1] = g_color;
    }
}

static void vga_cursor(void)
{
    u16 pos = (u16)(g_row * VGA_W + g_col);
    outb(0x3D4, 0x0F);
    outb(0x3D5, (u8)(pos & 0xFF));
    outb(0x3D4, 0x0E);
    outb(0x3D5, (u8)(pos >> 8));
}

static int g_esc;       /* séquence ANSI en cours / ANSI sequence in flight */

static void vga_putc(char c)
{
    if (g_esc) {
        if ((c >= '@' && c <= '~') || c == 'm')
            g_esc = 0;          /* fin de séquence / sequence end */
        return;
    }
    switch ((u8)c) {
    case 0x1B:
        g_esc = 1;
        return;
    case '\n':
        g_col = 0;
        g_row++;
        break;
    case '\r':
        g_col = 0;
        break;
    case '\b':
        if (g_col > 0)
            g_col--;
        g_vga[2 * (g_row * VGA_W + g_col)] = ' ';
        break;
    case '\t':
        do {
            vga_putc(' ');
        } while (g_col % 4);
        return;
    default: {
        /* UTF-8 accents -> CP437 / transliteration */
        static int utf8_next;
        u8 glyph = (u8)c;
        if (utf8_next) {
            switch (glyph) {
            case 0xA9: case 0x89: glyph = 0x82; break; /* é É */
            case 0xA8: case 0x88: glyph = 0x85; break; /* è È */
            case 0xA0: case 0x80: glyph = 0x85; break; /* à À */
            case 0xA7: case 0x87: glyph = 0x87; break; /* ç Ç */
            case 0xAA: case 0x8A: glyph = 0x88; break; /* ê Ê */
            case 0xB4: case 0x94: glyph = 0x93; break; /* ô Ô */
            case 0xB9: case 0x99: glyph = 0x97; break; /* ù Ù */
            case 0xAB: glyph = 0xAE; break;            /* « */
            case 0xBB: glyph = 0xAF; break;            /* » */
            default:  glyph = '?';  break;
            }
            utf8_next = 0;
        } else if ((u8)c == 0xC3 || (u8)c == 0xC2) {
            utf8_next = 1;
            return;
        } else if ((u8)c >= 0x80) {
            glyph = '?';
        }
        if (g_col >= VGA_W) {
            g_col = 0;
            g_row++;
        }
        if (g_row >= VGA_H) {
            vga_scroll();
            g_row = VGA_H - 1;
        }
        int idx = g_row * VGA_W + g_col;
        g_vga[2 * idx] = glyph;
        g_vga[2 * idx + 1] = g_color;
        g_col++;
        break;
    }
    }
    vga_cursor();
}

static void vga_clear(void)
{
    for (int i = 0; i < VGA_W * VGA_H; i++) {
        g_vga[2 * i] = ' ';
        g_vga[2 * i + 1] = 0x07;
    }
    g_row = g_col = 0;
    vga_cursor();
}

/* ---- série COM1 / COM1 serial ---- */

static int serial_ok;

static void serial_init(void)
{
    outb(0x3F8 + 1, 0x00);          /* irq off          */
    outb(0x3F8 + 3, 0x80);          /* DLAB on          */
    outb(0x3F8 + 0, 0x03);          /* 38400 baud       */
    outb(0x3F8 + 1, 0x00);
    outb(0x3F8 + 3, 0x03);          /* 8N1              */
    outb(0x3F8 + 2, 0xC7);
    outb(0x3F8 + 4, 0x0B);
    serial_ok = 1;
}

static void serial_putc(char c)
{
    if (!serial_ok)
        return;
    if (c == '\n')
        serial_putc('\r');
    while (!(inb(0x3F8 + 5) & 0x20))
        ;
    outb(0x3F8, (u8)c);
}

/* ---- clavier PS/2 / PS/2 keyboard ---- */

static u8  g_kbd_ring[128];
static u8 volatile g_kbd_head, g_kbd_tail;
static int g_kbd_shift;
static int g_kbd_ext;               /* touche étendue / extended key */

static const char kbd_map[128] = {
    0,   0,   '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
    '-', '=', '\b', '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i',
    'o', 'p', '[', ']', '\n', 0, 'a', 's', 'd', 'f', 'g', 'h',
    'j', 'k', 'l', ';', '\'', '`', 0, '\\', 'z', 'x', 'c', 'v',
    'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' ', 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static const char kbd_map_shift[128] = {
    0,   0,   '!', '@', '#', '$', '%', '^', '&', '*', '(', ')',
    '_', '+', '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I',
    'O', 'P', '{', '}', '\n', 0, 'A', 'S', 'D', 'F', 'G', 'H',
    'J', 'K', 'L', ':', '"', '~', 0, '|', 'Z', 'X', 'C', 'V',
    'B', 'N', 'M', '<', '>', '?', 0, '*', 0, ' ', 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

void irq_keyboard_scancode(u8 sc)
{
    if (sc == 0xE0) {               /* préfixe étendu / extended prefix */
        g_kbd_ext = 1;
        return;
    }
    if (g_kbd_ext) {
        g_kbd_ext = 0;
        return;                     /* flèches etc. ignorées / arrows ignored */
    }
    if (sc & 0x80) {                /* relâchement / release */
        sc &= 0x7F;
        if (sc == 0x2A || sc == 0x36)
            g_kbd_shift = 0;
        return;
    }
    if (sc == 0x2A || sc == 0x36) {
        g_kbd_shift = 1;
        return;
    }
    char c = g_kbd_shift ? kbd_map_shift[sc & 0x7F] : kbd_map[sc & 0x7F];
    if (c) {
        u8 next = (u8)((g_kbd_head + 1) & 127);
        if (next != g_kbd_tail) {
            g_kbd_ring[g_kbd_head] = (u8)c;
            g_kbd_head = next;
        }
    }
}

/* ---- PIT / timer ---- */

static u32 volatile g_ticks;

void irq_timer_tick(void)
{
    g_ticks++;
}

/* ---- console / shutdown ---- */

static void hal_putc(char c)
{
    vga_putc(c);
    serial_putc(c);
    outb(0xE9, (u8)c);              /* port debug QEMU / QEMU debug port */
}

static int hal_getc(void)
{
    if (g_kbd_tail == g_kbd_head)
        return -1;
    u8 c = g_kbd_ring[g_kbd_tail];
    g_kbd_tail = (u8)((g_kbd_tail + 1) & 127);
    return (int)c;
}

static u32 hal_ticks(void)
{
    return g_ticks;
}

static void hal_idle(void)
{
    sti();
    hlt();                          /* dort jusqu'à une IRQ / sleep until IRQ */
}

static void hal_shutdown(int reboot)
{
    if (reboot) {
        outb(0x64, 0xFE);           /* pulsation reset 8042 / 8042 reset pulse */
        for (;;) {
            cli();
            hlt();
        }
    }
    printk("\n*** FreaxOS halte / halted ***\n");
    outb(0xF4, 0x00);               /* isa-debug-exit QEMU / QEMU exit device */
    for (;;) {
        cli();
        hlt();
    }
}

static struct hal g_hal_i386 = {
    .putc     = hal_putc,
    .getc     = hal_getc,
    .ticks    = hal_ticks,
    .idle     = hal_idle,
    .shutdown = hal_shutdown,
};

void pit_init(void)
{
    u32 div = 1193182u / FREAX_TICK_HZ;
    outb(0x43, 0x36);               /* square wave, lo/hi / onde carrée       */
    outb(0x40, (u8)(div & 0xFF));
    outb(0x40, (u8)((div >> 8) & 0xFF));
}

void hal_i386_install(void)
{
    g_hal = &g_hal_i386;
    g_hal_platform = hal_platform;
    vga_clear();
    serial_init();
}
