/*
 * FreaxOS 2026 - baremetal/boot.S (GNU as, AT&T syntax, i386)
 * Amorce multiboot / Multiboot bootstrap.
 *
 * FR : Entrée du noyau. GRUB/QEMU -kernel charge l'ELF à 1 Mio avec le
 *      magic 0x1BADB002 ; on prépare la pile puis on appelle kmain(magic, mbi).
 * EN : Kernel entry. GRUB/QEMU -kernel loads the ELF at 1 MiB with magic
 *      0x1BADB002; we set up a stack then call kmain(magic, mbi).
 */
.set MB_MAGIC, 0x1BADB002
.set MB_FLAGS, (1 << 0) | (1 << 1)   /* ALIGN | MEMINFO */

.section .multiboot, "a"
.align 4
mb_header:
    .long MB_MAGIC
    .long MB_FLAGS
    .long -(MB_MAGIC + MB_FLAGS)     /* checksum */

.section .bss
.align 16
mb_stack_bottom:
    .space 16384                     /* pile noyau / kernel stack */
mb_stack_top:

.section .note.GNU-stack, "", @progbits

.section .text
.global _start
.type _start, @function
_start:
    cli
    cld
    movl $mb_stack_top, %esp
    pushl %ebx                       /* mbi (2e arg) / mbi (2nd arg) */
    pushl %eax                       /* magic (1er arg) / magic (1st arg) */
    call kmain
halt_loop:
    cli
    hlt
    jmp halt_loop
.size _start, . - _start
