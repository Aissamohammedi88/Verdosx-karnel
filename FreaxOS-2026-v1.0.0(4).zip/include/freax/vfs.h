/*
 * FreaxOS 2026 - include/freax/vfs.h
 * Ramfs + mini /proc / In-memory filesystem with a tiny /proc.
 */
#ifndef FREAX_VFS_H
#define FREAX_VFS_H

#include "freax/types.h"

#define VNODE_DIR  0
#define VNODE_FILE 1
#define VFS_NAME_MAX 32

struct vnode {
    char name[VFS_NAME_MAX];
    int  type;                /* VNODE_DIR / VNODE_FILE            */
    int  is_dynamic;          /* contenu généré (/proc) / generated */
    char *data;               /* contenu ramfs / ramfs content      */
    u32  size, cap;
    struct vnode *parent, *children, *sibling_next;
    /* Fichiers dynamiques : (out, cap) -> taille écrite / dynamic reader */
    int (*read_fn)(struct vnode *v, char *out, int cap);
};

void vfs_init(void);
void vfs_shutdown(void);      /* libère tout / free everything */

/* Résolution : chemin absolu ou relatif à cwd ; gère « . » et « .. ». */
struct vnode *vfs_root(void);
struct vnode *vfs_cwd(void);
void          vfs_set_cwd(struct vnode *dir);
struct vnode *vfs_resolve(const char *path);          /* NULL si absent */
struct vnode *vfs_resolve_dir(const char *path);      /* NULL si pas un dir */

struct vnode *vfs_mkdir(const char *path);            /* crée un dossier */
struct vnode *vfs_create(const char *path);           /* crée un fichier */
int  vfs_unlink(const char *path);                    /* 0 = ok          */
int  vfs_write(struct vnode *v, const char *buf, u32 len, u32 pos); /* 0=ok */
int  vfs_read(struct vnode *v, char *out, u32 len, u32 *pos);       /* >=0 */
int  vfs_truncate(struct vnode *v);

/* Listing via callback (1 = continuer) / list via callback */
int  vfs_list(struct vnode *dir,
              int (*cb)(const char *name, int type, void *ctx), void *ctx);
/* Chemin complet d'un nœud / full path of a node */
int  vfs_path_of(struct vnode *v, char *out, int cap);

/* Table de descripteurs globale (kit) / global fd table (kit simplification) */
int  vfs_fd_open(struct vnode *v, int mode); /* mode: 0=r 1=w 2=a */
int  vfs_fd_read(int fd, char *buf, int len);
int  vfs_fd_write(int fd, const char *buf, int len);
void vfs_fd_close(int fd);
void vfs_fd_close_all_for(struct vnode *v);  /* unlink: invalider les fds */

#endif /* FREAX_VFS_H */
