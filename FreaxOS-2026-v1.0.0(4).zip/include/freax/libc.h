/*
 * FreaxOS 2026 - include/freax/libc.h
 * Mini-libc du noyau : prototypes / Kernel mini-libc prototypes.
 *
 * FR : Les mêmes noms que la libc, réimplémentés freestanding dans
 *      kernel/libc.c (réentrants, sans état global).
 * EN : libc names, reimplemented freestanding in kernel/libc.c (reentrant,
 *      stateless).
 */
#ifndef FREAX_LIBC_H
#define FREAX_LIBC_H

#include "freax/types.h"

void  *memset(void *dst, int c, freax_size n);
void  *memcpy(void *dst, const void *src, freax_size n);
void  *memmove(void *dst, const void *src, freax_size n);
int    memcmp(const void *a, const void *b, freax_size n);

freax_size strlen(const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, freax_size n);
char  *strncpy(char *dst, const char *src, freax_size n);
char  *strchr(const char *s, int c);
char  *strrchr(const char *s, int c);

int    tolower(int c);
int    toupper(int c);
int    freax_atoi(const char *s);

#endif /* FREAX_LIBC_H */
