/*
 * FreaxOS 2026 - include/freax/printk.h
 * Formatage et journal du noyau / Kernel formatting and log.
 */
#ifndef FREAX_PRINTK_H
#define FREAX_PRINTK_H

#include "freax/types.h"

/* printk : printf du noyau. Formats : %d %i %u %x %X %p %s %c %%
 * avec largeur et zéro de remplissage (%08x, %5d). Pas de flottants. */
void printk(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
void vprintk(const char *fmt, __builtin_va_list ap);
/* snprintf interne du noyau (ne masque pas le snprintf libc). */
int  freax_vsnprintf(char *out, int cap, const char *fmt, __builtin_va_list ap);
int  freax_snprintf(char *out, int cap, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));

/* Panique noyau : message + arrêt / Kernel panic: message + halt. */
void kpanic(const char *fmt, ...) __attribute__((noreturn, format(printf, 1, 2)));

/* Anneau de journal (dumpable via /proc/klog) / Kernel log ring. */
void klog_write(const char *s, int n);
int  klog_read(char *out, int cap);   /* copie l'anneau, retourne la taille */

#endif /* FREAX_PRINTK_H */
