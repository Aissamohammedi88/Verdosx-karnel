/*
 * FreaxOS 2026 - include/freax/hal.h
 * Couche d'abstraction matérielle / Hardware Abstraction Layer.
 *
 * FR : Tout le noyau portable passe par cette interface. Deux implémentations :
 *      sim/hal_host.c  (terminal Linux/macOS)  et  baremetal/hal_i386.c (QEMU).
 * EN : All portable kernel code goes through this interface. Two backends:
 *      sim/hal_host.c  (Linux/macOS terminal)  and  baremetal/hal_i386.c (QEMU).
 */
#ifndef FREAX_HAL_H
#define FREAX_HAL_H

#include "freax/types.h"

struct hal {
    /* Écrit un caractère sur la console / Write one char to the console. */
    void (*putc)(char c);
    /* Lit un caractère, non bloquant : -1 si rien / Non-blocking getc. */
    int  (*getc)(void);
    /* Horloge monotone en ticks (FREAX_TICK_HZ par seconde) / Ticks. */
    u32  (*ticks)(void);
    /* Pause économe (hlt, usleep...) pendant les tours perdus / Idle. */
    void (*idle)(void);
    /* Extinction (0) ou redémarrage (1) / Shutdown or reboot. */
    void (*shutdown)(int reboot);
};

extern struct hal *g_hal;

/* État global fourni au noyau par chaque backend / Backend-provided state. */
extern const char *g_hal_platform; /* ex. "hosted simulator" / "i386 baremetal" */

#endif /* FREAX_HAL_H */
