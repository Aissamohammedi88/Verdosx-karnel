/*
 * FreaxOS 2026 - include/freax/config.h
 * Configuration et identité du noyau / Kernel identity and configuration.
 *
 * FR : FreaxOS est une relecture éducative du noyau Linux 0.12 (février 1992,
 *      première version sous GNU GPL) réinventée « pour les développeurs ».
 * EN : FreaxOS is an educational reimagining of the Linux 0.12 kernel (February
 *      1992, first GPL release), rebuilt "for developers".
 */
#ifndef FREAX_CONFIG_H
#define FREAX_CONFIG_H

#define FREAX_NAME      "FreaxOS"
#define FREAX_VERSION   "1.0.0"
#define FREAX_CODENAME  "freax"
#define FREAX_RELEASE   "1.0.0-freax"
#define FREAX_TAGLINE   "the 0.12 spirit, rebuilt for developers"

#ifndef FREAX_BUILD_DATE
#define FREAX_BUILD_DATE "2026-11-19"
#endif

/* Tick rate of the timer / Fréquence du timer (PIT matériel ou horloge hôte). */
#define FREAX_TICK_HZ   100

/* Process/file descriptor limits / Limites processus et descripteurs. */
#define FREAX_MAX_OPEN      16
#define FREAX_TASK_NAME_MAX 16
#define FREAX_MAX_TASKS     32
#define FREAX_KLOG_SIZE     4096

/* Per-mode defaults (stack, heap) — overridden per build / Valeurs par mode. */
#ifndef FREAX_BAREMETAL
#define FREAX_STACK_SIZE  32768u   /* hosted simulator stacks */
#define FREAX_HEAP_SIZE   (4u * 1024u * 1024u)
#else
#define FREAX_STACK_SIZE  8192u    /* bare-metal i386 stacks */
#define FREAX_HEAP_SIZE   (8u * 1024u * 1024u)
#endif

/* Scheduler default quantum, in ticks (time-slice hint) / Quantum par défaut. */
#define FREAX_QUANTUM     10

#endif /* FREAX_CONFIG_H */
