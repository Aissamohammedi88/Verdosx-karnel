/*
 * FreaxOS 2026 - include/freax/ctx.h
 * Contextes d'exécution (piles de tâches) / Task execution contexts.
 *
 * FR : Abstraction du changement de contexte. En mode hébergé, sim/ctx_ucontext.c
 *      utilise POSIX ucontext (portable sur tous les hôtes). En bare-metal i386,
 *      baremetal/ctx_i386.c bascule les registres à la main (asm inline).
 * EN : Context-switch abstraction. Hosted mode uses POSIX ucontext via
 *      sim/ctx_ucontext.c (portable on every host); bare-metal i386 switches
 *      registers by hand in baremetal/ctx_i386.c (inline asm).
 */
#ifndef FREAX_CTX_H
#define FREAX_CTX_H

#include "freax/types.h"

#ifdef FREAX_BAREMETAL
/* Bare-metal : un simple esp sauvegardé suffit (i386 cdecl). */
struct ctx { u32 esp; };
#else
/* Hébergé : opaque (ucontext_t), taille obtenue via ctx_size(). */
struct ctx;
#endif

int  ctx_size(void);
/* Prépare un contexte qui exécutera entry() sur la pile [stack, stack+size). */
int  ctx_init(struct ctx *c, void *stack, u32 stack_size, void (*entry)(void));
/* Bascule du contexte courant vers « to » en sauvegardant « from ». */
void ctx_switch(struct ctx *from, struct ctx *to);

#endif /* FREAX_CTX_H */
