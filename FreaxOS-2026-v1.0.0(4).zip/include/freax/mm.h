/*
 * FreaxOS 2026 - include/freax/mm.h
 * Gestion mémoire du noyau / Kernel memory manager.
 *
 * FR : Allocateur première place (« first-fit ») sur une région contiguë,
 *      avec coalescence des blocs libres, statistiques et contrôle d'intégrité.
 * EN : First-fit allocator over one contiguous region, with free-block
 *      coalescing, statistics and an integrity checker.
 */
#ifndef FREAX_MM_H
#define FREAX_MM_H

#include "freax/types.h"

void mm_init(void *base, u32 size);          /* base alignée 16 / 16-aligned */
void *kmalloc(u32 size);                     /* aligné 16 / 16-aligned       */
void *kmalloc_zero(u32 size);
void kfree(void *p);

struct mm_stats {
    u32 heap_size;   /* taille totale de la région / region size          */
    u32 used;        /* octets utiles alloués / bytes in use              */
    u32 free;        /* octets libres / free bytes                        */
    u32 peak_used;   /* maximum historique / historic peak                */
    u32 n_alloc;     /* nombre d'allocations / allocation count           */
    u32 n_free;      /* nombre de libérations / free count                */
    u32 n_fail;      /* échecs (plus de place) / out-of-memory failures   */
    u32 n_blocks;    /* blocs (utilisés + libres) / blocks                */
};

void mm_get_stats(struct mm_stats *out);
int  mm_check(void);        /* 0 = OK, -1 = amas corrompu / heap corrupted */
int  mm_leak_count(void);   /* blocs encore alloués / still-allocated blocks */

#endif /* FREAX_MM_H */
