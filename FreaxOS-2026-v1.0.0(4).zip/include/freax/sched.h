/*
 * FreaxOS 2026 - include/freax/sched.h
 * Ordonnanceur round-robin coopératif / Cooperative round-robin scheduler.
 */
#ifndef FREAX_SCHED_H
#define FREAX_SCHED_H

#include "freax/types.h"

enum task_state {
    T_RUNNABLE = 1, /* prêt à tourner / ready                       */
    T_RUNNING  = 2, /* en cours / running                           */
    T_BLOCKED  = 3, /* en attente (wait, sleep...) / waiting        */
    T_ZOMBIE   = 4  /* terminé, pas encore reprise / exited, unkept */
};

void sched_init(void);
/* Crée une tâche « name » exécutant entry() ; retourne le pid (>0) ou -1. */
int  sched_spawn(const char *name, void (*entry)(void), u32 stack_size);
/* Boucle principale : max_steps == 0 => infini. Retourne après l'arrêt. */
void sched_run(u32 max_steps);
/* Arrête la boucle / request scheduler loop exit. */
void sched_shutdown(void);
int  sched_shutting_down(void);

/* Points de reprise : appelés depuis une tâche. */
void sched_yield(void);                 /* cède son tour / give up the CPU */
void task_block(void);                  /* passe en T_BLOCKED puis cède    */
void task_wake(int pid);                /* réveille une tâche bloquée      */
void task_exit(int code) __attribute__((noreturn)); /* fin de tâche        */

/* Sommeil : bloque la tâche jusqu'au tick voulu / block until wake tick. */
void task_sleep_ticks(u32 n);

/* Attente d'une tâche précise ; retourne le pid ou -1 / waitpid-like. */
int  task_wait(int pid, int *exit_code);

/* Libère toutes les tâches restantes (extinction) / free all tasks (shutdown). */
void sched_free_all(void);

int  sched_current_pid(void);
const char *sched_current_name(void);
int  sched_task_count(void);            /* tâches vivantes / live tasks    */
u32  sched_switch_count(void);          /* commutations / context switches */

/* Table de fds de la tâche courante (opaque, gérée par vfs) / fd table. */
void **task_current_files(void);

/* Exposition pour /proc/tasks : liste (pid, nom, état, ticks) / proc dump. */
int  sched_dump_tasks(char *out, int cap);

#endif /* FREAX_SCHED_H */
