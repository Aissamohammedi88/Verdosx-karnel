/*
 * FreaxOS 2026 - include/freax/kernel.h
 * Démarrage/arrêt du noyau portable / Portable kernel boot & shutdown.
 */
#ifndef FREAX_KERNEL_H
#define FREAX_KERNEL_H

#include "freax/types.h"

/* Amorce complète : bandeau, mm, vfs, sched, tâche init (shell), boucle.
 * Ne retourne qu'après « halt » / returns only after "halt". */
void kernel_boot(void *heap_base, u32 heap_size);

/* Remplace la tâche init (défaut : shell_task) — ex. desktop_task du bureau.
 * À appeler avant kernel_boot / replaces the init task (default: shell_task)
 * — e.g. the desktop's desktop_task. Call before kernel_boot. */
void kernel_set_init_task(void (*entry)(void));

/* Initialisation seule (tests) : mm+vfs+sched prêts, rien ne tourne. */
void kernel_init_subsystems(void *heap_base, u32 heap_size);

/* Nettoyage propre : tâches, vfs, puis rapport de fuites / clean shutdown. */
void kernel_shutdown_cleanup(void);

#endif /* FREAX_KERNEL_H */
