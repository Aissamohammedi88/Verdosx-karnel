/*
 * FreaxOS 2026 - include/freax/shell.h
 * Shell interactif « freaxsh » / Interactive developer shell.
 */
#ifndef FREAX_SHELL_H
#define FREAX_SHELL_H

#include "freax/types.h"

/* Tâche pid 1 : boucle interactive (utilise les syscalls) / pid-1 task. */
void shell_task(void);

/* Exécute une ligne sans TTY (tests, scripts) / run one line, no TTY. */
void shell_exec_line(char *line);

/* Interface commandes / command interface. */
struct command {
    const char *name;
    const char *desc;
    int (*fn)(int argc, char **argv);
};
const struct command *shell_commands(int *count);

/* Console abstraite (capture pour tests) / console + test capture. */
void console_set_capture(char *buf, int cap);
void console_write(const char *s, int n);
void console_putc(char c);
int  console_trygetc(void);   /* -1 si rien / nothing available */

/* Tux + CRC32 : module Rust si présent, sinon repli C / Rust or C fallback */
int  freax_tux_lines(char *out, int cap);      /* art ASCII, retour lignes */
u32  freax_crc32(const u8 *data, u32 len, u32 seed);
int  freax_rust_info(char *out, int cap);      /* provenance du module     */

#endif /* FREAX_SHELL_H */
