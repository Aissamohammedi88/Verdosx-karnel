/*
 * FreaxOS 2026 - include/freax/types.h
 * Types de base freestanding (aucune dépendance libc) / Freestanding base types.
 *
 * FR : Le noyau ne dépend d'aucune libc. Les tailles sont fixes afin que le
 *      même code source compile en mode hébergé (x86-64) et en bare-metal i386.
 * EN : The kernel depends on no libc. Fixed-width types keep the same source
 *      building in hosted simulator mode and on bare-metal i386.
 */
#ifndef FREAX_TYPES_H
#define FREAX_TYPES_H

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned long long u64;
typedef signed char    i8;
typedef signed short   i16;
typedef signed int     i32;
typedef signed long long i64;

/* Compiler-provided, correct in both freestanding modes / fourni par gcc. */
typedef __SIZE_TYPE__   freax_size;
typedef __UINTPTR_TYPE__ freax_uptr;

#ifndef NULL
#define NULL ((void *)0)
#endif

#endif /* FREAX_TYPES_H */
