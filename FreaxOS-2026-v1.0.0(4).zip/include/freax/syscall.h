/*
 * FreaxOS 2026 - include/freax/syscall.h
 * Appels système (table éducative) / System calls (educational table).
 *
 * FR : Un seul espace d'adressage (pas de séparation noyau/utilisateur) :
 *      le passage d'arguments est volontairement simple, comme un kit.
 * EN : Single address space (no user/kernel split): argument passing is
 *      intentionally simple, kit-style.
 */
#ifndef FREAX_SYSCALL_H
#define FREAX_SYSCALL_H

#include "freax/types.h"

/* Numéros d'appels système / syscall numbers */
#define SYS_exit    1
#define SYS_read    3
#define SYS_write   4
#define SYS_open    5
#define SYS_close   6
#define SYS_getpid  20
#define SYS_spawn   57   /* clin d'œil à fork+exec / nod to fork+exec */
#define SYS_wait    58
#define SYS_uptime  78
#define SYS_msleep  79
#define SYS_reboot  88

/* Dispatch générique : long = taille pointeur sur l'hôte (i386 : 32 bits).
 * Generic dispatcher: long matches pointer size on the host. */
int syscall(int num, long a, long b, long c);

/* Enveloppes C / C wrappers */
int  sys_read(int fd, char *buf, int len);
int  sys_write(int fd, const char *buf, int len);
int  sys_open(const char *path, int mode);   /* mode: 0='r' 1='w' 2='a' */
int  sys_close(int fd);
int  sys_getpid(void);
int  sys_spawn(const char *name, void (*entry)(void));
int  sys_wait(int pid, int *exit_code);
u32  sys_uptime_ticks(void);
void sys_msleep(u32 ticks);
void sys_reboot(void) __attribute__((noreturn));

/* fds réservés console / reserved console fds */
#define FD_STDIN  0
#define FD_STDOUT 1
#define FD_STDERR 2

#endif /* FREAX_SYSCALL_H */
