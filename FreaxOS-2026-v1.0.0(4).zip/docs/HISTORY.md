# FreaxOS 2026 : la chronologie 1991 → 2026
# FreaxOS 2026: the 1991 → 2026 timeline

Document bilingue / Bilingual document.

---

## FR — Les faits (1987 → 1994)

**25 août 1991.** Sur le forum Usenet `comp.os.minix`, l'étudiant finlandais
Linus Benedict Torvalds annonce : *« I'm doing a (free) operating system
(just a hobby, won't be big and professional like gnu) »*. Il venait de
passer l'été à transformer son émulateur de terminal pour Intel 80386 en
noyau — d'abord pour comprendre sa machine, indisposé qu'il était par la
faible disponibilité du serveur UNIX de l'université d'Helsinki.

**Septembre 1991.** Ari Lemmke, administrateur du serveur FTP
`ftp.funet.fi`, héberge le travail dans un répertoire nommé **linux** :
Linus avait d'abord appelé son projet **Freax** (free + freak + x). Le nom
reste — et devient plus tard une marque déposée au nom de Linus Torvalds.

**5 octobre 1991.** Annonce de la version **0.02** ; la 0.01 (17 septembre)
était restée confidentielle.

**Février 1992.** La version **0.12** est la première diffusée sous
**licence publique générale GNU (GPL)**, à la place de la licence ad hoc
qui interdisait la redistribution commerciale. C'est l'acte fondateur : les
contributions externes explosent.

**Janvier-février 1992.** Le « débat Tanenbaum » : Andrew S. Tanenbaum,
professeur à l'université libre d'Amsterdam et auteur de Minix, publie
« LINUX is obsolete », plaidant pour les micro-noyaux ; Linus répond,
notamment : *« If GNU had been available last spring, I would not have
bothered to even start my project »*. Le choix monolithique est assumé —
et restera celui du noyau.

**14 mars 1994.** Version **1.0.0**, avec 176 250 lignes de code.

**1996.** Le manchot **Tux**, dessiné par Larry Ewing, devient la mascotte.

**Depuis 2005.** Le cycle moderne : une version toutes les ~9 semaines,
branche stable maintenue (Greg Kroah-Hartman), des milliers de contributeurs
et des centaines d'entreprises ; le noyau, monolithique mais **modulaire**
depuis la version 2.0, est écrit aujourd'hui en **C et Rust**.

> Note : les mentions d'une version « 7.3.4 (10 novembre 2026) » circulent
> dans des pages d'encyclopédie fictionnelles ; FreaxOS s'inspire de
> l'esprit, pas d'événements futurs.
>
> Note: references to a "7.3.4 (10 November 2026)" kernel version belong to
> fictional encyclopedia pages; FreaxOS borrows the spirit, not future
> events.

## FR — Ce que FreaxOS 2026 rejoue

| 1992 (Linux 0.12) | FreaxOS 2026 | Pourquoi |
|---|---|---|
| Noyau hobby lisible, qu'on compile chez soi | `make` unique, 5 min pour compiler | le plaisir de comprendre |
| Monolithique assumé (réponse à Tanenbaum) | monolithique **et** raconté (ARCHITECTURE.md) | le choix devient un document |
| Minix-fs rudimentaire | ramfs + `/proc` dynamique | tester sans disque |
| « just a hobby » sur Usenet | commandes `justforfun`, `tanenbaum`, `freax`, `v012` | l'histoire embarquée dans le shell |
| pid 1 = init | pid 1 = `freaxsh` | la continuité |
| GPL v2 (février 1992) | GPL v2 | la licence comme acte fondateur |
| C (et ASM) | C + ASM + **Rust** optionnel (no_std) | 2026 |
| débogage à la printk | printk + `/proc/klog` + tests unitaires + rapport de fuites | le confort « développeurs » |
| Tux (1996) | commande `tux` (Rust ou C) | la mascotte, partout |

Le nom **Freax** est rétabli en hommage : c'était le premier nom du projet,
avant le répertoire FTP. FreaxOS ne remplace rien — il re-joue le moment où
un étudiant a montré qu'un noyau « hobby » partagé librement pouvait tout
devenir.

## EN — The facts (1987 → 1994)

**August 25, 1991.** On the Usenet `comp.os.minix` forum, Finnish student
Linus Benedict Torvalds announces: *"I'm doing a (free) operating system
(just a hobby, won't be big and professional like gnu)"*. He had just spent
the summer turning his terminal emulator for the Intel 80386 into a kernel —
first to understand his machine, annoyed as he was by the poor availability
of his University of Helsinki's UNIX server.

**September 1991.** Ari Lemmke, admin of the `ftp.funet.fi` FTP server,
hosts the work in a directory named **linux**: Linus had first called his
project **Freax** (free + freak + x). The name stuck — and later became a
registered trademark held by Linus Torvalds.

**October 5, 1991.** Version **0.02** announced; 0.01 (September 17) had
seen only confidential distribution.

**February 1992.** Version **0.12** is the first released under the **GNU
General Public License (GPL)**, replacing the ad hoc license that forbade
commercial redistribution. The founding act: external contributions
explode.

**January–February 1992.** The "Tanenbaum debate": Andrew S. Tanenbaum,
professor at the Vrije Universiteit Amsterdam and Minix author, posts
"LINUX is obsolete", arguing for microkernels; Linus replies, among other
things: *"If GNU had been available last spring, I would not have bothered
to even start my project"*. The monolithic choice is embraced — and became
the kernel's lasting design.

**March 14, 1994.** Version **1.0.0**, with 176,250 lines of code.

**1996.** The **Tux** penguin, drawn by Larry Ewing, becomes the mascot.

**Since 2005.** The modern cadence: a release every ~9 weeks, a maintained
stable branch (Greg Kroah-Hartman), thousands of contributors and hundreds
of companies; the kernel, monolithic yet **modular** since version 2.0, is
now written in **C and Rust**.

## EN — What FreaxOS 2026 replays

| 1992 (Linux 0.12) | FreaxOS 2026 | Why |
|---|---|---|
| A readable hobby kernel you build at home | one `make`, 5-minute build | the joy of understanding |
| Embraced monolith (Tanenbaum's answer) | monolithic **and** narrated (ARCHITECTURE.md) | the choice becomes a document |
| Minimal minix-fs | ramfs + dynamic `/proc` | testing without a disk |
| "just a hobby" on Usenet | `justforfun`, `tanenbaum`, `freax`, `v012` commands | history embedded in the shell |
| pid 1 = init | pid 1 = `freaxsh` | continuity |
| GPL v2 (February 1992) | GPL v2 | the license as founding act |
| C (and assembly) | C + asm + optional **Rust** (no_std) | 2026 |
| printk-only debugging | printk + `/proc/klog` + unit tests + leak report | "developers" comfort |
| Tux (1996) | `tux` command (Rust or C) | the mascot, everywhere |

The **Freax** name is restored as a tribute: it was the project's first
name, before the FTP directory. FreaxOS replaces nothing — it replays the
moment when a student showed that a freely shared "hobby" kernel could
become everything.

## Sources des faits historiques / Sources for the historical facts

Les dates et citations ci-dessus sont les éléments classiques et documentés
de l'histoire du noyau Linux : l'annonce du 25 août 1991 sur
`comp.os.minix` (archives), le passage en GPL de la 0.12 en février 1992,
la sortie 1.0.0 du 14 mars 1994 (176 250 lignes), le renommage par Ari
Lemmke, Tux par Larry Ewing (1996), le débat Tanenbaum de janvier 1992.
Elles proviennent de l'article encyclopédique fourni par l'utilisateur et
des archives Usenet largement citées.

The dates and quotes above are the classic, well-documented milestones of
Linux kernel history: the August 25, 1991 `comp.os.minix` announcement
(archives), 0.12 going GPL in February 1992, the March 14, 1994 1.0.0
release (176,250 lines), Ari Lemmke's renaming, Tux by Larry Ewing (1996),
the January 1992 Tanenbaum debate. They come from the encyclopedia article
provided by the user and from the widely cited Usenet archives.
