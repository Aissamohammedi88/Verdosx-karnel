# Architecture de FreaxOS 2026 / FreaxOS 2026 architecture

Document bilingue : chaque section présente le français puis l'anglais.
Bilingual document: each section gives French then English.

---

## FR — Vue d'ensemble

FreaxOS est un noyau **monolithique modulaire par compilation** : un cœur
portable (`kernel/` + `shell/`) compilé deux fois contre deux implémentations
de la couche d'abstraction matérielle (HAL).

```
            +----------------------------------------------+
            |   shell freaxsh  (shell/*.c)                 |
            |   commandes, historique, easter eggs         |
            +---------------------|------------------------+
            |   appels système    |  (kernel/syscall.c)    |
            +---------------------|------------------------+
            |   noyau portable                             |
            |   printk/klog  mm  sched  vfs                |
            |   (kernel/*.c)                               |
            +---------------------|------------------------+
            |   HAL (freax/hal.h) : putc/getc/ticks/idle   |
            +------------+--------------+----------------+
                         |              |
        +----------------+--+        +--+-------------------+
        | sim/hal_host.c    |        | baremetal/hal_i386.c |
        | terminal hôte     |        | VGA + COM1 + 0xE9    |
        | ucontext, termios |        | PS/2, PIT 100 Hz     |
        +-------------------+        | GDT/IDT/PIC, multiboot|
                                     +----------------------+
```

Deux binaires très différents, un seul code de noyau :

- `build/freax-sim` — x86-64 (ou tout hôte POSIX), tas de 4 Mio alloué par
  l'hôte, terminal en mode semi-brut, entrée non bloquante ;
- `build/freax-i386.elf` — ELF32 i386 multiboot chargé à 1 Mio par
  GRUB/QEMU, tas borné par `mem_upper`, VGA + série, interruptions matérielles.

### Ordonnanceur (kernel/sched.c)

Round-robin **coopératif**. Chaque tâche possède sa pile (allouée via `mm`)
et son contexte :

- mode hébergé : `sim/ctx_ucontext.c` avec POSIX `swapcontext` — portable
  sur tous les hôtes sans asm, et il sauvegarde aussi les registres FPU ;
- bare-metal i386 : `baremetal/ctx_i386.c` bascule `ebx/ebp/esi/edi/esp`
  en asm inline ; le `ret` final entre dans la tâche via une trame
  préparée par `ctx_init`.

La boucle `sched_run()` choisit la tâche `T_RUNNABLE` suivante, bascule
vers elle, et récupère la main quand la tâche cède (`sched_yield`), bloque
(`task_block`, `task_sleep_ticks`) ou meurt (`task_exit` → zombie). Le
zombie reste tant qu'un parent vivant peut l'attendre ; il est repris
(libéré) sinon. `task_wait(pid, &code)` implémente la sémantique
waitpid : blocage, réveil par `task_exit`, code de sortie, reprise.

Une **file de sommeil** : `task_sleep_ticks(n)` marque `wake_at`, passe
en `T_BLOCKED` et cède ; à chaque tour, `wake_due_tasks()` réveille les
tâches dont l'échéance est passée. Aucun spin CPU.

**Différence assumée avec le 0.12 réel** : le noyau de 1992 était préemptif
(l'IRQ timer reprogrammait). Ici, une tâche garde le CPU tant qu'elle ne
cède pas ; le timer ne sert qu'à l'horloge et aux réveils. C'est le
compromis pédagogique : les changements de contexte se produisent toujours
en des points sûrs, et le code tient dans un fichier lisible.

### Gestion mémoire (kernel/mm.c)

Un seul amas contigu. Chaque bloc : en-tête 32 octets (magic `0xFEA12026`,
taille utile, état), liste doublement chaînée **en ordre d'adresse**.

- `kmalloc` : première place (« first-fit »), alignement 16 octets, découpe
  du bloc si le reste est assez grand ;
- `kfree` : fusion avec le voisin libre de gauche puis de droite ;
- statistiques : total/used/free/peak, compteurs alloc/free/fail ;
- `mm_check()` : promenade d'intégrité (magics, maillages, cohérence
  used/free avec les compteurs) — utilisée par les tests ;
- `mm_leak_count()` : alimente le rapport de fuites affiché par `halt`.

Le 0.12, lui, gérait pages et swapping ; ce kit volontairement non — la
comptabilité exacte des octets est le sujet.

### VFS : ramfs + mini /proc (kernel/vfs.c)

Arbre de `struct vnode` en mémoire (dossiers, fichiers). Résolution
absolute/relative avec `.` et `..`, création/suppression, écriture avec
croissance de tampon, listing par callback, chemins par récursion depuis
la racine. Les nœuds `/proc` sont **dynamiques** : leur `read_fn` régénère
le contenu à l'ouverture (version, uptime, meminfo, cpuinfo, tasks, klog,
freax). La position de lecture sert de garde-fou pour éviter la boucle
infinie d'un `cat /proc/...`.

La table de descripteurs est **globale au noyau** (fds 0/1/2 = console) :
simplification kit assumée, documentée.

### Appels système (kernel/syscall.c)

| Numéro | Nom | Rôle |
|---|---|---|
| 1 | `exit` | termine la tâche courante (zombie) |
| 3 | `read` | lit un fd ; console : `-2` (EAGAIN) si rien |
| 4 | `write` | écrit sur un fd ; 1/2 = console |
| 5 | `open` | ouvre/crée un fichier ('r' 0 / 'w' 1 / 'a' 2) |
| 6 | `close` | ferme un fd |
| 20 | `getpid` | pid de la tâche courante |
| 57 | `spawn` | crée une tâche (clin d'œil à fork+exec) |
| 58 | `wait` | attend un pid (sémantique waitpid) |
| 78 | `uptime` | ticks depuis le boot |
| 79 | `msleep` | bloque la tâche n ticks |
| 88 | `reboot` | via le HAL (8042 en bare-metal) |

Le dispatch `syscall(num, a, b, c)` utilise des `long` (taille du pointeur
de l'hôte) : aucun troncature de pointeur en 64 bits. Un seul espace
d'adressage : pas de copies utilisateur/noyau, comme dans un kit.

### Shell (shell/)

`shell_task` est la tâche init (pid 1, comme en 1992). Édition ligne
(écho, retour arrière, Ctrl-L, Ctrl-D = `halt`), tokenisation avec
guillemets, historique de 16 lignes, table de commandes déclarative.
Les commandes passent par les **syscalls** (`cat` ouvre/lit/ferme), ce
qui en fait de vrais « programmes ». L'attente clavier fait des
`sched_yield()` : les autres tâches continuent de tourner pendant que le
shell attend — c'est visible avec la commande `demo`.

Easter eggs historiques (`justforfun`, `tanenbaum`, `freax`, `v012`) :
extraits réels et documentés des archives Usenet, avec attribution.

### Module Rust (rust/freax_rust)

`#![no_std]`, `crate-type = ["staticlib"]`, aucune dépendance : la table
CRC32 est générée par une `const fn` à la compilation. Symboles C exportés :
`freax_crc32`, `freax_tux_lines`, `freax_rust_info`. Si cargo est absent,
le Makefile lie `kernel/tux_stub.c` qui fournit **exactement les mêmes
symboles et le même comportement** — les tests valident les vecteurs IEEE
CRC32 quel que soit le chemin choisi.

### Bare-metal i386 (baremetal/)

- `boot.S` : header multiboot (ALIGN|MEMINFO, checksum vérifié à la
  construction), pile, appel `kmain(magic, mbi)` en cdecl ;
- `interrupts.c` : GDT plate (code/données), IDT 256 portes, remappage du
  PIC sur les vecteurs 32-47, gestionnaire C unique (`isr_handler`) ;
- `hal_i386.c` : VGA 80×25 (défilement, curseur 0x3D4, filtrage des
  séquences ANSI, translittération UTF-8→CP437 des accents), clavier PS/2
  (set 1, shift, anneau 128 octets rempli par l'IRQ1), PIT à 100 Hz
  (diviseur 11932), série COM1 + port debug 0xE9, extinction
  (`isa-debug-exit` QEMU, port 0xF4) et reboot (8042) ;
- `linker.ld` : `.boot` d'abord à 1 Mio (header dans les 8 premiers Kio),
  `_end` exporté pour borner le tas.

---

## EN — Overview

FreaxOS is a **monolithic kernel, modular by compilation**: one portable
core (`kernel/` + `shell/`) built twice against two implementations of the
hardware abstraction layer (HAL).

Two very different binaries, one kernel source:

- `build/freax-sim` — x86-64 (or any POSIX host), a 4 MiB heap allocated by
  the host, semi-raw terminal, non-blocking input;
- `build/freax-i386.elf` — multiboot ELF32 i386 loaded at 1 MiB by
  GRUB/QEMU, heap bounded by `mem_upper`, VGA + serial, hardware interrupts.

### Scheduler (kernel/sched.c)

**Cooperative** round-robin. Every task owns its stack (allocated through
`mm`) and its context:

- hosted mode: `sim/ctx_ucontext.c` uses POSIX `swapcontext` — portable on
  every host without asm, and it also saves FPU registers;
- bare-metal i386: `baremetal/ctx_i386.c` switches `ebx/ebp/esi/edi/esp`
  with inline asm; the final `ret` enters the task through a frame crafted
  by `ctx_init`.

`sched_run()` picks the next `T_RUNNABLE` task, switches to it, and gets
control back when the task yields (`sched_yield`), blocks (`task_block`,
`task_sleep_ticks`) or dies (`task_exit` → zombie). A zombie stays as long
as a living parent may wait for it; otherwise it is reaped (freed).
`task_wait(pid, &code)` implements waitpid semantics: blocking, wakeup by
`task_exit`, exit code, reaping.

A **sleep queue**: `task_sleep_ticks(n)` sets `wake_at`, moves to
`T_BLOCKED` and yields; every loop iteration, `wake_due_tasks()` wakes
tasks whose deadline passed. Zero CPU spinning.

**Honest difference from the real 0.12**: the 1992 kernel was preemptive
(the timer IRQ rescheduled). Here a task keeps the CPU until it yields; the
timer only drives the clock and wakeups. That is the pedagogical trade-off:
context switches always happen at safe points, and the whole scheduler fits
in one readable file.

### Memory management (kernel/mm.c)

One contiguous heap. Each block: a 32-byte header (magic `0xFEA12026`,
payload size, used flag), doubly linked **in address order**.

- `kmalloc`: first fit, 16-byte alignment, splits the block when the
  remainder is big enough;
- `kfree`: coalesces with the free left neighbour then the right one;
- statistics: total/used/free/peak plus alloc/free/fail counters;
- `mm_check()`: integrity walk (magics, linkages, used/free consistency
  against the counters) — used by the tests;
- `mm_leak_count()`: feeds the leak report printed by `halt`.

The real 0.12 handled paging and swapping; this kit deliberately does not —
exact byte accounting is the subject.

### VFS: ramfs + mini /proc (kernel/vfs.c)

A tree of in-memory `struct vnode` (directories, files). Absolute/relative
resolution with `.` and `..`, create/unlink, writes with buffer growth,
listing through a callback, paths built recursively from the root. `/proc`
nodes are **dynamic**: their `read_fn` regenerates the content on every
open (version, uptime, meminfo, cpuinfo, tasks, klog, freax). The read
position doubles as a guard against the endless `cat /proc/...` loop.

The file-descriptor table is **kernel-global** (fds 0/1/2 = console): a
documented kit-level simplification.

### System calls (kernel/syscall.c)

Same table as above (1 exit, 3 read, 4 write, 5 open, 6 close, 20 getpid,
57 spawn, 58 wait, 78 uptime, 79 msleep, 88 reboot). The
`syscall(num, a, b, c)` dispatcher uses `long` (host pointer size): no
pointer truncation on 64-bit hosts. Single address space: no user/kernel
copies, kit-style.

### Shell (shell/)

`shell_task` is the init task (pid 1, like 1992). Line editing (echo,
backspace, Ctrl-L, Ctrl-D = `halt`), quoting-aware tokenization, a
16-entry history, a declarative command table. Commands go through
**syscalls** (`cat` opens/reads/closes), making them real "programs".
Keyboard waiting performs `sched_yield()`: other tasks keep running while
the shell waits — visible with the `demo` command.

History easter eggs (`justforfun`, `tanenbaum`, `freax`, `v012`) are real,
documented excerpts from the Usenet archives, with attribution.

### Rust module (rust/freax_rust)

`#![no_std]`, `crate-type = ["staticlib"]`, zero dependencies: the CRC32
table is generated by a `const fn` at compile time. Exported C symbols:
`freax_crc32`, `freax_tux_lines`, `freax_rust_info`. Without cargo, the
Makefile links `kernel/tux_stub.c`, which provides **exactly the same
symbols and behaviour** — the tests validate the IEEE CRC32 vectors on
either path.

### Bare-metal i386 (baremetal/)

- `boot.S`: multiboot header (ALIGN|MEMINFO, checksum verified at build
  time), stack, cdecl call to `kmain(magic, mbi)`;
- `interrupts.c`: flat GDT (code/data), 256-gate IDT, PIC remapped to
  vectors 32-47, one C handler (`isr_handler`);
- `hal_i386.c`: 80×25 VGA (scrolling, 0x3D4 cursor, ANSI filtering,
  UTF-8→CP437 accent transliteration), PS/2 keyboard (set 1, shift, 128-byte
  ring filled by IRQ1), 100 Hz PIT (divisor 11932), COM1 serial + debug
  port 0xE9, shutdown (QEMU `isa-debug-exit`, port 0xF4) and reboot (8042);
- `linker.ld`: `.boot` first at 1 MiB (header within the first 8 KiB),
  `_end` exported to bound the heap.

### Sizing for 2026 developers

- tests: `make test` → 324 checks, 0 failures;
- a demo session transcript lives in `docs/demo-session.txt`;
- the whole kernel core compiles warning-free with `-Wall -Wextra`.
