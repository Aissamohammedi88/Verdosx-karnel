# Construire et exécuter FreaxOS 2026 / Building and running FreaxOS 2026

Document bilingue / Bilingual document.

---

## FR — Prérequis

| Outil | Utilisé pour | Obligatoire ? |
|---|---|---|
| gcc (ou clang) 11+ | tout compiler | oui |
| GNU binutils (`as`, `ld`) | asm i386, édition de liens | oui |
| `make` | orchestration | oui |
| `gcc -m32` utilisable | noyau bare-metal i386 | non (dégradé automatiquement) |
| `cargo` (rustc 1.56+) | module Rust CRC32/Tux | non (repli C automatique) |
| `qemu-system-i386` | `make run` / `make smoke` | non |
| `zip` | `make zip` | non |

Tout est détecté automatiquement : `make help` affiche ce qui a été trouvé.

## Cibles make

```bash
make            # sim + tests (+ bare-metal si gcc -m32 disponible)
make sim        # ./build/freax-sim — simulateur hébergé
make test       # 324 vérifications unitaires (7 suites)
make baremetal  # ./build/freax-i386.elf — noyau multiboot i386
make run        # QEMU interactif : VGA + COM1 sur le terminal
make smoke      # boot sans écran, vérifie la bannière sur COM1 (QEMU requis)
make run-sim    # lance le simulateur
make zip        # archive source FreaxOS-2026-v1.0.0.zip
make clean      # supprime build/, target/, l'archive
make help       # aide + détections
```

## Exécuter le simulateur

```bash
./build/freax-sim                    # interactif (Ctrl-D ou halt pour sortir)
./build/freax-sim -c "ls /proc"      # une commande puis sortie propre
./build/freax-sim --script docs/demo-session.txt   # entrée préchargée
./build/freax-sim --mem 2048         # tas de 2 Mio
./build/freax-sim --version
```

En inter actif, le terminal passe en mode semi-brut (écho géré par le shell,
Ctrl-L pour effacer, Ctrl-D sur ligne vide = `halt`). Ctrl-C interrompt
proprement le simulateur (termios restauré).

## Exécuter le noyau bare-metal

Sans GRUB ni disque, QEMU accepte directement l'ELF multiboot :

```bash
qemu-system-i386 -kernel build/freax-i386.elf -serial stdio
```

- l'écran VGA affiche la bannière et le shell ;
- le clavier PS/2 fonctionne (basique, US, sans pavé numérique ni flèches) ;
- `-serial stdio` double la sortie sur votre terminal — pratique pour copier ;
- pour vérifier sans écran : `make smoke` boote 8 s en `-display none`,
  enregistre COM1 dans `build/smoke.log` et vérifie la bannière ;
- la sortie QEMU peut être accélérée avec `-device isa-debug-exit` (déjà
  utilisée par `make smoke`) : `halt` quitte alors QEMU.

Vérification statique sans QEMU (déjà faite pour ce build) :

```bash
readelf -h build/freax-i386.elf          # ELF32 / Intel 80386 / entry
readelf -l build/freax-i386.elf          # .boot chargée à 0x100000
python3 -c "..."                         # checksum multiboot = 0
```

## Module Rust : activer, désactiver

```bash
cargo build --release --offline --manifest-path rust/freax_rust/Cargo.toml
make sim            # lie libfreax_rust.a automatiquement si cargo présent
FREAX_NO_RUST=1 make clean sim   # force le repli C
```

Le repli C (`kernel/tux_stub.c`) fournit les mêmes symboles et les mêmes
résultats (vérifiés par les tests sur les vecteurs IEEE CRC32).

## Dépannage

- **`gcc: error: unrecognized command line option '-m32'`** ou liaison 32
  bits manquante : installez gcc-multilib (Debian/Ubuntu :
  `apt install gcc-multilib`). Le Makefile ignore alors la cible bare-metal
  et construit sim + tests sans échec.
- **`cargo: command not found`** : normal si Rust n'est pas installé ; le
  repli C prend le relais, `make` reste vert.
- **`qemu-system-i386: command not found`** : installez qemu-system-x86 ;
  `make smoke` se termine avec succès (test ignoré) en attendant.
- **Aucun caractère au clavier en bare-metal** : utilisez `-serial stdio` ;
  le shell lit le clavier PS/2 (mappe US), vérifiez que votre fenêtre QEMU
  a le focus.
- **Tests qui tournent en boucle** : vérifiez qu'aucun objet ne traîne d'un
  ancien build (`make clean`), surtout après modification de
  `tests/framework.h`.

## EN — Prerequisites

| Tool | Used for | Required? |
|---|---|---|
| gcc (or clang) 11+ | compiling everything | yes |
| GNU binutils (`as`, `ld`) | i386 asm, linking | yes |
| `make` | orchestration | yes |
| working `gcc -m32` | bare-metal i386 kernel | no (automatic degrade) |
| `cargo` (rustc 1.56+) | Rust CRC32/Tux module | no (C fallback) |
| `qemu-system-i386` | `make run` / `make smoke` | no |
| `zip` | `make zip` | no |

Everything is auto-detected; `make help` shows what was found.

## Make targets

```bash
make            # sim + tests (+ bare-metal when gcc -m32 works)
make sim        # ./build/freax-sim — hosted simulator
make test       # 324 unit checks (7 suites)
make baremetal  # ./build/freax-i386.elf — multiboot i386 kernel
make run        # interactive QEMU: VGA + COM1 on your terminal
make smoke      # headless boot, banner check on COM1 (needs QEMU)
make run-sim    # run the simulator
make zip        # source archive FreaxOS-2026-v1.0.0.zip
make clean      # removes build/, target/, the archive
make help       # help + detections
```

## Running the simulator

```bash
./build/freax-sim                    # interactive (Ctrl-D or halt exits)
./build/freax-sim -c "ls /proc"      # one command, clean exit
./build/freax-sim --script docs/demo-session.txt   # pre-fed input
./build/freax-sim --mem 2048         # 2 MiB heap
./build/freax-sim --version
```

Interactively the terminal switches to semi-raw mode (shell-managed echo,
Ctrl-L clears, Ctrl-D on an empty line = `halt`). Ctrl-C stops the
simulator cleanly (termios restored).

## Running the bare-metal kernel

No GRUB, no disk needed — QEMU boots the multiboot ELF directly:

```bash
qemu-system-i386 -kernel build/freax-i386.elf -serial stdio
```

- the VGA screen shows the banner and the shell;
- the PS/2 keyboard works (basic, US mapping, no numpad/arrows);
- `-serial stdio` mirrors output to your terminal — handy for copying;
- for headless verification: `make smoke` boots for 8 s with `-display none`,
  records COM1 into `build/smoke.log` and checks the banner;
- `-device isa-debug-exit` (already used by `make smoke`) lets `halt` quit
  QEMU.

Static verification without QEMU (already done for this build):

```bash
readelf -h build/freax-i386.elf          # ELF32 / Intel 80386 / entry
readelf -l build/freax-i386.elf          # .boot loaded at 0x100000
```

## Rust module: enabling, disabling

```bash
cargo build --release --offline --manifest-path rust/freax_rust/Cargo.toml
make sim            # links libfreax_rust.a automatically when cargo exists
FREAX_NO_RUST=1 make clean sim   # forces the C fallback
```

The C fallback (`kernel/tux_stub.c`) provides the same symbols and results
(verified by the tests against the IEEE CRC32 vectors).

## Troubleshooting

- **`gcc: error: unrecognized command line option '-m32'`** or missing
  32-bit support: install gcc-multilib (Debian/Ubuntu:
  `apt install gcc-multilib`). The Makefile then skips the bare-metal
  target and still builds sim + tests successfully.
- **`cargo: command not found`**: expected without Rust; the C fallback
  takes over and `make` stays green.
- **`qemu-system-i386: command not found`**: install qemu-system-x86;
  `make smoke` exits successfully (test skipped) meanwhile.
- **No keyboard input in bare-metal**: use `-serial stdio`; the shell reads
  the PS/2 keyboard (US mapping), make sure your QEMU window has focus.
- **Tests looping forever**: make sure no stale objects remain
  (`make clean`), especially after editing `tests/framework.h`.
