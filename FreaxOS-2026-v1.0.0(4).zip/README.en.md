# FreaxOS 2026

**EN — English version** (Français : voir [README.md](README.md))

> "The 1992 kernel, rebuilt for 2026 developers."

FreaxOS 2026 is a **complete educational kernel** that replays the founding
moment of February 1992 — version 0.12 of Linus Torvalds' kernel, the first
release under the GNU GPL — with 2026 ideas and comfort: small, readable,
fully bilingual comments, unit tests and a modern `make` toolchain. It gives
the kernel back its original name, **Freax** (free + freak + x), chosen by
Linus before Ari Lemmke renamed the FTP directory "linux".

It is a **kit meant to be read and modified**, not a Linux reimplementation:
about 5,200 lines of C, x86 assembly and Rust, all included.

## What's in the kit

| Component | Files | Purpose |
|---|---|---|
| Portable kernel | `kernel/` | printk + klog ring, first-fit allocator with coalescing, round-robin scheduler with a real sleep queue, syscalls, ramfs + mini `/proc` |
| `freaxsh` shell | `shell/` | 30+ commands, history, history easter eggs (Aug 25 1991 post, the Tanenbaum debate…) |
| Simulator | `sim/` | the same kernel in any Linux/macOS terminal, no VM (`ucontext`, semi-raw terminal) |
| Bare-metal i386 | `baremetal/` | multiboot boot, GDT/IDT, PIC, 100 Hz PIT, 80×25 VGA, PS/2 keyboard, COM1 serial — runs under `qemu-system-i386 -kernel` |
| Optional Rust module | `rust/freax_rust/` | CRC32 (compile-time table) + Tux mascot, `no_std`; automatic C fallback when cargo is missing |
| Tests | `tests/` | 7 suites, **324 checks, 100 % green** (`make test`) |
| Docs | `docs/` | architecture, build, 1991→2026 history, demo session |

## Quick start

```bash
make              # builds sim + tests (+ bare-metal kernel if gcc -m32)
make test         # 324 unit checks
./build/freax-sim # the kernel in your terminal
```

Inside the shell (`freaxsh`):

```
freax:/> ls /proc
freax:/> cat /proc/version
freax:/> demo            ← three live round-robin tasks
freax:/> justforfun      ← the Aug 25 1991 Usenet post
freax:/> crc32 123456789
freax:/> tux
freax:/> halt
```

Non-interactive use:

```bash
./build/freax-sim -c "ls /proc"
./build/freax-sim --script docs/demo-session.txt
```

The bare-metal (i386, multiboot) kernel:

```bash
make baremetal
make run       # qemu-system-i386 -kernel build/freax-i386.elf -serial stdio
make smoke     # headless boot + banner check on COM1
```

## The "2026" ideas compared to 1992

- **Readability first**: every file opens with a bilingual comment explaining
  the why; 0.12 had to be deciphered.
- **Unit tests** (`make test`) for the allocator, scheduler, VFS, syscalls,
  shell and formatting — unthinkable in 1992.
- **Rust next to C**, like the modern kernel: CRC32 and Tux in `no_std`,
  with an automatic C fallback (`FREAX_NO_RUST=1` to force it).
- **A readable kernel log**: `cat /proc/klog` returns the last 4 KiB of
  `printk` output.
- **A real sleep queue**: `sleep` blocks the task (zero CPU spinning) and the
  scheduler wakes it at the requested tick.
- **A shutdown leak report**: `halt` frees everything and prints the memory
  peak and remaining blocks.
- **One toolchain**: `make sim`, `make test`, `make baremetal`, `make run`,
  `make smoke`, `make zip` — everything automated.

## What this kit is not (by design)

- No true preemption: the scheduler is **cooperative** (yield, block, sleep)
  — an educational choice documented in `docs/ARCHITECTURE.md`.
- No `fork()`: `sys_spawn` creates a task with its own stack; the parent can
  `wait` (waitpid semantics, zombies included).
- No paging and no user/kernel split: one address space, kit-style.
- No disk: the ramfs is volatile.

## Documentation

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — layers, design choices,
  syscall table, honest comparison with 0.12.
- [docs/BUILD.md](docs/BUILD.md) — prerequisites, make targets, troubleshooting.
- [docs/HISTORY.md](docs/HISTORY.md) — the 1991→2026 timeline and what
  FreaxOS replays from it.
- [docs/demo-session.txt](docs/demo-session.txt) — a full session.
- [TEST_REPORT.txt](TEST_REPORT.txt) — the test output of this build.

## License and credits

FreaxOS is distributed under the **GNU GPL v2**, echoing 0.12 going GPL in
February 1992 (see [LICENSE](LICENSE)).

Historical credits: Linus Torvalds (the kernel, 1991), Ari Lemmke (the
name), Andrew S. Tanenbaum (the debate that made it famous), Larry Ewing
(Tux mascot, 1996), and the Linux kernel community since. FreaxOS is an
independent educational tribute — it is neither Linux nor derived from
Linux kernel code.
