/*
 * FreaxOS 2026 - shell/shell.c
 * Shell « freaxsh » : boucle, tokenisation, dispatch / REPL, tokenizer, dispatch.
 *
 * FR : La tâche init (pid 1) exécute ce shell. Les commandes passent par les
 *      appels système, comme de vrais programmes. L'attente clavier fait des
 *      sched_yield(), laissant tourner les autres tâches — démo vivante du
 *      round-robin coopératif.
 * EN : The init task (pid 1) runs this shell. Commands go through syscalls
 *      like real programs. Keyboard waiting uses sched_yield(), letting other
 *      tasks run — a live demo of the cooperative round-robin.
 */
#include "freax/shell.h"
#include "freax/printk.h"
#include "freax/syscall.h"
#include "freax/sched.h"
#include "freax/vfs.h"
#include "freax/config.h"
#include "freax/libc.h"

#define SHELL_LINE_MAX  256
#define SHELL_ARGV_MAX  16
#define SHELL_ARG_MAX   64

/* stockage de l'historique dans eggs.c / history storage lives in eggs.c */
void shell_history_add(const char *line);

/* ---- tokenisation / tokenizer ---- */

static int tokenize(char *line, char *argv[], int maxv)
{
    int argc = 0;
    char *p = line;
    while (*p && argc < maxv) {
        while (*p == ' ' || *p == '\t')
            p++;
        if (!*p)
            break;
        char *out;
        if (*p == '"') {                /* guillemets / quotes */
            p++;
            out = p;
            argv[argc++] = out;
            while (*p && *p != '"')
                p++;
            if (*p == '"')
                *p++ = '\0';
        } else {
            out = p;
            argv[argc++] = out;
            while (*p && *p != ' ' && *p != '\t')
                p++;
            if (*p)
                *p++ = '\0';
        }
    }
    return argc;
}

/* ---- dispatch ---- */

void shell_exec_line(char *line)
{
    /* trim gauche/droite / trim both ends */
    while (*line == ' ' || *line == '\t')
        line++;
    int len = (int)strlen(line);
    while (len > 0 && (line[len - 1] == ' ' || line[len - 1] == '\t'))
        line[--len] = '\0';
    if (len == 0)
        return;

    char *copy[SHELL_LINE_MAX];
    memcpy(copy, line, (freax_size)len + 1);
    char *argv[SHELL_ARGV_MAX];
    int argc = tokenize((char *)copy, argv, SHELL_ARGV_MAX);
    if (argc == 0)
        return;

    int ncmds = 0;
    const struct command *cmds = shell_commands(&ncmds);
    for (int i = 0; i < ncmds; i++) {
        if (strcmp(cmds[i].name, argv[0]) == 0) {
            cmds[i].fn(argc, argv);
            return;
        }
    }
    printk("freaxsh : commande inconnue / unknown command : '%s'\n", argv[0]);
    printk("         tapez / type 'help' \x1b[2m(essayez aussi / also try: justforfun)\x1b[0m\n");
}

/* ---- boucle interactive / interactive loop ---- */

static void print_prompt(void)
{
    char path[256];
    vfs_path_of(vfs_cwd(), path, (int)sizeof(path));
    printk("\x1b[1;32mfreax\x1b[0m:\x1b[1;34m%s\x1b[0m> ", path);
}

static void shell_read_line(char *buf, int cap)
{
    int n = 0;
    buf[0] = '\0';
    while (!sched_shutting_down()) {
        char c;
        int r = sys_read(FD_STDIN, &c, 1);
        if (r == -2) {              /* EAGAIN : rien / nothing yet */
            sched_yield();
            continue;
        }
        if (r <= 0)
            continue;
        if (c == '\r')
            c = '\n';
        if (c == '\n') {
            printk("\n");
            return;
        }
        if (c == 0x7f || c == '\b') {   /* backspace / retour arrière */
            if (n > 0) {
                n--;
                printk("\b \b");
            }
            continue;
        }
        if (c == 0x0c) {                /* Ctrl-L : efface / clear */
            printk("\x1b[2J\x1b[H");
            print_prompt();
            printk("%s", buf);
            continue;
        }
        if (c == 0x04 && n == 0) {      /* Ctrl-D : quitte / quit */
            strncpy(buf, "halt", (freax_size)cap - 1);
            buf[cap - 1] = '\0';
            printk("halt\n");
            return;
        }
        if (c < 0x20 || c > 0x7e)
            continue;                   /* autres ctrl / other control chars */
        if (n < cap - 1) {
            buf[n++] = c;
            buf[n] = '\0';
            printk("%c", c);
        }
    }
}

void shell_task(void)
{
    char line[SHELL_LINE_MAX];

    struct vnode *motd = vfs_resolve("/etc/motd");
    if (motd && motd->type == VNODE_FILE) {
        char buf[512];
        u32 pos = 0;
        int n = vfs_read(motd, buf, sizeof(buf) - 1, &pos);
        if (n > 0) {
            buf[n] = '\0';
            printk("%s", buf);
        }
    }
    printk("\x1b[2mFR : pid 1 = shell « freaxsh ». Aide : help. Histoire : about.\x1b[0m\n");
    printk("\x1b[2mEN : pid 1 = the freaxsh shell. Help: help. History: about.\x1b[0m\n\n");

    while (!sched_shutting_down()) {
        print_prompt();
        shell_read_line(line, (int)sizeof(line));
        if (sched_shutting_down())
            break;
        if (line[0]) {
            shell_history_add(line);
            shell_exec_line(line);
        }
    }
    task_exit(0);
}
