/*
 * FreaxOS 2026 - shell/commands.c
 * Commandes du shell / Shell commands.
 */
#include "freax/shell.h"
#include "freax/printk.h"
#include "freax/syscall.h"
#include "freax/sched.h"
#include "freax/vfs.h"
#include "freax/mm.h"
#include "freax/config.h"
#include "freax/hal.h"
#include "freax/kernel.h"
#include "freax/libc.h"

/* extern de eggs.c (hist + easter eggs) / from eggs.c */
int cmd_history(int argc, char **argv);
int cmd_egg_justforfun(int argc, char **argv);
int cmd_egg_tanenbaum(int argc, char **argv);
int cmd_egg_freax(int argc, char **argv);
int cmd_egg_v012(int argc, char **argv);

/* ---- utilitaires / helpers ---- */

static void cmd_result_msg(const char *what, int rc)
{
    if (rc != 0)
        printk("%s : echec / failed (%d)\n", what, rc);
}

static int ls_cb(const char *name, int type, void *ctx)
{
    (void)ctx;
    if (type == VNODE_DIR)
        printk("\x1b[1;34m%s/\x1b[0m  ", name);
    else
        printk("%s  ", name);
    return 1;
}

/* ---- commandes système / system commands ---- */

static int cmd_help(int argc, char **argv)
{
    if (argc > 1) {
        int ncmds = 0;
        const struct command *cmds = shell_commands(&ncmds);
        for (int i = 0; i < ncmds; i++) {
            if (strcmp(cmds[i].name, argv[1]) == 0) {
                printk("%-10s : %s\n", cmds[i].name, cmds[i].desc);
                return 0;
            }
        }
        printk("help : '%s' inconnu / unknown\n", argv[1]);
        return 1;
    }
    printk("\nCommandes / Commands :\n");
    int ncmds = 0;
    const struct command *cmds = shell_commands(&ncmds);
    for (int i = 0; i < ncmds; i++)
        printk("  %-10s : %s\n", cmds[i].name, cmds[i].desc);
    printk("\nFR : cat /etc/motd, cat /proc/version, demo pour voir l'ordonnanceur.\n");
    printk("EN : cat /etc/motd, cat /proc/version, demo to watch the scheduler.\n\n");
    return 0;
}

static int cmd_version(int argc, char **argv)
{
    (void)argc; (void)argv;
    u32 t = sys_uptime_ticks();
    printk("FreaxOS %s (%s) — %s\n", FREAX_RELEASE, FREAX_CODENAME,
           FREAX_TAGLINE);
    printk("noyau / kernel : C (gnu11), module Rust optionnel (style 2026)\n");
    printk("inspire de / inspired by : Linux 0.12 (GPL, fevrier 1992)\n");
    printk("build %s | %s | uptime %u.%02u s\n", FREAX_BUILD_DATE,
           g_hal_platform, t / FREAX_TICK_HZ, t % FREAX_TICK_HZ);
    char ri[96];
    if (freax_rust_info(ri, (int)sizeof(ri)) > 0)
        printk("module : %s\n", ri);
    return 0;
}

static int cmd_uname(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("FreaxOS %s %s\n", FREAX_RELEASE, g_hal_platform);
    return 0;
}

static int cmd_uptime(int argc, char **argv)
{
    (void)argc; (void)argv;
    u32 t = sys_uptime_ticks();
    printk("up %u.%02u s (%u ticks, %u commutations / switches)\n",
           t / FREAX_TICK_HZ, t % FREAX_TICK_HZ, t, sched_switch_count());
    return 0;
}

static int cmd_date(int argc, char **argv)
{
    (void)argc; (void)argv;
    u32 t = sys_uptime_ticks();
    printk("build %s — up %u.%02u s\n", FREAX_BUILD_DATE,
           t / FREAX_TICK_HZ, t % FREAX_TICK_HZ);
    return 0;
}

static int cmd_whoami(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("root\n");
    return 0;
}

static int cmd_clear(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("\x1b[2J\x1b[H");
    return 0;
}

static int cmd_mem(int argc, char **argv)
{
    (void)argc; (void)argv;
    struct mm_stats s;
    mm_get_stats(&s);
    printk("\nHeap / Tas :\n");
    printk("  total %u | used %u | free %u | peak %u octets/bytes\n",
           s.heap_size, s.used, s.free, s.peak_used);
    printk("  allocs %u | frees %u | fails %u | blocks %u | leaks %d\n",
           s.n_alloc, s.n_free, s.n_fail, s.n_blocks, mm_leak_count());
    printk("  integrite / integrity : %s\n\n",
           mm_check() == 0 ? "OK" : "CORROMPU/CORRUPTED");
    return 0;
}

static int cmd_ps(int argc, char **argv)
{
    (void)argc; (void)argv;
    char buf[1024];
    printk("PID  NAME           STATE  TICKS\n");
    sched_dump_tasks(buf, (int)sizeof(buf));
    printk("%s", buf);
    return 0;
}

static int cmd_sysinfo(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("\n");
    cmd_version(0, NULL);
    struct mm_stats s;
    mm_get_stats(&s);
    printk("taches / tasks : %d | commutations / switches : %u\n",
           sched_task_count(), sched_switch_count());
    printk("memoire / memory : %u/%u octets utilises (peak %u)\n\n",
           s.used, s.heap_size, s.peak_used);
    return 0;
}

static int cmd_sleep(int argc, char **argv)
{
    if (argc < 2) {
        printk("usage : sleep <secondes>\n");
        return 1;
    }
    int secs = freax_atoi(argv[1]);
    if (secs < 0 || secs > 3600) {
        printk("sleep : 0..3600 s\n");
        return 1;
    }
    sys_msleep((u32)(secs * FREAX_TICK_HZ));
    printk("slept %d s\n", secs);
    return 0;
}

static int cmd_halt(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("\x1b[2mFreaxOS s'arrete / FreaxOS is shutting down...\x1b[0m\n");
    sched_shutdown();
    return 0;
}

static int cmd_reboot(int argc, char **argv)
{
    (void)argc; (void)argv;
    sys_reboot();
    return 0;
}

static int cmd_license(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("\nFreaxOS 2026 — licence educative GNU GPL v2 (comme Linux 0.12\n");
    printk("depuis fevrier 1992). Le texte complet : fichier LICENSE du depot.\n");
    printk("Educational GNU GPL v2 license (like Linux 0.12 since Feb 1992).\n");
    printk("Full text: the LICENSE file in the repository.\n\n");
    return 0;
}

/* ---- fichiers / files ---- */

static int cmd_ls(int argc, char **argv)
{
    const char *path = (argc > 1) ? argv[1] : ".";
    struct vnode *d = vfs_resolve_dir(path);
    if (!d) {
        struct vnode *f = vfs_resolve(path);
        if (f && f->type == VNODE_FILE) {
            printk("%s\n", path);
            return 0;
        }
        printk("ls : '%s' introuvable ou pas un dossier / not found or not a directory\n",
               path);
        return 1;
    }
    vfs_list(d, ls_cb, NULL);
    printk("\n");
    return 0;
}

static int cmd_cd(int argc, char **argv)
{
    const char *path = (argc > 1) ? argv[1] : "/";
    struct vnode *d = vfs_resolve_dir(path);
    if (!d) {
        printk("cd : '%s' introuvable ou pas un dossier / not found or not a directory\n",
               path);
        return 1;
    }
    vfs_set_cwd(d);
    return 0;
}

static int cmd_pwd(int argc, char **argv)
{
    (void)argc; (void)argv;
    char path[256];
    vfs_path_of(vfs_cwd(), path, (int)sizeof(path));
    printk("%s\n", path);
    return 0;
}

static int cmd_cat(int argc, char **argv)
{
    if (argc < 2) {
        printk("usage : cat <fichier>\n");
        return 1;
    }
    for (int a = 1; a < argc; a++) {
        int fd = sys_open(argv[a], 0);
        if (fd < 0) {
            printk("cat : '%s' introuvable / not found\n", argv[a]);
            continue;
        }
        char buf[512];
        int n;
        while ((n = sys_read(fd, buf, (int)sizeof(buf))) > 0)
            sys_write(FD_STDOUT, buf, n);
        sys_close(fd);
    }
    return 0;
}

static int cmd_write(int argc, char **argv)
{
    if (argc < 3) {
        printk("usage : write <fichier> <texte...>\n");
        return 1;
    }
    int fd = sys_open(argv[1], 1);          /* 'w' tronque / truncates */
    if (fd < 0) {
        printk("write : impossible d'ouvrir / cannot open '%s'\n", argv[1]);
        return 1;
    }
    for (int a = 2; a < argc; a++) {
        if (a > 2)
            sys_write(fd, " ", 1);
        sys_write(fd, argv[a], (int)strlen(argv[a]));
    }
    sys_write(fd, "\n", 1);
    sys_close(fd);
    return 0;
}

static int cmd_touch(int argc, char **argv)
{
    if (argc < 2) {
        printk("usage : touch <fichier>\n");
        return 1;
    }
    struct vnode *v = vfs_resolve(argv[1]);
    if (v)
        return 0;
    v = vfs_create(argv[1]);
    if (!v) {
        printk("touch : impossible de creer / cannot create '%s'\n", argv[1]);
        return 1;
    }
    return 0;
}

static int cmd_mkdir(int argc, char **argv)
{
    if (argc < 2) {
        printk("usage : mkdir <dossier>\n");
        return 1;
    }
    struct vnode *v = vfs_mkdir(argv[1]);
    if (!v) {
        printk("mkdir : impossible / cannot create '%s'\n", argv[1]);
        return 1;
    }
    return 0;
}

static int cmd_rm(int argc, char **argv)
{
    if (argc < 2) {
        printk("usage : rm <fichier>\n");
        return 1;
    }
    int rc = vfs_unlink(argv[1]);
    cmd_result_msg("rm", rc);
    return rc;
}

static int cmd_echo(int argc, char **argv)
{
    for (int a = 1; a < argc; a++) {
        if (a > 1)
            printk(" ");
        printk("%s", argv[a]);
    }
    printk("\n");
    return 0;
}

/* ---- outils dev / dev tools ---- */

static int cmd_crc32(int argc, char **argv)
{
    if (argc < 2) {
        printk("usage : crc32 <texte> | crc32 <chemin/absolu>\n");
        return 1;
    }
    struct vnode *f = (argv[1][0] == '/') ? vfs_resolve(argv[1]) : NULL;
    if (f && f->type == VNODE_FILE && !f->is_dynamic) {
        char buf[512];
        u32 pos = 0;
        int n = vfs_read(f, buf, (int)sizeof(buf), &pos);
        u32 crc = (n > 0) ? freax_crc32((const u8 *)buf, (u32)n, 0) : 0;
        printk("crc32(\"%s\") = 0x%08x (%d octets / bytes)\n", argv[1], crc, n);
        return 0;
    }
    u32 crc = freax_crc32((const u8 *)argv[1], (u32)strlen(argv[1]), 0);
    printk("crc32(\"%s\") = 0x%08x\n", argv[1], crc);
    return 0;
}

static int cmd_tux(int argc, char **argv)
{
    (void)argc; (void)argv;
    char buf[512];
    int lines = freax_tux_lines(buf, (int)sizeof(buf));
    if (lines > 0) {
        printk("%s", buf);
        printk("\x1b[2mMascotte : Tux par Larry Ewing (1996) — hommage. / Tux by Larry Ewing (1996), tribute.\x1b[0m\n");
    }
    return 0;
}

/* ---- demo d'ordonnancement / scheduling demo ---- */

static volatile int g_demo_cnt[3];

static void demo_task(int idx, const char *color)
{
    for (int i = 1; i <= 8; i++) {
        g_demo_cnt[idx]++;
        printk("%stask-%d \x1b[2mtick %d\x1b[0m\n", color, idx + 1, i);
        sys_msleep(2);                      /* 2 ticks par pas / 2 ticks/step */
    }
    task_exit(0);
}

static void demo1(void) { demo_task(0, "\x1b[31m"); }
static void demo2(void) { demo_task(1, "\x1b[33m"); }
static void demo3(void) { demo_task(2, "\x1b[36m"); }

static int cmd_demo(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk("\nFR : trois taches round-robin (sleep 2 ticks/pas). Voici le partage :\n");
    printk("EN : three round-robin tasks (sleep 2 ticks/step). Watch the interleave:\n\n");
    g_demo_cnt[0] = g_demo_cnt[1] = g_demo_cnt[2] = 0;
    int p1 = sys_spawn("demo1", demo1);
    int p2 = sys_spawn("demo2", demo2);
    int p3 = sys_spawn("demo3", demo3);
    int code, done = 0;
    if (p1 > 0 && sys_wait(p1, &code) == p1) done++;
    if (p2 > 0 && sys_wait(p2, &code) == p2) done++;
    if (p3 > 0 && sys_wait(p3, &code) == p3) done++;
    printk("\nFR : %d taches finies — tours fair-play : %d/%d/%d ticks.\n",
           done, g_demo_cnt[0], g_demo_cnt[1], g_demo_cnt[2]);
    printk("EN : %d tasks done — fair slices: %d/%d/%d.\n\n",
           done, g_demo_cnt[0], g_demo_cnt[1], g_demo_cnt[2]);
    return 0;
}

/* ---- easter eggs historiques / history easter eggs ---- */

static int cmd_about(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk(
        "\nFreaxOS 2026 — « le 0.12, reconstruit pour les developpeurs »\n"
        "\n"
        "En fevrier 1992, Linus Torvalds diffuse la version 0.12 de son\n"
        "noyau hobby sous licence GNU GPL : c'est l'acte de naissance\n"
        "juridique du noyau Linux. FreaxOS 2026 rejoue ce moment : un petit\n"
        "noyau lisible, multitache, multi-taches, avec ramfs, /proc, shell\n"
        "et tests unitaires — pense pour etre LU et MODIFIE.\n"
        "\n"
        "In February 1992, Linus Torvalds released kernel version 0.12\n"
        "under the GNU GPL: the legal birth certificate of Linux. FreaxOS\n"
        "2026 replays that moment: a small readable kernel, multitasking,\n"
        "with a ramfs, /proc, a shell and unit tests — meant to be READ\n"
        "and MODIFIED.\n\n");
    return 0;
}

/* ---- table / table ---- */

static const struct command g_commands[] = {
    { "help",      "aide des commandes / command help",              cmd_help },
    { "version",   "version du noyau / kernel version",              cmd_version },
    { "uname",     "nom du systeme / system name",                   cmd_uname },
    { "uptime",    "temps de fonctionnement / uptime",               cmd_uptime },
    { "date",      "date de build + uptime",                         cmd_date },
    { "whoami",    "utilisateur courant / current user",             cmd_whoami },
    { "sysinfo",   "resume systeme / system summary",                cmd_sysinfo },
    { "mem",       "statistiques memoire / memory stats",            cmd_mem },
    { "ps",        "taches en cours / running tasks",                cmd_ps },
    { "ls",        "liste un dossier / list a directory",            cmd_ls },
    { "cd",        "change de dossier / change directory",           cmd_cd },
    { "pwd",       "dossier courant / working directory",            cmd_pwd },
    { "cat",       "affiche un fichier / print a file",              cmd_cat },
    { "write",     "ecrit un fichier / write a file",                cmd_write },
    { "touch",     "cree un fichier vide / create an empty file",    cmd_touch },
    { "mkdir",     "cree un dossier / create a directory",           cmd_mkdir },
    { "rm",        "supprime un fichier / remove a file",            cmd_rm },
    { "echo",      "affiche ses arguments / print arguments",        cmd_echo },
    { "crc32",     "CRC32 (module Rust ou C) / CRC32 checksum",      cmd_crc32 },
    { "tux",       "affiche Tux / show the mascot",                  cmd_tux },
    { "demo",      "demo d'ordonnanceur / scheduler demo",           cmd_demo },
    { "sleep",     "pause N secondes / pause N seconds",             cmd_sleep },
    { "clear",     "efface l'ecran / clear screen",                  cmd_clear },
    { "history",   "dernieres commandes / recent commands",          cmd_history },
    { "license",   "licence GPL v2",                                 cmd_license },
    { "reboot",    "redemarre / reboot",                             cmd_reboot },
    { "halt",      "eteint FreaxOS / shut FreaxOS down",             cmd_halt },
    { "about",     "histoire 1991-2026 / the 1991-2026 story",       cmd_about },
    { "justforfun","l'annonce du 25 aout 1991 / the 1991 Usenet post", cmd_egg_justforfun },
    { "tanenbaum", "le debat de janvier 1992 / the 1992 debate",     cmd_egg_tanenbaum },
    { "freax",     "pourquoi « Freax » ? / why \"Freax\"?",          cmd_egg_freax },
    { "v012",      "0.12 passe en GPL (fev. 1992) / 0.12 goes GPL",  cmd_egg_v012 },
};

const struct command *shell_commands(int *count)
{
    *count = (int)(sizeof(g_commands) / sizeof(g_commands[0]));
    return g_commands;
}
