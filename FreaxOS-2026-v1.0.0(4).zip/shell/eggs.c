/*
 * FreaxOS 2026 - shell/eggs.c
 * Commande history + easter eggs historiques / history + history eggs.
 *
 * FR : Les citations ci-dessous sont des extraits reels et documentes des
 *      archives Usenet (comp.os.minix, aout 1991 / janvier 1992).
 * EN : The quotes below are real, documented excerpts from the Usenet
 *      archives (comp.os.minix, August 1991 / January 1992).
 */
#include "freax/shell.h"
#include "freax/printk.h"
#include "freax/config.h"
#include "freax/libc.h"

#define SHELL_LINE_MAX 256
#define SHELL_HIST_MAX 16

static char g_hist[SHELL_HIST_MAX][SHELL_LINE_MAX];
static int  g_hist_count;
static int  g_hist_next;

void shell_history_add(const char *line)
{
    strncpy(g_hist[g_hist_next], line, SHELL_LINE_MAX - 1);
    g_hist[g_hist_next][SHELL_LINE_MAX - 1] = '\0';
    g_hist_next = (g_hist_next + 1) % SHELL_HIST_MAX;
    if (g_hist_count < SHELL_HIST_MAX)
        g_hist_count++;
}

int cmd_history(int argc, char **argv)
{
    (void)argc; (void)argv;
    int first = (g_hist_count == SHELL_HIST_MAX)
                    ? g_hist_next
                    : 0;
    for (int i = 0; i < g_hist_count; i++) {
        int idx = (first + i) % SHELL_HIST_MAX;
        printk("  %2d  %s\n", i + 1, g_hist[idx]);
    }
    if (!g_hist_count)
        printk("  (vide / empty)\n");
    return 0;
}

/* ---- easter eggs / easter eggs ---- */

int cmd_egg_justforfun(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk(
        "\n\x1b[1;33mcomp.os.minix - 25 aout 1991 - 25 August 1991\x1b[0m\n"
        "De Linus Benedict Torvalds :\n"
        "\"Hello everybody out there using minix -\n"
        " I'm doing a (free) operating system (just a hobby, won't be big\n"
        " and professional like gnu)... I'd like any feedback on things\n"
        " people like/dislike in minix, as my OS resembles it somewhat...\"\n\n"
        "FR : « juste un hobby ». 35 ans plus tard, le hobby fait tourner\n"
        "     le monde. FreaxOS 2026 rejoue ce moment avec ses propres mains.\n"
        "EN : \"just a hobby\". Thirty-five years later, the hobby runs the\n"
        "     world. FreaxOS 2026 replays that moment, hands-on.\n\n");
    return 0;
}

int cmd_egg_tanenbaum(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk(
        "\n\x1b[1;33mLe debat / The debate - comp.os.minix, janvier / January 1992\x1b[0m\n"
        "Andrew S. Tanenbaum (auteur de Minix) :\n"
        "\"LINUX is obsolete... [it] is a monolithic style system.\" —\n"
        "pour lui, un noyau moderne devait etre un micro-noyau.\n"
        "(for him a modern kernel had to be a microkernel.)\n"
        "Linus Torvalds repond notamment / famously replies:\n"
        "\"If GNU had been available last spring, I would not have bothered\n"
        " to even start my project.\"\n\n"
        "FR : FreaxOS assume le choix monolithique educatif du 0.12,\n"
        "     tout en restant un kit a decortiquer.\n"
        "EN : FreaxOS embraces the educational monolithic choice of 0.12,\n"
        "     while staying a kit meant to be dissected.\n\n");
    return 0;
}

int cmd_egg_freax(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk(
        "\n\x1b[1;33mPourquoi « Freax » / Why \"Freax\" ?\x1b[0m\n"
        "Le projet s'appelait d'abord « Freax » : free + freak + le x\n"
        "d'UNIX. Ari Lemmke, administrateur du serveur FTP ftp.funet.fi,\n"
        "prefere « linux » pour le repertoire d'hebergement (septembre\n"
        "1991) : le nom reste. FreaxOS rend son nom d'origine au noyau\n"
        "educatif, en hommage.\n\n"
        "The project was first called \"Freax\": free + freak + the x of\n"
        "UNIX. Ari Lemmke, FTP admin at ftp.funet.fi, preferred \"linux\"\n"
        "for the hosting directory (September 1991); the name stuck.\n"
        "FreaxOS gives the educational kernel its original name back,\n"
        "as a tribute.\n\n");
    return 0;
}

int cmd_egg_v012(int argc, char **argv)
{
    (void)argc; (void)argv;
    printk(
        "\n\x1b[1;33m0.12 - fevrier 1992 - February 1992\x1b[0m\n"
        "La version 0.12 est la premiere diffusee sous licence publique\n"
        "generale GNU (GPL) a la place de la licence ad hoc qui interdisait\n"
        "la redistribution commerciale. C'est LE moment fondateur :\n"
        "les contributions externes explosent, et le modele de\n"
        "developpement ouvert du noyau devient possible.\n\n"
        "Version 0.12 is the first released under the GNU General Public\n"
        "License (GPL), replacing the ad hoc license that forbade\n"
        "commercial redistribution. THE founding moment: external\n"
        "contributions explode, and the open kernel development model\n"
        "becomes possible.\n\n");
    return 0;
}
