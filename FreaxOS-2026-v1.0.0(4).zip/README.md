# FreaxOS 2026

**FR — version française** (English: see [README.en.md](README.en.md))

> « Le noyau de 1992, reconstruit pour les développeurs de 2026. »
> "The 1992 kernel, rebuilt for 2026 developers."

FreaxOS 2026 est un **noyau éducatif complet** qui rejoue le moment fondateur
de février 1992 — la version 0.12 du noyau de Linus Torvalds, première
diffusée sous licence GNU GPL — avec les idées et le confort de 2026 :
petit, lisible, entièrement commenté bilingue, avec tests unitaires et un
outilage `make` moderne. Il rend au noyau son nom d'origine, **Freax**
(free + freak + x), choisi par Linus avant qu'Ari Lemmke ne rebaptise le
dossier FTP « linux ».

C'est un **kit à lire et à modifier**, pas une réimplémentation de Linux :
~5 200 lignes de C, d'asm x86 et de Rust, tout compris.

---

## Ce que contient le kit

| Composant | Fichiers | Rôle |
|---|---|---|
| Noyau portable | `kernel/` | printk + journal klog, allocateur first-fit avec coalescence, ordonnanceur round-robin avec file de sommeil, appels système, ramfs + mini `/proc` |
| Shell `freaxsh` | `shell/` | 30+ commandes, historique, easter eggs historiques (25 août 1991, débat Tanenbaum…) |
| Simulateur | `sim/` | le même noyau dans n'importe quel terminal Linux/macOS, sans VM (`ucontext`, terminal semi-brut) |
| **Bureau Liquid Glass** | `desktop/` | bureau graphique complet relié au noyau : fenêtres, barre translucide floutée, launcher, desklets, 10 apps (Terminal réel, Navigateur HTML, Boutique d'apps, Réglages, Extensions…) — rendu 100 % logiciel ARGB32, affiché en X11 (`dlopen`, zéro dépendance de build) |
| Bare-metal i386 | `baremetal/` | boot multiboot, GDT/IDT, PIC, PIT 100 Hz, VGA 80×25, clavier PS/2, série COM1, **splash graphique « Liquid Glass » en mode 13h** — tourne sous `qemu-system-i386 -kernel` |
| Module Rust optionnel | `rust/freax_rust/` | CRC32 (table générée à la compilation) + mascotte Tux, `no_std` ; repli C automatique si cargo est absent |
| Tests | `tests/` | 8 suites, **398 vérifications, 100 % vertes** (`make test`) |
| Docs | `docs/` | architecture, bureau Liquid Glass, build, histoire 1991→2026, session de démo — captures du bureau dans `docs/img/` |

## Démarrage rapide

```bash
make                   # construit sim + tests + bureau (+ noyau i386 si gcc -m32)
make test              # 398 vérifications unitaires
./build/freax-sim      # le noyau dans votre terminal
./build/freax-desktop  # le bureau Liquid Glass dans une fenêtre X11
```

Aperçu du bureau sans rien compiler : ouvrez les captures `docs/img/*.png`
(inclues dans le zip), ou générez les vôtres sans écran :

```bash
make shot   # 6 scènes du bureau rendues en PPM/PNG dans docs/img/
```

Dans le shell (`freaxsh`) :

```
freax:/> ls /proc
freax:/> cat /proc/version
freax:/> demo            ← trois tâches round-robin en direct
freax:/> justforfun      ← l'annonce Usenet du 25 août 1991
freax:/> crc32 123456789
freax:/> tux
freax:/> halt
```

Une commande sans interactivité :

```bash
./build/freax-sim -c "ls /proc"
./build/freax-sim --script docs/demo-session.txt
```

Le noyau bare-metal (i386, multiboot) :

```bash
make baremetal
make run       # qemu-system-i386 -kernel build/freax-i386.elf -serial stdio
make smoke     # boot sans écran + vérification de la bannière sur COM1
```

Le boot affiche d'abord le **splash graphique Liquid Glass** (mode VGA 13h,
4 s ou touche), puis le shell texte — même scénario que sur une clé USB
bootable (voir `docs/DESKTOP.md`).

## Les idées « 2026 » par rapport à 1992

- **Un code lisible avant tout** : chaque fichier commence par un commentaire
  bilingue qui explique le pourquoi ; le 0.12 exigeait de déchiffrer.
- **Des tests unitaires** (`make test`) sur l'allocateur, l'ordonnanceur, le
  VFS, les syscalls, le shell et le formatage — impensable en 1992.
- **Rust à côté du C**, comme le noyau moderne : CRC32 et Tux en `no_std`,
  avec repli C automatique (`FREAX_NO_RUST=1` pour forcer).
- **Un journal noyau consultable** : `cat /proc/klog` renvoie les 4 derniers
  Kio de `printk`.
- **Une file de sommeil réelle** : `sleep` bloque la tâche (0 spin CPU),
  réveillée au tick voulu par l'ordonnanceur.
- **Un rapport de fuites à l'extinction** : `halt` libère tout et affiche le
  pic mémoire et les blocs restants.
- **Un bureau graphique relié au noyau** : le Terminal exécute le vrai
  `freaxsh`, Fichiers et l'Éditeur passent par le VFS, le Moniteur lit
  `/proc`, la Boutique installe des bundles dans `/apps` via des syscalls —
  le tout dessiné dans un framebuffer ARGB32 maison, style « liquid glass ».
- **Un outillage unique** : `make sim`, `make test`, `make baremetal`,
  `make desktop`, `make shot`, `make run`, `make smoke`, `make zip` — tout
  est automatisé.

## Ce que ce kit n'est pas (assumé)

- Pas de vraie préemption : l'ordonnanceur est **coopératif** (yield, bloque,
  sommeil) — choix éducatif documenté dans `docs/ARCHITECTURE.md`.
- Pas de `fork()` : `sys_spawn` crée une tâche avec sa propre pile ; le
  parent peut `wait` (sémantique waitpid, zombies compris).
- Pas de pagination ni de séparation utilisateur/noyau : un seul espace
  d'adressage, comme un kit.
- Pas de disque : le ramfs est volatile.

## Documentation

- `docs/ARCHITECTURE.md` — le noyau module par module
- `docs/DESKTOP.md` — le bureau Liquid Glass : architecture, apps, thèmes,
  API d'installation, X11 et captures


- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — couches, choix de
  conception, tableau des appels système, comparaison honnête avec 0.12.
- [docs/BUILD.md](docs/BUILD.md) — prérequis, cibles make, dépannage.
- [docs/HISTORY.md](docs/HISTORY.md) — la chronologie 1991→2026 et ce que
  FreaxOS en rejoue.
- [docs/demo-session.txt](docs/demo-session.txt) — une session complète.
- [TEST_REPORT.txt](TEST_REPORT.txt) — la sortie des tests du build.

## Licence et crédits

FreaxOS est distribué sous **GNU GPL v2**, en écho au passage en GPL de la
version 0.12 en février 1992 (voir [LICENSE](LICENSE)).

Crédits historiques : Linus Torvalds (noyau, 1991), Ari Lemmke (le nom),
Andrew S. Tanenbaum (le débat qui l'a fait connaitre), Larry Ewing
(mascotte Tux, 1996), la communauté du noyau Linux depuis. FreaxOS est un
hommage éducatif indépendant — il n'est ni Linux ni un dérivé du code du
noyau Linux.
