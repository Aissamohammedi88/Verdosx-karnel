/*
 * FreaxOS 2026 - kernel/syscall.c
 * Appels système / System calls.
 *
 * FR : fds 0/1/2 = console ; 3.. = fichiers vfs. sys_read sur stdin renvoie
 *      -2 (EAGAIN) quand rien n'est disponible : le shell boucle en yield —
 *      c'est ce qui fait tourner les autres tâches pendant l'attente.
 * EN : fds 0/1/2 = console; 3.. = vfs files. sys_read on stdin returns -2
 *      (EAGAIN) when nothing is available: the shell loops with yield — which
 *      is what keeps other tasks running while we wait.
 */
#include "freax/syscall.h"
#include "freax/sched.h"
#include "freax/vfs.h"
#include "freax/hal.h"
#include "freax/printk.h"
#include "freax/mm.h"
#include "freax/shell.h"
#include "freax/config.h"

#define EAGAIN -2
#define EBADF  -3

int sys_read(int fd, char *buf, int len)
{
    if (!buf || len <= 0)
        return -1;
    if (fd == FD_STDIN) {
        int c = console_trygetc();
        if (c < 0)
            return EAGAIN;
        buf[0] = (char)c;
        return 1;
    }
    return vfs_fd_read(fd, buf, len);
}

int sys_write(int fd, const char *buf, int len)
{
    if (!buf || len < 0)
        return -1;
    if (fd == FD_STDOUT || fd == FD_STDERR) {
        console_write(buf, len);
        return len;
    }
    return vfs_fd_write(fd, buf, len);
}

int sys_open(const char *path, int mode)
{
    if (!path)
        return -1;
    struct vnode *v = vfs_resolve(path);
    if (!v) {
        if (mode == 0)      /* 'r' : doit exister / must exist */
            return -1;
        v = vfs_create(path);
        if (!v)
            return -1;
    }
    if (v->type == VNODE_DIR)
        return -1;
    return vfs_fd_open(v, mode);
}

int sys_close(int fd)
{
    if (fd <= FD_STDERR || fd >= FREAX_MAX_OPEN)
        return -1;
    vfs_fd_close(fd);
    return 0;
}

int sys_getpid(void)
{
    return sched_current_pid();
}

int sys_spawn(const char *name, void (*entry)(void))
{
    return sched_spawn(name, entry, 0);
}

int sys_wait(int pid, int *exit_code)
{
    return task_wait(pid, exit_code);
}

u32 sys_uptime_ticks(void)
{
    return g_hal ? g_hal->ticks() : 0;
}

void sys_msleep(u32 ticks)
{
    if (!g_hal)
        return;
    task_sleep_ticks(ticks);
}

void sys_reboot(void)
{
    if (g_hal)
        g_hal->shutdown(1);
    kpanic("reboot : HAL absent");
}

/* ---- dispatch générique / generic dispatch ---- */

typedef long (*sys_fn)(long, long, long);

static long sc_exit(long code, long _b, long _c)
{
    (void)_b; (void)_c;
    task_exit((int)code);       /* noreturn / ne revient jamais */
    return 0;
}

static long sc_read(long fd, long buf, long len)
{
    return sys_read((int)fd, (char *)(freax_uptr)buf, (int)len);
}

static long sc_write(long fd, long buf, long len)
{
    return sys_write((int)fd, (const char *)(freax_uptr)buf, (int)len);
}

static long sc_open(long path, long mode, long _c)
{
    (void)_c;
    return sys_open((const char *)(freax_uptr)path, (int)mode);
}

static long sc_close(long fd, long _b, long _c)
{
    (void)_b; (void)_c;
    return sys_close((int)fd);
}

static long sc_getpid(long _a, long _b, long _c)
{
    (void)_a; (void)_b; (void)_c;
    return sys_getpid();
}

static long sc_spawn(long name, long entry, long _c)
{
    (void)_c;
    return sys_spawn((const char *)(freax_uptr)name,
                     (void (*)(void))(freax_uptr)entry);
}

static long sc_wait(long pid, long code, long _c)
{
    (void)_c;
    return task_wait((int)pid, (int *)(freax_uptr)code);
}

static long sc_uptime(long _a, long _b, long _c)
{
    (void)_a; (void)_b; (void)_c;
    return (long)sys_uptime_ticks();
}

static long sc_msleep(long ticks, long _b, long _c)
{
    (void)_b; (void)_c;
    sys_msleep((u32)ticks);
    return 0;
}

/* Table éducative : numéros choisis, trous volontaires / educational table:
 * chosen numbers, deliberate gaps. */
static const sys_fn g_sys_table[] = {
    [SYS_exit]   = sc_exit,
    [SYS_read]   = sc_read,
    [SYS_write]  = sc_write,
    [SYS_open]   = sc_open,
    [SYS_close]  = sc_close,
    [SYS_getpid] = sc_getpid,
    [SYS_spawn]  = sc_spawn,
    [SYS_wait]   = sc_wait,
    [SYS_uptime] = sc_uptime,
    [SYS_msleep] = sc_msleep,
};

int syscall(int num, long a, long b, long c)
{
    if (num < 0 || (u32)num >= sizeof(g_sys_table) / sizeof(g_sys_table[0]))
        goto bad;
    if (!g_sys_table[num])
        goto bad;
    return (int)g_sys_table[num](a, b, c);
bad:
    printk("syscall : numero inconnu %d\n", num);
    return -1;
}
