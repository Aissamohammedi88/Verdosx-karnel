/*
 * FreaxOS 2026 - kernel/mm.c
 * Allocateur first-fit avec coalescence / First-fit allocator with coalescing.
 *
 * FR : Un seul amas contigu. Chaque bloc porte un en-tête, la liste est
 *      chaînée en ordre d'adresse, la libération fusionne avec les voisins
 *      libres. mm_check() permet un contrôle d'intégrité (tests).
 * EN : One contiguous heap. Each block has a header, blocks are linked in
 *      address order, and freeing coalesces with free neighbours. mm_check()
 *      provides an integrity walk (tests).
 */
#include "freax/mm.h"
#include "freax/printk.h"

#define MB_MAGIC   0xFEA12026u
#define MB_ALIGN   16u
#define MB_MIN     32u   /* plus petit bloc utile / smallest useful block */

struct mblock {
    u32 magic;
    u32 size;          /* taille des données / payload size */
    u32 used;
    u32 pad;           /* aligne l'en-tête sur 16 octets / 16-byte header  */
    struct mblock *next;
    struct mblock *prev;
};

static u8  *g_base;
static u32  g_size;
static struct mblock *g_head;
static struct mm_stats g_stats;

void mm_init(void *base, u32 size)
{
    freax_uptr b = (freax_uptr)base;
    b = (b + MB_ALIGN - 1) & ~(freax_uptr)(MB_ALIGN - 1);
    if (size < MB_ALIGN * 4)
        size = 0;
    else {
        u32 lost = (u32)(b - (freax_uptr)base);
        size = (size > lost) ? size - lost : 0;
        size &= ~(u32)(MB_ALIGN - 1);
    }

    g_base = (u8 *)b;
    g_size = size;
    g_stats.heap_size = size;
    g_stats.used = g_stats.free = 0;
    g_stats.peak_used = g_stats.n_alloc = g_stats.n_free = 0;
    g_stats.n_fail = g_stats.n_blocks = 0;
    g_head = NULL;

    if (size >= sizeof(struct mblock)) {
        g_head = (struct mblock *)g_base;
        g_head->magic = MB_MAGIC;
        g_head->size = size - sizeof(struct mblock);
        g_head->used = 0;
        g_head->pad = 0;
        g_head->next = g_head->prev = g_head;
        g_stats.n_blocks = 1;
        g_stats.free = g_head->size;
    } else {
        printk("mm : heap trop petit (%u octets)\n", size);
    }
}

static struct mblock *block_of(void *p)
{
    return (struct mblock *)((u8 *)p - sizeof(struct mblock));
}

static void *payload_of(struct mblock *b)
{
    return (u8 *)b + sizeof(struct mblock);
}

static void stats_use(i32 delta)
{
    if (delta < 0) {
        u32 d = (u32)(-delta);
        g_stats.used = (g_stats.used >= d) ? g_stats.used - d : 0;
    } else {
        g_stats.used += (u32)delta;
        if (g_stats.used > g_stats.peak_used)
            g_stats.peak_used = g_stats.used;
    }
}

static void split_block(struct mblock *b, u32 need)
{
    /* découpe si le reste peut former un bloc / split when remainder fits */
    if (b->size >= need + sizeof(struct mblock) + MB_MIN) {
        struct mblock *r = (struct mblock *)((u8 *)payload_of(b) + need);
        r->magic = MB_MAGIC;
        r->size = b->size - need - sizeof(struct mblock);
        r->used = 0;
        r->pad = 0;
        r->next = b->next;
        r->prev = b;
        b->next->prev = r;
        b->next = r;
        b->size = need;
        g_stats.n_blocks++;
        /* le nouvel en-tête sort du pool libre / new header leaves the pool */
        g_stats.free -= (u32)sizeof(struct mblock);
    }
}

void *kmalloc(u32 size)
{
    if (size == 0)
        size = 1;
    u32 need = (size + MB_ALIGN - 1) & ~(u32)(MB_ALIGN - 1);
    g_stats.n_alloc++;

    if (!g_head)
        goto fail;

    for (struct mblock *b = g_head;; b = b->next) {
        if (!b->used && b->size >= need) {
            split_block(b, need);
            b->used = 1;
            g_stats.free -= b->size;
            stats_use((i32)b->size);
            return payload_of(b);
        }
        if (b->next == g_head)
            break;
    }
fail:
    g_stats.n_fail++;
    return NULL;
}

void *kmalloc_zero(u32 size)
{
    u8 *p = (u8 *)kmalloc(size);
    if (p) {
        for (u32 i = 0; i < size; i++)
            p[i] = 0;
    }
    return p;
}

static void coalesce_right(struct mblock *b)
{
    /* fusionne tant que le suivant est libre / merge while next is free */
    while (b->next != b && !b->next->used &&
           (u8 *)payload_of(b) + b->size == (u8 *)b->next) {
        struct mblock *n = b->next;
        b->size += sizeof(struct mblock) + n->size;
        n->magic = 0;
        b->next = n->next;
        n->next->prev = b;
        g_stats.n_blocks--;
        /* l'en-tête absorbé retourne au pool libre / absorbed header returns */
        g_stats.free += (u32)sizeof(struct mblock);
    }
}

void kfree(void *p)
{
    if (!p)
        return;
    struct mblock *b = block_of(p);
    if (b->magic != MB_MAGIC || !b->used) {
        printk("mm : kfree invalide (%p)\n", p);
        return;
    }
    g_stats.n_free++;
    b->used = 0;
    g_stats.free += b->size;
    stats_use(-(i32)b->size);
    if (b->prev != b && !b->prev->used &&
        (u8 *)payload_of(b->prev) + b->prev->size == (u8 *)b) {
        /* fusion par la gauche / merge leftward */
        b = b->prev;
        b->size += sizeof(struct mblock) + block_of(p)->size;
        b->next->magic = 0;
        b->next = b->next->next;
        b->next->prev = b;
        g_stats.n_blocks--;
        g_stats.free += (u32)sizeof(struct mblock);
    }
    coalesce_right(b);
}

void mm_get_stats(struct mm_stats *out)
{
    *out = g_stats;
}

int mm_check(void)
{
    if (!g_head)
        return 0;
    u32 seen_blocks = 0, sum_used = 0, sum_free = 0;
    for (struct mblock *b = g_head;; b = b->next) {
        if (b->magic != MB_MAGIC)
            return -1;
        if (b->next->prev != b || b->prev->next != b)
            return -1;
        seen_blocks++;
        if (b->used)
            sum_used += b->size;
        else
            sum_free += b->size;
        if (b->next == g_head)
            break;
    }
    if (seen_blocks != g_stats.n_blocks)
        return -1;
    if (sum_used != g_stats.used || sum_free != g_stats.free)
        return -1;
    return 0;
}

int mm_leak_count(void)
{
    int n = 0;
    if (!g_head)
        return 0;
    for (struct mblock *b = g_head;; b = b->next) {
        if (b->used)
            n++;
        if (b->next == g_head)
            break;
    }
    return n;
}
