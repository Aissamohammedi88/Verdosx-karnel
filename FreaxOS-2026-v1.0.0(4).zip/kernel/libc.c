/*
 * FreaxOS 2026 - kernel/libc.c
 * Mini-libc du noyau (freestanding) / Kernel mini-libc (freestanding).
 *
 * FR : Ces fonctions remplacent la libc pour tout le noyau portable. Elles
 *      sont réentrantes et sans état global. En mode hébergé, leurs symboles
 *      écrasent ceux de la libc pour les objets du noyau uniquement.
 * EN : These functions stand in for libc across the portable kernel. They are
 *      reentrant and stateless. In hosted mode their symbols override libc's
 *      for kernel objects only.
 */
#include "freax/types.h"

void *memset(void *dst, int c, freax_size n)
{
    u8 *d = (u8 *)dst;
    while (n--)
        *d++ = (u8)c;
    return dst;
}

void *memcpy(void *dst, const void *src, freax_size n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    while (n--)
        *d++ = *s++;
    return dst;
}

void *memmove(void *dst, const void *src, freax_size n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    if (d == s || n == 0)
        return dst;
    if (d < s) {
        while (n--)
            *d++ = *s++;
    } else {
        d += n;
        s += n;
        while (n--)
            *--d = *--s;
    }
    return dst;
}

int memcmp(const void *a, const void *b, freax_size n)
{
    const u8 *x = (const u8 *)a, *y = (const u8 *)b;
    while (n--) {
        if (*x != *y)
            return (int)*x - (int)*y;
        x++;
        y++;
    }
    return 0;
}

freax_size strlen(const char *s)
{
    const char *p = s;
    while (*p)
        p++;
    return (freax_size)(p - s);
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) {
        a++;
        b++;
    }
    return (int)(u8)*a - (int)(u8)*b;
}

int strncmp(const char *a, const char *b, freax_size n)
{
    while (n && *a && *a == *b) {
        a++;
        b++;
        n--;
    }
    if (n == 0)
        return 0;
    return (int)(u8)*a - (int)(u8)*b;
}

char *strncpy(char *dst, const char *src, freax_size n)
{
    freax_size i = 0;
    for (; i < n && src[i]; i++)
        dst[i] = src[i];
    for (; i < n; i++)
        dst[i] = '\0';
    return dst;
}

char *strchr(const char *s, int c)
{
    for (; *s; s++)
        if (*s == (char)c)
            return (char *)s;
    return (c == '\0') ? (char *)s : NULL;
}

char *strrchr(const char *s, int c)
{
    const char *found = NULL;
    for (; *s; s++)
        if (*s == (char)c)
            found = s;
    if (c == '\0')
        return (char *)s;
    return (char *)found;
}

int tolower(int c)
{
    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}

int toupper(int c)
{
    return (c >= 'a' && c <= 'z') ? c - 32 : c;
}

/* Parsing décimal minimal pour le shell (atoi) / minimal decimal parse. */
int freax_atoi(const char *s)
{
    int v = 0, neg = 0;
    if (*s == '-') {
        neg = 1;
        s++;
    }
    while (*s >= '0' && *s <= '9') {
        v = v * 10 + (*s - '0');
        s++;
    }
    return neg ? -v : v;
}
