/*
 * FreaxOS 2026 - kernel/kernel.c
 * Amorce et arrêt du noyau portable / Portable kernel boot & shutdown.
 */
#include "freax/kernel.h"
#include "freax/hal.h"
#include "freax/config.h"
#include "freax/mm.h"
#include "freax/vfs.h"
#include "freax/sched.h"
#include "freax/shell.h"
#include "freax/printk.h"

extern const char *g_hal_platform;   /* défini par le HAL / set by the HAL */

static const char banner[] =
    "\x1b[1;36m"
    " ____                 ___  ___  ____ \n"
    "|  _ \\ _ __ ___  ___ / _ \\/ _ \\/ ___|\n"
    "| | | | '__/ _ \\/ _ \\ | | | | | \\___ \\\n"
    "| |_| | | |  __/  __/ |_| | |_| |___) |\n"
    "|____/|_|  \\___|\\___|\\__\\_\\___/|____/ \n"
    "\x1b[0m";

static void print_banner(void)
{
    printk("%s", banner);
    printk("FreaxOS 2026 v%s (%s) — %s\n", FREAX_RELEASE, FREAX_CODENAME,
           FREAX_TAGLINE);
    printk("Inspire du noyau Linux 0.12 (GNU GPL, fevrier 1992).\n");
    printk("Inspired by the Linux 0.12 kernel (GNU GPL, February 1992).\n");
    printk("Build %s | plateforme : %s\n", FREAX_BUILD_DATE, g_hal_platform);
    char rustinfo[96];
    if (freax_rust_info(rustinfo, (int)sizeof(rustinfo)) > 0)
        printk("Module : %s\n", rustinfo);
    printk("\n");
}

void kernel_init_subsystems(void *heap_base, u32 heap_size)
{
    mm_init(heap_base, heap_size);
    vfs_init();
    sched_init();
}

void kernel_shutdown_cleanup(void)
{
    printk("\nNettoyage / cleanup : taches (tasks), vfs, rapport memoire...\n");
    sched_shutdown();
    sched_free_all();
    vfs_shutdown();
    struct mm_stats s;
    mm_get_stats(&s);
    int leaks = mm_leak_count();
    printk("Fuites restantes / remaining leaks : %d bloc(s)\n", leaks);
    printk("Pic memoire / memory peak : %u / %u octets | allocs=%u frees=%u\n",
           s.peak_used, s.heap_size, s.n_alloc, s.n_free);
}

/* tâche init remplaçable / replaceable init task (défaut : shell_task) */
static void (*g_init_task)(void) = NULL;

void kernel_set_init_task(void (*entry)(void))
{
    g_init_task = entry;
}

void kernel_boot(void *heap_base, u32 heap_size)
{
    print_banner();
    kernel_init_subsystems(heap_base, heap_size);
    if (sched_spawn("init", g_init_task ? g_init_task : shell_task, 0) < 0)
        kpanic("kernel : echec du lancement de la tache init");
    sched_run(0);                       /* tourne jusqu'au halt / runs to halt */
    kernel_shutdown_cleanup();
}
