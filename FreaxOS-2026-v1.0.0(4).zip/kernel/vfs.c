/*
 * FreaxOS 2026 - kernel/vfs.c
 * Ramfs + mini /proc / In-memory filesystem with a tiny /proc.
 *
 * FR : Tout est en mémoire (comme le minix-fs rudimentaire du 0.12, mais sans
 *      disque). Les nœuds /proc sont « dynamiques » : leur contenu est régénéré
 *      à chaque lecture par une fonction. Un seul espace d'adressage : les
 *      tampons passent directement, sans copie utilisateur/noyau.
 * EN : Everything lives in memory (like 0.12's minimal minix-fs, minus the
 *      disk). /proc nodes are "dynamic": content is regenerated on every read
 *      by a function. Single address space: buffers pass straight through,
 *      no user/kernel copies.
 */
#include "freax/vfs.h"
#include "freax/mm.h"
#include "freax/printk.h"
#include "freax/sched.h"
#include "freax/config.h"
#include "freax/libc.h"
#include "freax/hal.h"

static struct vnode *g_root;
static struct vnode *g_cwd;

/* ---- table de descripteurs / fd table ---- */
struct vfile {
    struct vnode *v;
    u32 pos;
    int used;
};
static struct vfile g_ft[FREAX_MAX_OPEN];

void vfs_fd_close_all_for(struct vnode *v)
{
    for (int i = 0; i < FREAX_MAX_OPEN; i++) {
        if (g_ft[i].used && g_ft[i].v == v) {
            g_ft[i].used = 0;
            g_ft[i].v = NULL;
        }
    }
}

/* ---- allocation de nœuds / node allocation ---- */

static struct vnode *node_new(const char *name, int type)
{
    struct vnode *v = (struct vnode *)kmalloc_zero(sizeof(struct vnode));
    if (!v)
        return NULL;
    strncpy(v->name, name, VFS_NAME_MAX - 1);
    v->type = type;
    return v;
}

static void node_free(struct vnode *v)
{
    vfs_fd_close_all_for(v);
    kfree(v->data);
    kfree(v);
}

static struct vnode *child_find(struct vnode *dir, const char *name)
{
    for (struct vnode *c = dir->children; c; c = c->sibling_next)
        if (strcmp(c->name, name) == 0)
            return c;
    return NULL;
}

static void child_add(struct vnode *dir, struct vnode *c)
{
    c->parent = dir;
    c->sibling_next = dir->children;
    dir->children = c;
}

static struct vnode *dir_of_path(char *path, char *base_out, int base_cap)
{
    /* sépare « /a/b » en dir=/a + base=b / split "/a/b" into dir + base */
    int len = (int)strlen(path);
    while (len > 1 && path[len - 1] == '/')
        path[--len] = '\0';                 /* retire '/' final / trim '/' */
    char *slash = strrchr(path, '/');
    const char *base;
    char dirbuf[256];
    if (!slash) {
        strncpy(dirbuf, ".", sizeof(dirbuf) - 1);
        dirbuf[sizeof(dirbuf) - 1] = '\0';
        base = path;
    } else if (slash == path) {
        strncpy(dirbuf, "/", sizeof(dirbuf) - 1);
        base = slash + 1;
    } else {
        freax_size dlen = (freax_size)(slash - path);
        if (dlen >= sizeof(dirbuf))
            return NULL;
        memcpy(dirbuf, path, dlen);
        dirbuf[dlen] = '\0';
        base = slash + 1;
    }
    if (base_out && base_cap > 0) {
        strncpy(base_out, base, (freax_size)base_cap - 1);
        base_out[base_cap - 1] = '\0';
    }
    return vfs_resolve(dirbuf);
}

/* ---- résolution / resolution ---- */

static struct vnode *resolve_from(struct vnode *start, const char *path)
{
    char buf[256];
    strncpy(buf, path, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';

    struct vnode *cur = start;
    const char *p = buf;
    while (*p) {
        while (*p == '/')
            p++;
        if (!*p)
            break;
        char comp[VFS_NAME_MAX];
        int n = 0;
        while (*p && *p != '/' && n < VFS_NAME_MAX - 1)
            comp[n++] = *p++;
        comp[n] = '\0';
        while (*p && *p != '/')
            p++;                        /* composant trop long / too long */

        if (strcmp(comp, ".") == 0)
            continue;
        if (strcmp(comp, "..") == 0) {
            if (cur->parent)
                cur = cur->parent;
            continue;
        }
        if (cur->type != VNODE_DIR)
            return NULL;
        cur = child_find(cur, comp);
        if (!cur)
            return NULL;
    }
    return cur;
}

struct vnode *vfs_resolve(const char *path)
{
    if (!path || !path[0])
        return g_cwd;
    return resolve_from(path[0] == '/' ? g_root : g_cwd, path);
}

struct vnode *vfs_resolve_dir(const char *path)
{
    struct vnode *v = vfs_resolve(path);
    return (v && v->type == VNODE_DIR) ? v : NULL;
}

/* ---- création/suppression / create/unlink ---- */

struct vnode *vfs_mkdir(const char *path)
{
    if (vfs_resolve(path))
        return NULL;                    /* existe déjà / already exists */
    char base[VFS_NAME_MAX];
    char pathbuf[256];
    strncpy(pathbuf, path, sizeof(pathbuf) - 1);
    pathbuf[sizeof(pathbuf) - 1] = '\0';
    struct vnode *dir = dir_of_path(pathbuf, base, sizeof(base));
    if (!dir || dir->type != VNODE_DIR || !base[0])
        return NULL;
    struct vnode *v = node_new(base, VNODE_DIR);
    if (!v)
        return NULL;
    child_add(dir, v);
    return v;
}

struct vnode *vfs_create(const char *path)
{
    struct vnode *existing = vfs_resolve(path);
    if (existing)
        return (existing->type == VNODE_FILE) ? existing : NULL;
    char base[VFS_NAME_MAX];
    char pathbuf[256];
    strncpy(pathbuf, path, sizeof(pathbuf) - 1);
    pathbuf[sizeof(pathbuf) - 1] = '\0';
    struct vnode *dir = dir_of_path(pathbuf, base, sizeof(base));
    if (!dir || dir->type != VNODE_DIR || !base[0])
        return NULL;
    struct vnode *v = node_new(base, VNODE_FILE);
    if (!v)
        return NULL;
    child_add(dir, v);
    return v;
}

int vfs_unlink(const char *path)
{
    struct vnode *v = vfs_resolve(path);
    if (!v || v == g_root || v == g_cwd)
        return -1;
    if (v->type == VNODE_DIR && v->children)
        return -2;                      /* non vide / not empty */
    if (v->parent) {
        struct vnode **pp = &v->parent->children;
        while (*pp && *pp != v)
            pp = &(*pp)->sibling_next;
        if (*pp)
            *pp = v->sibling_next;
    }
    node_free(v);
    return 0;
}

/* ---- contenu / content ---- */

int vfs_truncate(struct vnode *v)
{
    if (!v || v->type != VNODE_FILE || v->is_dynamic)
        return -1;
    v->size = 0;
    return 0;
}

int vfs_write(struct vnode *v, const char *buf, u32 len, u32 pos)
{
    if (!v || v->type != VNODE_FILE || v->is_dynamic)
        return -1;
    u32 end = pos + len;
    if (end < pos)
        return -1;                      /* débordement / overflow */
    if (end > v->cap) {
        u32 newcap = (end + 63u) & ~(u32)63u;
        char *nd = (char *)kmalloc(newcap);
        if (!nd)
            return -1;
        if (v->data) {
            memcpy(nd, v->data, v->cap);
            kfree(v->data);
        }
        v->data = nd;
        v->cap = newcap;
    }
    memcpy(v->data + pos, buf, len);
    if (end > v->size)
        v->size = end;
    return 0;
}

int vfs_read(struct vnode *v, char *out, u32 len, u32 *pos)
{
    if (!v || v->type != VNODE_FILE || !out)
        return -1;
    if (v->is_dynamic) {
        /* contenu régénéré à chaque ouverture : la position fait foi pour
         * éviter la boucle infinie de « cat » / regenerated per open: pos
         * guards against an endless cat loop */
        if (v->read_fn && *pos == 0) {
            int n = v->read_fn(v, out, (int)len);
            if (n < 0)
                n = 0;
            if ((u32)n > len)
                n = (int)len;
            *pos += (u32)n;
            if (n == (int)len && len > 0)
                *pos += 1;      /* pas fini : encore un coup / not done yet */
            return n;
        }
        return 0;
    }
    if (!v->data || *pos >= v->size)
        return 0;
    u32 avail = v->size - *pos;
    u32 n = (len < avail) ? len : avail;
    memcpy(out, v->data + *pos, n);
    *pos += n;
    return (int)n;
}

/* ---- listing & chemins / listing & paths ---- */

int vfs_list(struct vnode *dir,
             int (*cb)(const char *name, int type, void *ctx), void *ctx)
{
    if (!dir || dir->type != VNODE_DIR)
        return -1;
    for (struct vnode *c = dir->children; c; c = c->sibling_next)
        if (cb(c->name, c->type, ctx) == 0)
            break;
    return 0;
}

/* Chemin récursif depuis la racine / recursive path from the root. */
static int path_build(struct vnode *v, char *out, int cap)
{
    if (!v->parent) {                       /* racine / root */
        if (cap < 2)
            return -1;
        out[0] = '/';
        out[1] = '\0';
        return 1;
    }
    int n = path_build(v->parent, out, cap);
    if (n < 0)
        return -1;
    int i = n;
    if (n > 1) {                            /* pas après « / » / no double / */
        if (i >= cap - 1)
            return -1;
        out[i++] = '/';
    }
    for (const char *p = v->name; *p && i < cap - 1; p++)
        out[i++] = *p;
    out[i] = '\0';
    return i;
}

int vfs_path_of(struct vnode *v, char *out, int cap)
{
    if (!v || cap <= 0)
        return -1;
    return path_build(v, out, cap);
}

struct vnode *vfs_root(void)        { return g_root; }
struct vnode *vfs_cwd(void)         { return g_cwd; }
void vfs_set_cwd(struct vnode *dir) { if (dir && dir->type == VNODE_DIR) g_cwd = dir; }

/* ---- fds ---- */

int vfs_fd_open(struct vnode *v, int mode)
{
    if (!v || v->type != VNODE_FILE)
        return -1;
    for (int i = 3; i < FREAX_MAX_OPEN; i++) {
        if (!g_ft[i].used) {
            g_ft[i].used = 1;
            g_ft[i].v = v;
            if (mode == 1) {            /* 'w' : tronque / truncate      */
                vfs_truncate(v);
                g_ft[i].pos = 0;
            } else if (mode == 2) {     /* 'a' : ajoute / append         */
                g_ft[i].pos = v->size;
            } else {
                g_ft[i].pos = 0;
            }
            return i;
        }
    }
    return -1;
}

int vfs_fd_read(int fd, char *buf, int len)
{
    if (fd < 3 || fd >= FREAX_MAX_OPEN || !g_ft[fd].used || len < 0)
        return -1;
    return vfs_read(g_ft[fd].v, buf, (u32)len, &g_ft[fd].pos);
}

int vfs_fd_write(int fd, const char *buf, int len)
{
    if (fd < 3 || fd >= FREAX_MAX_OPEN || !g_ft[fd].used || len < 0)
        return -1;
    struct vfile *f = &g_ft[fd];
    int r = vfs_write(f->v, buf, (u32)len, f->pos);
    if (r == 0) {
        f->pos += (u32)len;
        return len;
    }
    return r;
}

void vfs_fd_close(int fd)
{
    if (fd >= 3 && fd < FREAX_MAX_OPEN) {
        g_ft[fd].used = 0;
        g_ft[fd].v = NULL;
    }
}

/* ---- mini /proc ---- */

static int proc_version(struct vnode *v, char *out, int cap)
{
    (void)v;
    return freax_snprintf(out, cap,
        "FreaxOS version %s (%s)\n"
        "inspired by Linux 0.12 - GNU GPL, February 1992\n"
        "compiled %s for %s\n",
        FREAX_RELEASE, FREAX_CODENAME, FREAX_BUILD_DATE, g_hal_platform);
}

static int proc_uptime(struct vnode *v, char *out, int cap)
{
    (void)v;
    u32 t = g_hal ? g_hal->ticks() : 0;
    return freax_snprintf(out, cap, "%u.%02u s (%u ticks @ %d Hz)\n",
                          t / FREAX_TICK_HZ, t % FREAX_TICK_HZ, t,
                          FREAX_TICK_HZ);
}

static int proc_meminfo(struct vnode *v, char *out, int cap)
{
    (void)v;
    struct mm_stats s;
    mm_get_stats(&s);
    return freax_snprintf(out, cap,
        "HeapTotal : %u bytes\nHeapUsed  : %u bytes\nHeapFree  : %u bytes\n"
        "HeapPeak  : %u bytes\nAllocs    : %u\nFrees     : %u\n"
        "Failed    : %u\nBlocks    : %u\n",
        s.heap_size, s.used, s.free, s.peak_used,
        s.n_alloc, s.n_free, s.n_fail, s.n_blocks);
}

static int proc_cpuinfo(struct vnode *v, char *out, int cap)
{
    (void)v;
    return freax_snprintf(out, cap,
        "architecture : %s\nclock        : virtual (%d Hz ticks)\n"
        "cooperative  : round-robin scheduler\n",
        g_hal_platform, FREAX_TICK_HZ);
}

static int proc_tasks(struct vnode *v, char *out, int cap)
{
    (void)v;
    char tmp[1024];
    int n = freax_snprintf(tmp, sizeof(tmp),
                           "PID  NAME           STATE  TICKS\n");
    int m = sched_dump_tasks(tmp + n, (int)sizeof(tmp) - n);
    int total = n + m;
    for (int i = 0; i < total && i < cap - 1; i++)
        out[i] = tmp[i];
    out[(total < cap - 1) ? total : cap - 1] = '\0';
    return (total < cap - 1) ? total : cap - 1;
}

static int proc_klog(struct vnode *v, char *out, int cap)
{
    (void)v;
    return klog_read(out, cap);
}

static int proc_freax(struct vnode *v, char *out, int cap)
{
    (void)v;
    return freax_snprintf(out, cap,
        "\"Freax\" = free + freak + x : le nom d'origine du projet de\n"
        "Linus Torvalds, rebaptise \"Linux\" par Ari Lemmke, admin du FTP\n"
        "ftp.funet.fi, en septembre 1991. FreaxOS rend son nom d'origine\n"
        "au noyau educatif, pour saluer cette histoire. / FreaxOS gives\n"
        "the kernel its original name back, in tribute to that history.\n");
}

static void proc_add(const char *path,
                     int (*fn)(struct vnode *, char *, int))
{
    /* attache au dossier /proc indiqué par le chemin / attach under /proc */
    char base[VFS_NAME_MAX];
    char pathbuf[256];
    strncpy(pathbuf, path, sizeof(pathbuf) - 1);
    pathbuf[sizeof(pathbuf) - 1] = '\0';
    struct vnode *dir = dir_of_path(pathbuf, base, sizeof(base));
    if (!dir || dir->type != VNODE_DIR || !base[0] || vfs_resolve(path))
        return;
    struct vnode *v = node_new(base, VNODE_FILE);
    if (!v)
        return;
    v->is_dynamic = 1;
    v->read_fn = fn;
    child_add(dir, v);
}

/* ---- contenu par défaut / default content ---- */

static void seed_file(const char *path, const char *content)
{
    struct vnode *v = vfs_create(path);
    if (!v)
        return;
    vfs_write(v, content, (u32)strlen(content), 0);
}

static void vfs_seed(void)
{
    vfs_mkdir("/proc");
    vfs_mkdir("/etc");
    vfs_mkdir("/bin");
    vfs_mkdir("/home");
    vfs_mkdir("/home/root");
    vfs_mkdir("/tmp");

    proc_add("/proc/version", proc_version);
    proc_add("/proc/uptime", proc_uptime);
    proc_add("/proc/meminfo", proc_meminfo);
    proc_add("/proc/cpuinfo", proc_cpuinfo);
    proc_add("/proc/tasks", proc_tasks);
    proc_add("/proc/klog", proc_klog);
    proc_add("/proc/freax", proc_freax);

    seed_file("/etc/motd",
        "Bienvenue sur FreaxOS 2026 - Welcome to FreaxOS 2026\n"
        "\"Le noyau de 1992, reconstruit pour les developpeurs de 2026.\"\n"
        "Tapez 'help' pour la liste des commandes. / Type 'help'.\n");
    seed_file("/etc/freax-release", "FreaxOS 2026 v" FREAX_RELEASE " (freax)\n");
    seed_file("/home/root/README",
        "FR : Ce dossier est le repertoire de root. Le ramfs est volatile.\n"
        "EN : This folder is root's home. The ramfs is volatile.\n");

    /* /bin : les commandes integrees / built-in commands */
    static const char *bins[] = {
        "help", "version", "uname", "ls", "cd", "pwd", "cat", "echo",
        "ps", "mem", "uptime", "tux", "crc32", "demo", "halt", NULL
    };
    for (int i = 0; bins[i]; i++) {
        char p[64];
        int n = freax_snprintf(p, sizeof(p), "/bin/%s", bins[i]);
        (void)n;
        seed_file(p, "# commande integree du shell freaxsh / built-in shell command\n");
    }
}

/* ---- init / shutdown ---- */

static void free_subtree(struct vnode *v)
{
    struct vnode *c = v->children;
    while (c) {
        struct vnode *next = c->sibling_next;
        free_subtree(c);
        c = next;
    }
    node_free(v);
}

void vfs_init(void)
{
    g_root = node_new("/", VNODE_DIR);
    if (!g_root)
        kpanic("vfs : impossible d'allouer la racine");
    g_cwd = g_root;
    for (int i = 0; i < FREAX_MAX_OPEN; i++) {
        g_ft[i].used = 0;
        g_ft[i].v = NULL;
    }
    vfs_seed();
}

void vfs_shutdown(void)
{
    if (!g_root)
        return;
    free_subtree(g_root);   /* libère récursivement l'arbre / free tree recursively */
    g_root = g_cwd = NULL;
}
