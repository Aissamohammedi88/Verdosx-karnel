/*
 * FreaxOS 2026 - kernel/sched.c
 * Ordonnanceur round-robin coopératif / Cooperative round-robin scheduler.
 *
 * FR : Chaque tâche a sa propre pile (kmalloc) et son contexte. Le modèle est
 *      coopératif : une tâche cède le CPU à sched_yield()/task_block(). Le
 *      0.12 réel était préemptif ; ce choix éducatif est assumé et documenté
 *      dans docs/ARCHITECTURE.md.
 * EN : Every task owns its stack (kmalloc) and context. The model is
 *      cooperative: tasks surrender the CPU at sched_yield()/task_block().
 *      The real 0.12 was preemptive; this educational choice is documented in
 *      docs/ARCHITECTURE.md.
 */
#include "freax/sched.h"
#include "freax/ctx.h"
#include "freax/mm.h"
#include "freax/printk.h"
#include "freax/config.h"
#include "freax/hal.h"
#include "freax/syscall.h"

#include "freax/vfs.h"   /* vfs_fd_close_all_for à l'extinction */
#include "freax/libc.h"

struct task {
    int pid;
    char name[FREAX_TASK_NAME_MAX];
    int state;
    int exit_code;
    struct ctx *ctxp;
    u8 *stack;
    u32 stack_size;
    void (*entry)(void);
    struct task *next, *prev;
    int waiter_pid;
    int parent_pid;                 /* 0 = orphelin / orphan */
    u32 wake_at;                    /* 0 = pas endormi / not sleeping */
    void *files[FREAX_MAX_OPEN];
    u32 ticks_used;
};

static struct task *g_tasks;      /* liste circulaire / circular list */
static struct task *g_cursor;     /* dernier élu / last scheduled     */
static struct task *g_current;    /* tâche en cours / running task    */
static struct ctx  *g_sched_ctx;  /* contexte ordonnanceur / scheduler ctx */
static int   g_next_pid = 1;
static int   g_shutdown_req;
static u32   g_nswitches;

static struct task *task_by_pid(int pid);
int sched_task_count_active(void);

/* ---- accès pour syscall/vfs ---- */
void **task_current_files(void)
{
    static void *empty[FREAX_MAX_OPEN];
    return g_current ? g_current->files : empty;
}

int sched_current_pid(void)      { return g_current ? g_current->pid : 0; }
const char *sched_current_name(void) { return g_current ? g_current->name : "sched"; }

/* ---- cycle de vie ---- */

static void task_trampoline(void)
{
    struct task *t = g_current;
    t->entry();                 /* retour => sortie code 0 / fallthrough = 0 */
    task_exit(0);
}

static void task_destroy(struct task *t)
{
    if (t == g_current)
        return;                 /* jamais soi-même ici / never ourselves    */
    if (t->prev)
        t->prev->next = t->next;
    if (t->next)
        t->next->prev = t->prev;
    if (g_tasks == t)
        g_tasks = (t->next != t) ? t->next : NULL;
    if (g_cursor == t)
        g_cursor = g_tasks;
    kfree(t->ctxp);
    kfree(t->stack);
    kfree(t);
}

int sched_spawn(const char *name, void (*entry)(void), u32 stack_size)
{
    if (sched_task_count_active() >= FREAX_MAX_TASKS)
        return -1;
    if (stack_size == 0)
        stack_size = FREAX_STACK_SIZE;

    struct task *t = (struct task *)kmalloc(sizeof(struct task));
    u8 *stack = (u8 *)kmalloc(stack_size);
    struct ctx *c = (struct ctx *)kmalloc((u32)ctx_size());
    if (!t || !stack || !c) {
        kfree(t);
        kfree(stack);
        kfree(c);
        return -1;
    }

    strncpy(t->name, name ? name : "task", FREAX_TASK_NAME_MAX - 1);
    t->name[FREAX_TASK_NAME_MAX - 1] = '\0';
    t->pid = g_next_pid++;
    t->state = T_RUNNABLE;
    t->exit_code = 0;
    t->stack = stack;
    t->stack_size = stack_size;
    t->entry = entry;
    t->ctxp = c;
    t->waiter_pid = 0;
    t->parent_pid = g_current ? g_current->pid : 0;
    t->wake_at = 0;
    t->ticks_used = 0;
    for (int i = 0; i < FREAX_MAX_OPEN; i++)
        t->files[i] = NULL;

    if (ctx_init(c, stack, stack_size, task_trampoline) != 0) {
        kfree(t);
        kfree(stack);
        kfree(c);
        return -1;
    }

    if (!g_tasks) {
        t->next = t->prev = t;
        g_tasks = g_cursor = t;
    } else {
        /* insère après g_cursor (fin de file) / insert after cursor (tail) */
        t->next = g_cursor->next;
        t->prev = g_cursor;
        g_cursor->next->prev = t;
        g_cursor->next = t;
    }
    return t->pid;
}

void task_exit(int code)
{
    struct task *t = g_current;
    if (!t)
        kpanic("task_exit : appel hors tache / called outside a task");

    /* ferme les descripteurs ouverts / close open fds */
    for (int i = 0; i < FREAX_MAX_OPEN; i++) {
        if (t->files[i]) {
            vfs_fd_close(i);
            t->files[i] = NULL;
        }
    }

    t->exit_code = code;
    t->state = T_ZOMBIE;
    if (t->waiter_pid) {
        struct task *w = task_by_pid(t->waiter_pid);
        if (w && w->state == T_BLOCKED)
            w->state = T_RUNNABLE;
    }
    ctx_switch(t->ctxp, g_sched_ctx);
    for (;;) { } /* inaccessible / unreachable */
}

void sched_yield(void)
{
    struct task *t = g_current;
    if (!t)
        return;
    if (t->state == T_RUNNING)
        t->state = T_RUNNABLE;
    ctx_switch(t->ctxp, g_sched_ctx);
}

void task_block(void)
{
    struct task *t = g_current;
    if (!t)
        return;
    t->state = T_BLOCKED;
    ctx_switch(t->ctxp, g_sched_ctx);
}

void task_wake(int pid)
{
    struct task *t = task_by_pid(pid);
    if (t && t->state == T_BLOCKED)
        t->state = T_RUNNABLE;
}

/* Sommeil réel : la tâche est bloquée et réveillée au tick voulu.
 * Real sleep: the task blocks and is woken at the requested tick. */
void task_sleep_ticks(u32 n)
{
    struct task *t = g_current;
    if (!t || !g_hal)
        return;
    t->wake_at = g_hal->ticks() + n;
    if (t->wake_at == 0)
        t->wake_at = 1;             /* 0 signifie « pas endormi » / marker */
    t->state = T_BLOCKED;
    ctx_switch(t->ctxp, g_sched_ctx);
}

static void wake_due_tasks(void)
{
    if (!g_tasks || !g_hal)
        return;
    u32 now = g_hal->ticks();
    for (struct task *t = g_tasks;; t = t->next) {
        if (t->state == T_BLOCKED && t->wake_at &&
            (i32)(now - t->wake_at) >= 0) {
            t->wake_at = 0;
            t->state = T_RUNNABLE;
        }
        if (t->next == g_tasks)
            break;
    }
}

int task_wait(int pid, int *exit_code)
{
    struct task *t = task_by_pid(pid);
    if (!t)
        return -1;

    if (g_current) {
        /* depuis une tâche : bloque proprement / from a task: block cleanly */
        t->waiter_pid = g_current->pid;
        while (t->state != T_ZOMBIE) {
            if (g_shutdown_req)
                return -1;
            task_block();           /* se rendort sinon / sleep otherwise */
        }
    } else {
        /* hors tâche (harnais de tests) : on fait tourner l'ordonnanceur.
           waiter_pid = -1 protège le zombie de la reprise automatique. */
        t->waiter_pid = -1;
        while (t && t->state != T_ZOMBIE) {
            sched_run(200);
            if (sched_shutting_down())
                break;
            t = task_by_pid(pid);
        }
        t = task_by_pid(pid);
        if (!t)
            return -1;
    }

    if (exit_code)
        *exit_code = t->exit_code;
    task_destroy(t);
    return pid;
}

/* ---- ordonnanceur / scheduler ---- */

static struct task *pick_next(void)
{
    if (!g_tasks)
        return NULL;
    struct task *start = g_cursor ? g_cursor->next : g_tasks;
    struct task *t = start;
    do {
        if (t->state == T_RUNNABLE) {
            g_cursor = t;
            return t;
        }
        t = t->next;
    } while (t != start);
    return NULL;
}

void sched_run(u32 max_steps)
{
    u32 steps = 0;
    while (!g_shutdown_req) {
        wake_due_tasks();           /* réveille les dormeurs / wake sleepers */
        struct task *t = pick_next();
        if (!t) {
            if (g_hal && g_hal->idle)
                g_hal->idle();  /* rien de prêt : pause / nothing ready */
            if (max_steps && ++steps >= max_steps)
                break;
            continue;
        }
        g_current = t;
        t->state = T_RUNNING;
        g_nswitches++;
        ctx_switch(g_sched_ctx, t->ctxp);
        g_current = NULL;
        /* reprise seulement si orphelin réel / reap only when truly orphaned:
         * un zombie garde sa pile tant que le parent peut encore attendre */
        if (t->state == T_ZOMBIE && !t->waiter_pid &&
            (t->parent_pid == 0 || task_by_pid(t->parent_pid) == NULL))
            task_destroy(t);
        if (max_steps && ++steps >= max_steps)
            break;
    }
}

void sched_shutdown(void)
{
    g_shutdown_req = 1;
}

void sched_free_all(void)
{
    while (g_tasks) {
        struct task *t = g_tasks;
        for (int i = 0; i < FREAX_MAX_OPEN; i++)
            if (t->files[i])
                vfs_fd_close(i);
        g_tasks = (t->next != t) ? t->next : NULL;
        if (g_cursor == t)
            g_cursor = g_tasks;
        kfree(t->ctxp);
        kfree(t->stack);
        kfree(t);
    }
    g_cursor = g_current = NULL;
}

int sched_shutting_down(void)
{
    return g_shutdown_req;
}

int sched_task_count(void)
{
    return sched_task_count_active();
}

static struct task *task_by_pid(int pid)
{
    if (!g_tasks)
        return NULL;
    for (struct task *t = g_tasks;; t = t->next) {
        if (t->pid == pid)
            return t;
        if (t->next == g_tasks)
            break;
    }
    return NULL;
}

int sched_task_count_active(void)
{
    int n = 0;
    if (!g_tasks)
        return 0;
    for (struct task *t = g_tasks;; t = t->next) {
        n++;
        if (t->next == g_tasks)
            break;
    }
    return n;
}

int sched_dump_tasks(char *out, int cap)
{
    char line[96];
    int total = 0;
    if (!g_tasks) {
        char empty[] = "  (aucune tache / no task)\n";
        for (int i = 0; empty[i] && total < cap - 1; i++)
            out[total++] = empty[i];
        out[total] = '\0';
        return total;
    }
    for (struct task *t = g_tasks;; t = t->next) {
        static const char *st[] = { "?", "RUN", "RUN", "BLK", "ZOM" };
        int n = freax_snprintf(line, (int)sizeof(line),
                               "  %-4d %-14s %-3s %u\n",
                               t->pid, t->name, st[t->state], t->ticks_used);
        for (int i = 0; i < n && total < cap - 1; i++)
            out[total++] = line[i];
        if (t->next == g_tasks)
            break;
    }
    out[total] = '\0';
    return total;
}

void sched_init(void)
{
    g_tasks = g_cursor = g_current = NULL;
    g_next_pid = 1;
    g_shutdown_req = 0;
    g_nswitches = 0;
    g_sched_ctx = (struct ctx *)kmalloc((u32)ctx_size());
    if (!g_sched_ctx)
        kpanic("sched : impossible d'allouer le contexte ordonnanceur");
    /* Pas de capture nécessaire : chaque ctx_switch(&sched, t) écrit
     * l'état courant de l'ordonnanceur. / No capture needed: every
     * ctx_switch(&sched, t) stores the scheduler's live state. */
}

u32 sched_switch_count(void)
{
    return g_nswitches;
}
