/*
 * FreaxOS 2026 - kernel/tux_stub.c
 * Repli C du module Rust / C fallback for the Rust module.
 *
 * FR : Si cargo n'est pas disponible (ou FREAX_NO_RUST=1), ces symboles
 *      remplacent rust/freax_rust avec un comportement identique : CRC32 et
 *      mascotte Tux. Le Makefile lie soit ce fichier, soit la staticlib Rust.
 * EN : When cargo is unavailable (or FREAX_NO_RUST=1), these symbols replace
 *      rust/freax_rust with identical behaviour: CRC32 and the Tux mascot.
 *      The Makefile links either this file or the Rust static library.
 */
#include "freax/shell.h"
#include "freax/printk.h"
#include "freax/libc.h"

u32 freax_crc32(const u8 *data, u32 len, u32 seed)
{
    u32 crc = seed ^ 0xFFFFFFFFu;
    for (u32 i = 0; i < len; i++) {
        crc ^= data[i];
        for (int k = 0; k < 8; k++)
            crc = (crc >> 1) ^ (0xEDB88320u & (u32)(-(i32)(crc & 1)));
    }
    return crc ^ 0xFFFFFFFFu;
}

int freax_tux_lines(char *out, int cap)
{
    static const char *art[] = {
        "   _____",
        "  /     \\        .---.",
        " | () () |       |o o|",
        "  \\  ^  /        (   )",
        "   |||||          \\_/ ~",
        "   |||||       .-\"\"\"\"\"\"-.",
        "  _/___\\_     /  FreaxOS \\",
        " (  TUX  )    \\  2026    /",
        "  `\"\"\"\"\"`      '-.,___,.-'",
        NULL
    };
    if (!out || cap <= 0)
        return 0;
    int n = 0, lines = 0;
    for (int i = 0; art[i]; i++) {
        for (const char *p = art[i]; *p && n < cap - 1; p++)
            out[n++] = *p;
        if (n < cap - 1)
            out[n++] = '\n';
        lines++;
    }
    out[n] = '\0';
    return lines;
}

int freax_rust_info(char *out, int cap)
{
    (void)cap;
    if (!out || cap <= 0)
        return 0;
    strncpy(out, "FreaxCore C (fallback) - compilez avec cargo pour Rust",
            (freax_size)cap - 1);
    out[cap - 1] = '\0';
    return (int)strlen(out);
}
