/*
 * FreaxOS 2026 - kernel/printk.c
 * printk + mini-vsnprintf + anneau de journal / printk + tiny vsnprintf + klog.
 *
 * FR : Le formatage s'écrit d'abord dans un tampon, puis part simultanément
 *      vers la console et vers un anneau de 4 Kio consultable via /proc/klog —
 *      une commodité « 2026 » que le 0.12 n'avait pas.
 * EN : Output is formatted into a buffer, then fanned out to the console and
 *      to a 4 KiB ring readable through /proc/klog — a "2026" convenience the
 *      0.12 kernel never had.
 */
#include "freax/printk.h"
#include "freax/hal.h"
#include "freax/config.h"
#include "freax/shell.h"   /* console_write */

static char klog_buf[FREAX_KLOG_SIZE];
static u32  klog_head;      /* position d'écriture (jamais décroissante) */
static int  klog_full;

static void klog_push(const char *s, int n)
{
    for (int i = 0; i < n; i++) {
        klog_buf[klog_head % FREAX_KLOG_SIZE] = s[i];
        klog_head++;
        if (klog_head > FREAX_KLOG_SIZE)
            klog_full = 1;
    }
}

void klog_write(const char *s, int n)
{
    klog_push(s, n);
}

int klog_read(char *out, int cap)
{
    u32 total = klog_full ? FREAX_KLOG_SIZE : klog_head;
    u32 start = klog_full ? klog_head % FREAX_KLOG_SIZE : 0;
    if ((int)total > cap)
        total = (u32)cap;
    for (u32 i = 0; i < total; i++)
        out[i] = klog_buf[(start + i) % FREAX_KLOG_SIZE];
    return (int)total;
}

/* ---- formatage ---- */

struct fmtbuf {
    char *s;
    int   cap;
    int   n;
};

static void fmt_putc(struct fmtbuf *b, char c)
{
    if (b->cap > 0 && b->n < b->cap - 1)
        b->s[b->n++] = c;
}

static void fmt_puts(struct fmtbuf *b, const char *s, int width, int zero,
                     int left, int maxlen)
{
    const char *p = s;
    if (!p)
        p = "(null)";
    int len = 0;
    while (p[len] && (maxlen < 0 || len < maxlen))
        len++;
    int pad = width > len ? width - len : 0;
    for (int i = 0; i < pad && !left; i++)
        fmt_putc(b, zero ? '0' : ' ');
    for (int i = 0; i < len; i++)
        fmt_putc(b, p[i]);
    for (int i = 0; i < pad && left; i++)
        fmt_putc(b, ' ');
}

static void fmt_ux(struct fmtbuf *b, u32 v, int base, int upper, int width,
                   int zero, int left)
{
    char digits[16];
    const char *d = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int n = 0;
    if (v == 0)
        digits[n++] = '0';
    while (v) {
        digits[n++] = d[v % (u32)base];
        v /= (u32)base;
    }
    int pad = width > n ? width - n : 0;
    for (int i = 0; i < pad && !left; i++)
        fmt_putc(b, zero ? '0' : ' ');
    while (n--)
        fmt_putc(b, digits[n]);
    for (int i = 0; i < pad && left; i++)
        fmt_putc(b, ' ');
}

static void fmt_d(struct fmtbuf *b, i32 v, int width, int zero, int left)
{
    u32 mag = (v < 0) ? (u32)(-(i64)v) : (u32)v;
    if (v < 0) {
        /* le signe doit précéder le remplissage à zéro */
        char tmp[16];
        int n = 0;
        if (mag == 0)
            tmp[n++] = '0';
        while (mag) {
            tmp[n++] = (char)('0' + (mag % 10));
            mag /= 10;
        }
        int pad = width > n + 1 ? width - n - 1 : 0;
        fmt_putc(b, '-');
        for (int i = 0; i < pad && !left; i++)
            fmt_putc(b, zero ? '0' : ' ');
        while (n--)
            fmt_putc(b, tmp[n]);
        for (int i = 0; i < pad && left; i++)
            fmt_putc(b, ' ');
        return;
    }
    fmt_ux(b, (u32)v, 10, 0, width, zero, left);
}

int freax_vsnprintf(char *out, int cap, const char *fmt, __builtin_va_list ap)
{
    struct fmtbuf b = { out, cap, 0 };
    if (cap > 0)
        out[0] = '\0';

    for (const char *p = fmt; *p; p++) {
        if (*p != '%') {
            fmt_putc(&b, *p);
            continue;
        }
        p++;
        int zero = 0, left = 0, width = 0;
        /* drapeaux / flags */
        for (;; p++) {
            if (*p == '0')
                zero = 1;
            else if (*p == '-')
                left = 1;
            else
                break;
        }
        while (*p >= '0' && *p <= '9') {
            width = width * 10 + (*p - '0');
            p++;
        }
        /* « l » accepté mais ignoré (int 32 bits partout ici) */
        if (*p == 'l')
            p++;

        switch (*p) {
        case 'd':
        case 'i':
            fmt_d(&b, __builtin_va_arg(ap, i32), width, zero, left);
            break;
        case 'u':
            fmt_ux(&b, __builtin_va_arg(ap, u32), 10, 0, width, zero, left);
            break;
        case 'x':
            fmt_ux(&b, __builtin_va_arg(ap, u32), 16, 0, width, zero, left);
            break;
        case 'X':
            fmt_ux(&b, __builtin_va_arg(ap, u32), 16, 1, width, zero, left);
            break;
        case 'c':
            fmt_putc(&b, (char)__builtin_va_arg(ap, int));
            break;
        case 's':
            fmt_puts(&b, __builtin_va_arg(ap, const char *), width, zero,
                     left, -1);
            break;
        case 'p': {
            freax_uptr v = (freax_uptr)__builtin_va_arg(ap, void *);
            fmt_putc(&b, '0');
            fmt_putc(&b, 'x');
            fmt_ux(&b, (u32)v, 16, 0, (int)(2 * sizeof(freax_uptr)), 1, 0);
            break;
        }
        case '%':
            fmt_putc(&b, '%');
            break;
        case '\0':
            p--; /* fin de chaîne inattendue / unexpected end */
            break;
        default:
            fmt_putc(&b, '%');
            fmt_putc(&b, *p);
            break;
        }
    }
    if (cap > 0)
        out[b.n < cap ? b.n : cap - 1] = '\0';
    return b.n;
}

int freax_snprintf(char *out, int cap, const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int n = freax_vsnprintf(out, cap, fmt, ap);
    __builtin_va_end(ap);
    return n;
}

void vprintk(const char *fmt, __builtin_va_list ap)
{
    char tmp[1024];
    int n = freax_vsnprintf(tmp, (int)sizeof(tmp), fmt, ap);
    console_write(tmp, n);
    klog_write(tmp, n);
}

void printk(const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vprintk(fmt, ap);
    __builtin_va_end(ap);
}

void kpanic(const char *fmt, ...)
{
    char tmp[512];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    freax_vsnprintf(tmp, (int)sizeof(tmp), fmt, ap);
    __builtin_va_end(ap);
    printk("\n*** KERNEL PANIC : %s ***\n*** system halted ***\n", tmp);
    if (g_hal)
        g_hal->shutdown(0);
    for (;;)
        ; /* repli si pas de HAL / fallback if no HAL */
}
