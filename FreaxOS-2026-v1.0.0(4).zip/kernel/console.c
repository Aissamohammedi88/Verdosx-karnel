/*
 * FreaxOS 2026 - kernel/console.c
 * Console du noyau + capture pour tests / Kernel console + test capture.
 *
 * FR : printk arrive ici après formatage. La capture (utilisée par les tests
 *      unitaires) intercepte la sortie avant le HAL.
 * EN : printk lands here after formatting. The capture hook (used by unit
 *      tests) intercepts output before the HAL.
 */
#include "freax/shell.h"
#include "freax/hal.h"

/* Définition unique du pointeur HAL / single definition of the HAL pointer. */
struct hal *g_hal = NULL;
/* Plateforme, écrasée par le HAL actif / overwritten by the active HAL. */
const char *g_hal_platform = "unknown";

static char *g_capture;
static int   g_capture_cap;
static int   g_capture_len;

void console_set_capture(char *buf, int cap)
{
    g_capture = buf;
    g_capture_cap = cap;
    g_capture_len = 0;
    if (buf && cap > 0)
        buf[0] = '\0';
}

void console_putc(char c)
{
    if (g_capture && g_capture_len < g_capture_cap - 1) {
        g_capture[g_capture_len++] = c;
        g_capture[g_capture_len] = '\0';
    }
    if (g_hal && g_hal->putc)
        g_hal->putc(c);
}

void console_write(const char *s, int n)
{
    for (int i = 0; i < n; i++)
        console_putc(s[i]);
}

int console_trygetc(void)
{
    if (g_hal && g_hal->getc)
        return g_hal->getc();
    return -1;
}
