/*
 * FreaxOS 2026 - baremetal/main.c
 * kmain bare-metal / bare-metal kmain.
 *
 * FR : Vérifie le magic multiboot, prépare le tas depuis la mémoire libre
 *      annoncée par GRUB/QEMU, installe interruptions et HAL, puis appelle le
 *      noyau portable.
 * EN : Verifies the multiboot magic, carves the heap from free memory
 *      reported by GRUB/QEMU, installs interrupts and the HAL, then hands
 *      control to the portable kernel.
 */
#include "freax/kernel.h"
#include "freax/mm.h"
#include "freax/printk.h"
#include "freax/hal.h"
#include "freax/config.h"
#include "i386.h"
#include "freax/types.h"

void interrupts_install(void);
void hal_i386_install(void);
void pit_init(void);

/* fournis par linker.ld / from the linker script */
extern u8 _end[];

#define MB_BOOT_MAGIC 0x2BADB002u

static void park(void)
{
    for (;;) {
        cli();
        hlt();
    }
}

void kmain(u32 magic, u32 mbinfo)
{
    hal_i386_install();             /* console dès maintenant / console first */
    interrupts_install();
    pit_init();

    if (magic != MB_BOOT_MAGIC) {
        printk("kmain : magic multiboot invalide / bad multiboot magic: %x\n",
               magic);
        if (g_hal)
            g_hal->shutdown(0);
        park();
    }

    /* tas : depuis _end, aligné 2 Mio, borné par mem_upper / heap bounds */
    freax_uptr base = ((freax_uptr)_end + 0x1FFFFF) & ~(freax_uptr)0x1FFFFF;
    u32 heap = FREAX_HEAP_SIZE;

    u32 *mb = (u32 *)(freax_uptr)mbinfo;
    if (mb && (mb[0] & 1)) {        /* bit 0 : mem_lower/mem_upper valides */
        u32 upper_bytes = mb[2] * 1024;   /* mémoire > 1 Mio / memory above 1M */
        u32 avail = (upper_bytes > 0x100000) ? upper_bytes - 0x100000 : 0;
        if (avail > (u32)(base - 0x100000))
            avail -= (u32)(base - 0x100000);
        else
            avail = 0;
        if (avail < heap)
            heap = avail;
    }
    if (heap < 256 * 1024) {        /* plancher raisonnable / sane floor */
        printk("kmain : mémoire insuffisante / not enough memory (%u)\n", heap);
        if (g_hal)
            g_hal->shutdown(0);
        park();
    }

    sti();                          /* interruptions OK / interrupts live */

    kernel_boot((void *)base, heap);
    /* kernel_boot ne revient pas (halt) / never returns (halt loop) */
    park();
}
